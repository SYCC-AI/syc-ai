extends Node
## 70-model catalog: unique ids, a Persian name each, collection grid with 70 cards (never crashes on missing thumbs),
## showcase id, zoom slider mapping.

const Catalog := preload("res://scripts/ui/catalog.gd")
var fails: int = 0

func check(name: String, ok: bool, why: String = "") -> void:
	if ok:
		print("PASS ", name)
	else:
		fails += 1
		print("FAIL ", name, ": ", why)

func _ready() -> void:
	Game.save_path = "user://meta_catalog_test.json"
	Game.test_mode = true
	check("catalog_70", Catalog.IDS.size() == 70, str(Catalog.IDS.size()))
	var seen := {}
	var dup := 0
	var missing: Array[String] = []
	for id in Catalog.IDS:
		if seen.has(id):
			dup += 1
		seen[id] = true
		var t := TranslationServer.translate("MODEL_" + id)
		if t == "" or t == "MODEL_" + id:
			missing.append(id)
	check("catalog_unique", dup == 0)
	check("catalog_names_fa", missing.is_empty(), str(missing))
	check("catalog_blk_tail", Catalog.IDS[50] == "blk_cube2" and Catalog.IDS[69] == "blk_giant_cube5")
	check("id_of_clamps", Catalog.id_of(0) == "blk_s01" and Catalog.id_of(99) == "blk_giant_cube5" and Catalog.id_of(10) == "blk_s10")
	for lvl in [1, 36, 71]:
		Game.level = lvl
		var col: Control = load("res://scenes/ui/collection.tscn").instantiate()
		add_child(col)
		await get_tree().process_frame
		var grid := _find_grid(col)
		check("collection_cards_L%d" % lvl, grid != null and grid.get_child_count() == 70 and grid.columns == 3, str(grid.get_child_count() if grid else -1))
		col.queue_free()
	Game.level = 1
	check("unlock_rule", not Catalog.unlocked(0))
	Game.level = 2
	check("unlock_first", Catalog.unlocked(0) and not Catalog.unlocked(1))
	var zs := ZoomSlider.new()
	add_child(zs)
	zs.size = Vector2(120, 600)
	zs.set_value(0.5)
	check("zoom_slider_value", is_equal_approx(zs.value, 0.5))
	zs.set_value(5.0)
	check("zoom_slider_clamp", zs.value == 1.0)
	print("RESULT PASS" if fails == 0 else "RESULT FAIL n=%d" % fails)
	get_tree().quit(0 if fails == 0 else 1)

func _find_grid(n: Node) -> GridContainer:
	if n is GridContainer:
		return n
	for c in n.get_children():
		var g := _find_grid(c)
		if g:
			return g
	return null
