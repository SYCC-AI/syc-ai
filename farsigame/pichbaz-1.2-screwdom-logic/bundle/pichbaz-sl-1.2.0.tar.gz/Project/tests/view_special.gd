extends Node
## Special edition 1.1 (Docs/design/SPECIAL_EDITION.md 7) on the real GameView:
##  A. L1 gift box: when the lid's last screw goes the lid opens on its hinge and STAYS (node alive, turned, released);
##  B. L5 radio: a bot turn of the dial changes the rules' rotor state and the knob's visual angle, and a plate head
##     that was covered in state 0 becomes tappable in some later state;
##  C. L7 cake: a locked candle screw tapped before the star key is refused (locked_tapped, nothing removed); after the
##     key it goes.

var fails: int = 0
var gv: GameView


func check(name: String, ok: bool, why: String = "") -> void:
	if ok:
		print("PASS ", name)
	else:
		fails += 1
		print("FAIL ", name, ": ", why)


func _ready() -> void:
	gv = (load("res://scenes/game/game_view.tscn") as PackedScene).instantiate() as GameView
	add_child(gv)
	gv.anim_speed = 20.0
	await get_tree().process_frame
	await _hinge_l1()
	await _rotor_l5()
	await _lock_l7()
	print("RESULT PASS" if fails == 0 else "RESULT FAIL n=%d" % fails)
	get_tree().quit(0 if fails == 0 else 1)


func _begin(n: int) -> void:
	gv.start_level(n)
	await get_tree().physics_frame
	await get_tree().physics_frame


func _settle() -> void:
	var g := 0
	while gv.is_busy() and g < 3000:
		await get_tree().process_frame
		g += 1


func _hinge_l1() -> void:
	await _begin(1)
	var lid: String = ""
	for pid: String in gv._part_def:
		if (gv._part_def[pid] as Dictionary).has("hinge"):
			lid = pid
	if lid == "":
		print("SKIP L1 hinge: no hinged part in the level (1.2: cube levels; the 1.1 living toys left the catalog)")
		return
	var before: Transform3D = (gv._parts[lid] as Node3D).transform
	var level: Dictionary = Levels.load_level(1)
	# the lid's own screws first (they sit on top, open at the start): the lid must open while its host wall still stands
	var lid_screws: Array[int] = []
	for s: Dictionary in level["screws"]:
		if String(s["part"]) == lid:
			lid_screws.append(int(s["id"]))
	check("L1 lid carries 1-4 screws (%d)" % lid_screws.size(), lid_screws.size() >= 1 and lid_screws.size() <= 4)
	for id in lid_screws:
		check("L1 lid screw %d is tappable at the start" % id, gv.state().is_tappable(id))
		gv.bot_tap(id)
		await _settle()
	check("L1 lid opened on its hinge when its last screw went", gv._hinged.has(lid))
	var node_v: Variant = gv._parts.get(lid)
	var alive: bool = node_v != null and is_instance_valid(node_v) and (node_v as Node).is_inside_tree()
	check("L1 open lid stays in the scene", alive)
	if alive:
		var node := node_v as Node3D
		var turned: float = rad_to_deg(before.basis.get_rotation_quaternion().angle_to(node.transform.basis.get_rotation_quaternion()))
		check("L1 open lid is turned (%.0f deg)" % turned, turned > 30.0)
	check("L1 open lid is released by the rules", gv.state().is_part_released(lid))
	# the heads under the lid (the surprise) are tappable now
	var freed_hidden := 0
	for s2: Dictionary in level["screws"]:
		if (s2["blocked_by"] as Array).has(lid) and gv.state().is_tappable(int(s2["id"])):
			freed_hidden += 1
	check("L1 heads hidden under the lid are tappable after it opens (%d)" % freed_hidden, freed_hidden >= 1)


func _rotor_l5() -> void:
	await _begin(5)
	var st: PuzzleState = gv.state()
	if st.rotor_count() == 0:
		print("SKIP L5 rotor: no rotor in the level (1.2: cube levels; the 1.1 living toys left the catalog)")
		return
	check("L5 has one rotor", st.rotor_count() == 1)
	var pid: String = st.rotor_part_id(0)
	var level: Dictionary = Levels.load_level(5)
	# a plate head covered at state 0 and open in some other state
	var probe: int = -1
	var open_state: int = -1
	for s: Dictionary in level["screws"]:
		var sts: Array = s.get("blocked_by_states", [])
		if sts.is_empty() or (sts[0] as Array).is_empty():
			continue
		for k in range(1, sts.size()):
			if (sts[k] as Array).is_empty():
				probe = int(s["id"])
				open_state = k
				break
		if probe >= 0:
			break
	check("L5 some head is covered at state 0 and open at another state", probe >= 0)
	check("L5 that head is not tappable at the start", probe < 0 or not st.is_tappable(probe))
	var a0: float = float(gv._rotor_angle.get(pid, 0.0))
	gv.bot_rotate(0)
	await _settle()
	check("L5 rules rotor state is 1 after one turn", st.rotor_state(0) == 1, str(st.rotor_state(0)))
	var a1: float = float(gv._rotor_angle.get(pid, 0.0))
	check("L5 knob turned a quarter (%.1f deg)" % rad_to_deg(absf(a1 - a0)), absf(absf(a1 - a0) - TAU / 4.0) < 0.05)
	if probe >= 0:
		while st.rotor_state(0) != open_state and st.can_rotate(0):
			gv.bot_rotate(0)
			await _settle()
		check("L5 covered head is tappable at state %d" % open_state, st.is_tappable(probe))
		gv.bot_tap(probe)
		await _settle()
		check("L5 covered head removed after the turn", st.is_removed(probe))


func _lock_l7() -> void:
	await _begin(7)
	var st: PuzzleState = gv.state()
	var level: Dictionary = Levels.load_level(7)
	if not level.has("key"):
		print("SKIP L7 lock: no key screw in the level (1.2: cube levels; the 1.1 living toys left the catalog)")
		return
	check("L7 has a key screw", level.has("key"))
	var key: int = int(level.get("key", -1))
	var locked: int = -1
	for s: Dictionary in level["screws"]:
		if not (s.get("needs", []) as Array).is_empty():
			locked = int(s["id"])
			break
	check("L7 has a locked screw", locked >= 0)
	if key < 0 or locked < 0:
		return
	var refused: Array[int] = [0]
	gv.locked_tapped.connect(func(_id: int) -> void: refused[0] += 1)
	check("L7 locked screw is not tappable before the key", not st.is_tappable(locked))
	gv.bot_tap(locked)
	await _settle()
	check("L7 tap on the locked screw is refused", refused[0] == 1 and not st.is_removed(locked), "refused=%d removed=%s" % [refused[0], str(st.is_removed(locked))])
	check("L7 key is tappable at the start", st.is_tappable(key))
	gv.bot_tap(key)
	await _settle()
	check("L7 key removed", st.is_removed(key))
	check("L7 locked screw is tappable after the key", st.is_tappable(locked))
	gv.bot_tap(locked)
	await _settle()
	check("L7 candle screw goes after the key", st.is_removed(locked))
