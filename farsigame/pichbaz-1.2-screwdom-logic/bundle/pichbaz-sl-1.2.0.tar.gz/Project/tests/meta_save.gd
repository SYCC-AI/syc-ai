extends Node

var fails: int = 0

func check(name: String, ok: bool, why: String = "") -> void:
	if ok:
		print("PASS ", name)
	else:
		fails += 1
		print("FAIL ", name, ": ", why)

func _ready() -> void:
	Game.save_path = "user://meta_save_test.json"
	DirAccess.remove_absolute(ProjectSettings.globalize_path(Game.save_path))
	Game.band_override = func(n: int) -> String: return {1: "tutorial", 5: "hard", 10: "very_hard"}.get(n, "normal")
	Game.load_save()
	check("fresh_coins", Game.coins == 100, str(Game.coins))
	check("fresh_level", Game.level == 1)
	check("fresh_boosters", Game.boosters == {"extra_slot": 0, "hammer": 0, "xray": 0})
	check("fresh_settings", Game.settings == {"sound": true, "music": true, "vibration": true})

	# win rewards per band + collection
	check("win_tutorial", Game.on_level_won(1) == 20)
	check("level_advances", Game.level == 2)
	Game.level = 5
	check("win_hard", Game.on_level_won(5) == 30)
	check("collection_L5", Game.collection == ["blk_s01", "blk_s05"], str(Game.collection))
	check("last_win_model", Game.last_win["new_model"] == "blk_s05")
	Game.level = 10
	check("win_very_hard", Game.on_level_won(10) == 40)
	check("collection_L10", Game.collection == ["blk_s01", "blk_s05", "blk_s10"], str(Game.collection))
	check("home_model", Game.home_model() == "blk_s10")
	Game.level = 7
	check("win_normal", Game.on_level_won(7) == 20)

	# round trip
	Game.add_booster("hammer", 3)
	Game.settings["music"] = false
	Game.no_ads = true
	Game.save()
	var snap := [Game.coins, Game.level, Game.boosters.duplicate(), Game.settings.duplicate(), Game.no_ads, Game.collection.duplicate()]
	Game.coins = 1
	Game.level = 1
	Game.load_save()
	var now := [Game.coins, Game.level, Game.boosters, Game.settings, Game.no_ads, Game.collection]
	check("round_trip", snap == now, str(snap) + " vs " + str(now))

	# corrupt file
	var f := FileAccess.open(Game.save_path, FileAccess.WRITE)
	f.store_string("{not json")
	f.close()
	Game.load_save()
	check("corrupt_fresh", Game.coins == 100 and Game.level == 1 and Game.collection.is_empty())

	# season end + replay
	Game.level = 70
	Game.on_level_won(70)
	check("season_done", Game.season_done() and Game.last_win["season_end"])
	check("collection_full", Game.collection == ["blk_giant_cube5"])
	check("replay_coins", Game.on_level_won(1) == 5)
	check("replay_level", Game.play_level() == 2 and Game.replay_level == 2, str(Game.replay_level))
	Game.replay_level = 70
	Game.on_level_won(70)
	check("replay_cycle", Game.replay_level == 1)

	# daily streak
	Game.load_save()
	Game.today_override = "2026-10-05"
	Game.coins = 0
	var st := Game.daily_state()
	check("daily_first", st["can_claim"] and st["day"] == 1)
	var r := Game.claim_daily(false)
	check("daily_d1", r["coins"] == 20 and Game.coins == 20)
	check("daily_once", not Game.daily_state()["can_claim"] and Game.claim_daily().is_empty())
	Game.today_override = "2026-10-06"
	check("daily_streak", Game.daily_state()["day"] == 2)
	r = Game.claim_daily(true)
	check("daily_double", r["coins"] == 60 and Game.coins == 80, str(Game.coins))
	Game.today_override = "2026-10-09"  # skipped days
	check("daily_reset", Game.daily_state()["day"] == 1)
	Game._daily_last = "2026-10-08"
	Game._daily_day = 7
	Game.today_override = "2026-10-09"
	check("daily_wrap", Game.daily_state()["day"] == 1)
	Game._daily_day = 5
	Game.boosters["hammer"] = 0
	Game.claim_daily()
	check("daily_d6_item", Game.boosters["extra_slot"] >= 1 and Game._daily_day == 6)

	# free coins limit
	Game.today_override = "2026-11-01"
	Game.coins = 0
	for i in 5:
		Game.claim_free_coins()
	check("free_5", Game.coins == 150 and Game.free_coins_left() == 0, str(Game.coins))
	check("free_6_refused", Game.claim_free_coins() == 0 and Game.coins == 150)
	Game.today_override = "2026-11-02"
	check("free_next_day", Game.free_coins_left() == 5)

	# items
	Game.boosters["xray"] = 1
	check("use_item", Game.use_booster_item("xray") and not Game.use_booster_item("xray"))
	Game.coins = 50
	check("spend_refused", not Game.spend_coins(60) and Game.coins == 50)
	check("spend_ok", Game.spend_coins(50) and Game.coins == 0)

	DirAccess.remove_absolute(ProjectSettings.globalize_path(Game.save_path))
	print("RESULT PASS" if fails == 0 else "RESULT FAIL n=%d" % fails)
	get_tree().quit(0 if fails == 0 else 1)
