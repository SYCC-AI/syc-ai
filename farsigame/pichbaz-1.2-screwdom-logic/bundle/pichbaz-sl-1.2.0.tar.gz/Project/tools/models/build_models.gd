extends Node
## Model pipeline (fix round 3), headless:
##   defs/<id>.gd -> ModelKit -> part ids p0..pN -> SocketGen (real-mesh rays) -> gates -> data/models_r3/<id>.json
## Run: Tools/gd.sh <dir> res://tools/models/build_models.tscn [-- id1 id2 ... --legacy --out=res://data/models_scratch/]
##   no ids = the whole catalog (Levels.CATALOG); --legacy = the 10 round-2 definitions (pipeline test, scratch only).

const DEFAULT_OUT := "res://data/models_r3/"
const TRI_BUDGET := 70000
const MIN_GAP := 0.26
const BAND_PARTS := [[1, 5, 4, 12], [6, 15, 8, 16], [16, 30, 12, 24], [31, 50, 18, 40], [51, 70, 20, 240]]   # Fab: block structures are 25-100 cubes + straps

var _fails: int = 0
var _out_dir: String = DEFAULT_OUT
var _legacy: bool = false
var _overlaps_only: bool = false


func _ready() -> void:
	var ids: Array[String] = []
	for a in OS.get_cmdline_user_args():
		if a == "--legacy":
			_legacy = true
		elif a == "--overlaps":
			_overlaps_only = true
		elif a.begins_with("--out="):
			_out_dir = a.substr(6)
		elif not a.begins_with("--"):
			ids.append(a)
	if not _out_dir.ends_with("/"):
		_out_dir += "/"
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(_out_dir))
	var all: Array[String] = LegacyDefs.ORDER.duplicate() if _legacy else Levels.CATALOG.duplicate()
	for id in all:
		if ids.is_empty() or id in ids:
			_make(id)
	print("RESULT PASS" if _fails == 0 else "RESULT FAIL n=%d" % _fails)
	get_tree().quit(0 if _fails == 0 else 1)


## Loads one definition and returns the raw model (parts p0..pN, centred) or {}.
func _define(id: String) -> Dictionary:
	if _legacy:
		return _legacy_model(id)
	var path: String = "res://tools/models/defs/%s.gd" % id
	if not ResourceLoader.exists(path):
		print("MODEL %s FAIL no def file %s" % [id, path])
		return {}
	var script: GDScript = load(path)
	var k := ModelKit.new()
	script.define(k)
	return k.to_model(id)


func _make(id: String) -> void:
	var raw: Dictionary = _define(id)
	if raw.is_empty():
		_fails += 1
		return
	var parts: Array = raw["parts"]
	for i in parts.size():
		(parts[i] as Dictionary)["id"] = "p%d" % i
	if _overlaps_only:
		var ovs: Array[Dictionary] = OverlapCheck.find(JSON.parse_string(_j(raw)))
		for ov: Dictionary in ovs:
			print("OVERLAP %s %s %s %.3f" % [id, ov["a"], ov["b"], ov["depth"]])
		print("OVERLAPS %s pairs=%d" % [id, ovs.size()])
		_fails += 1 if not ovs.is_empty() else 0
		return
	var t0: int = Time.get_ticks_msec()
	raw = JSON.parse_string(_j(raw))  # same 0.001 rounding the file gets, so the oracle sees what the generator saw
	var lv: int = Levels.CATALOG.find(id) + 1
	if lv >= 4 and not _legacy and not id.begins_with("blk_"):
		# item 14: service caps that hide 2-3 heads each (honest geometry hides almost none); block structures hide
		# heads by their layers (Screwdom style) and get no caps
		var pass1: Dictionary = SocketGen.generate(JSON.parse_string(_j(raw)))
		var added: int = 0
		var want: int = HoodGen.wanted(int(Levels.PLAN_R3[lv - 1][0]))
		if lv <= 5:
			want = mini(want, 4)   # hand-made opening (round 5): a few clear caps that teach the rule, not a crowd
		for k_try: float in [1.0, 0.85, 0.7]:  # small models (lantern, toy robot) have no flat spot for a full-size hood
			HoodGen.size_k = k_try
			added += HoodGen.add(raw, pass1, want - added)
			raw = JSON.parse_string(_j(raw))
			if added > 0 and (lv > 5 or added >= want):
				break
		HoodGen.size_k = 1.0
		raw = JSON.parse_string(_j(raw))
		print("HOODS %s +%d" % [id, added])
	var model: Dictionary = SocketGen.generate(raw)
	if id.begins_with("blk_"):
		# a strap or washer whose every hole was rejected holds nothing and hangs in the air: remove it and generate again
		for _round in 2:
			var held: Dictionary = {}
			for part: Dictionary in model["parts"]:
				for pl: Array in part["pin"]:
					for q: Variant in pl:
						held[q] = true
			var keep: Array = []
			for part: Dictionary in raw["parts"]:
				if part.has("anchors") and String(part["shape"]) != "box" and not part.get("cube", false) and not held.has(part["id"]):
					continue
				keep.append(part)
			if keep.size() == (raw["parts"] as Array).size():
				break
			print("NOTE %s: removed %d straps that no hole could hold" % [id, (raw["parts"] as Array).size() - keep.size()])
			raw["parts"] = keep
			raw = JSON.parse_string(_j(raw))
			model = SocketGen.generate(raw)
	var notes: Array = model["_notes"]
	model.erase("_notes")
	_write(id, model)
	var back: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_out_dir + id + ".json"))
	# a socket the oracle rejects after the file rounding is dropped (one pass), so the file is always self-consistent
	var dropped: Dictionary = {}
	for line in SocketGen.verify(back):
		var head: String = line.get_slice(":", 0)   # "p3/4"
		if head.contains("/"):
			dropped[head] = true
	if not dropped.is_empty():
		for part: Dictionary in model["parts"]:
			var keep: Array[int] = []
			for i in (part["sockets"] as Array).size():
				if not dropped.has("%s/%d" % [part["id"], i]):
					keep.append(i)
			if keep.size() != (part["sockets"] as Array).size():
				for key in ["sockets", "cover", "pin", "group", "role"]:
					if part.has(key):
						var src: Array = part[key]
						var dst: Array = []
						for i in keep:
							dst.append(src[i])
						part[key] = dst
		print("NOTE %s: dropped %d sockets the oracle rejected" % [id, dropped.size()])
		_write(id, model)
		back = JSON.parse_string(FileAccess.get_file_as_string(_out_dir + id + ".json"))
	var problems: Array[String] = _gates(id, model)
	for line in SocketGen.verify(back):
		problems.append("oracle: " + line)
	if "-v" in OS.get_cmdline_user_args() or not problems.is_empty():
		for n in notes:
			print("  ", n)
	var total: int = 0
	var covered: int = 0
	for part: Dictionary in model["parts"]:
		for c: Array in part["cover"]:
			total += 1
			if not c.is_empty():
				covered += 1
	var tag: String = "PASS" if problems.is_empty() else "FAIL " + "; ".join(problems.slice(0, 6))
	if not problems.is_empty():
		_fails += 1
	print("MODEL %s parts=%d sockets=%d covered=%d%% tris=%d %ds %s" % [id, parts.size(), total,
		(100 * covered / maxi(total, 1)), _tris(model), (Time.get_ticks_msec() - t0) / 1000, tag])


# ------------------------------------------------------------------ gates (COMMON 6)

func _gates(id: String, model: Dictionary) -> Array[String]:
	var bad: Array[String] = []
	var parts: Array = model["parts"]
	var level: int = Levels.CATALOG.find(id) + 1
	if level > 0:
		for band: Array in BAND_PARTS:
			if id.begins_with("blk_"):
				break   # a cube structure's part count is its cubes + straps (Screwdom logic: 30-250 parts at any level)
			if level >= band[0] and level <= band[1] and (parts.size() < band[2] or parts.size() > band[3] + 8):
				bad.append("parts %d not in %d-%d for L%d" % [parts.size(), band[2], band[3], level])
	var total: int = 0
	var with_sockets: int = 0
	var all_pos: Array[Vector3] = []
	var pinned: Dictionary = {}
	for part: Dictionary in parts:
		var socks: Array = part["sockets"]
		total += socks.size()
		if not socks.is_empty():
			with_sockets += 1
		for s: Array in socks:
			all_pos.append(Vector3(s[0], s[1], s[2]))
		for pl: Array in part["pin"]:
			for q: Variant in pl:
				pinned[q] = true
	if level > 0:
		var need: int = int(ceil(float(Levels.PLAN_R3[level - 1][0]) * 1.2))  # lane 25: was x2 (unreachable on real meshes, see CONTRACT NOTES)
		if total < need:
			# round Fab: pattern sockets are fewer than free-grid sockets; the level generator lowers the screw count
			print("NOTE %s: sockets %d < 1.2 x planned screws %d (level %d takes fewer screws)" % [id, total, need, level])
		if total < 6:
			bad.append("sockets %d < 6" % total)
	if level > 0:
		var covered_n: int = 0
		for part: Dictionary in parts:
			for c: Array in part["cover"]:
				if not c.is_empty():
					covered_n += 1
		# item 14: a covered socket is a head NO orbit camera can see (closed wells, pockets, deep nooks). Honest models
		# have few; the share is a design target, not a gate: the level generator takes what the model offers
		# and the casual-player band decides whether the level is hard enough.
		if covered_n < 2 and level >= 4:
			print("NOTE %s: only %d covered (hidden) sockets" % [id, covered_n])
	if with_sockets * 2 < parts.size() and not id.begins_with("blk_"):   # block cubes under straps carry no head of their own
		bad.append("only %d of %d parts have sockets" % [with_sockets, parts.size()])
	for part: Dictionary in parts:
		if not pinned.has(part["id"]):
			bad.append("%s is pinned by no socket" % part["id"])
	if not (SocketGen._stuck(parts) as Dictionary).is_empty():
		bad.append("cover cycle remains")
	var tris: int = _tris(model)
	if tris > TRI_BUDGET:
		bad.append("triangles %d > %d" % [tris, TRI_BUDGET])
	for i in all_pos.size():
		for j in range(i + 1, all_pos.size()):
			if all_pos[i].distance_to(all_pos[j]) < MIN_GAP:
				bad.append("heads %d and %d only %.2f apart" % [i, j, all_pos[i].distance_to(all_pos[j])])
				break
		if bad.size() > 8:
			break
	for ov: Dictionary in OverlapCheck.find(model).slice(0, 4):
		bad.append("overlap %s/%s depth %.3f" % [ov["a"], ov["b"], ov["depth"]])
	var size: Vector3 = _bounds(model).size
	var longest: float = maxf(size.x, maxf(size.y, size.z))
	if id.begins_with("blk_"):
		# a cube structure is as wide as its grid (3-7 cells x 0.85): the view fits it (GameView frame_scale 0.5-1.5)
		if longest < 1.5 or longest > 6.5:
			bad.append("longest side %.2f not in 1.5-6.5 (blocks)" % longest)
	elif not _legacy and (longest < 2.95 or longest > 4.65):
		bad.append("longest side %.2f not in 3.0-4.6" % longest)
	return bad


func _tris(model: Dictionary) -> int:
	var n: int = 0
	for part: Dictionary in model["parts"]:
		n += ModelBuilder.make_part_mesh(part).get_faces().size() / 3
	return n


func _bounds(model: Dictionary) -> AABB:
	var lo := Vector3(1e9, 1e9, 1e9)
	var hi := -lo
	for part: Dictionary in model["parts"]:
		var xf: Transform3D = ModelBuilder.part_transform(part)
		var bb: AABB = ModelBuilder.make_part_mesh(part).get_aabb()
		for k in 8:
			var q: Vector3 = xf * bb.get_endpoint(k)
			lo = lo.min(q)
			hi = hi.max(q)
	return AABB(lo, hi - lo)


# ------------------------------------------------------------------ legacy definitions

func _legacy_model(id: String) -> Dictionary:
	var d: Dictionary = LegacyDefs.define(id)
	var parts: Array = d["parts"]
	var dets: Array = d["dets"]
	var model := {"id": id, "name_key": "MODEL_" + id, "parts": parts}
	var shift: Vector3 = _bounds(model).get_center()
	for p: Dictionary in parts:
		var pos: Array = p["pos"]
		p["pos"] = [snappedf(pos[0] - shift.x, 0.001), snappedf(pos[1] - shift.y, 0.001), snappedf(pos[2] - shift.z, 0.001)]
	for det: Dictionary in dets:
		var p2: Dictionary = parts[int(det["part"])]
		var dp: Array = det["p"]
		var dr: Array = det["r"]
		var wx := Transform3D(Basis.from_euler(Vector3(deg_to_rad(dr[0]), deg_to_rad(dr[1]), deg_to_rad(dr[2])), EULER_ORDER_YXZ),
			Vector3(dp[0] - shift.x, dp[1] - shift.y, dp[2] - shift.z))
		var loc: Transform3D = ModelBuilder.part_transform(p2).affine_inverse() * wx
		var e: Vector3 = loc.basis.get_euler(EULER_ORDER_YXZ)
		if not p2.has("details"):
			p2["details"] = []
		(p2["details"] as Array).append({"k": det["k"], "p": [loc.origin.x, loc.origin.y, loc.origin.z], "s": det["s"],
			"r": [rad_to_deg(e.x), rad_to_deg(e.y), rad_to_deg(e.z)], "c": det["c"]})
	return model


# ------------------------------------------------------------------ output

static func _f(x: float) -> String:
	var v: float = snappedf(x, 0.001)
	if absf(v) < 0.0005:
		v = 0.0
	var s: String = "%.3f" % v
	while s.ends_with("0") and not s.ends_with(".0"):
		s = s.substr(0, s.length() - 1)
	return s


## Compact deterministic JSON (sorted keys, floats at 3 decimals).
static func _j(v: Variant) -> String:
	match typeof(v):
		TYPE_DICTIONARY:
			var keys: Array = (v as Dictionary).keys()
			keys.sort()
			var items: Array[String] = []
			for k in keys:
				items.append('"%s": %s' % [k, _j(v[k])])
			return "{" + ", ".join(items) + "}"
		TYPE_ARRAY:
			var items2: Array[String] = []
			for x: Variant in v:
				items2.append(_j(x))
			return "[" + ", ".join(items2) + "]"
		TYPE_PACKED_FLOAT32_ARRAY, TYPE_PACKED_FLOAT64_ARRAY, TYPE_PACKED_INT32_ARRAY:
			return _j(Array(v))
		TYPE_STRING, TYPE_STRING_NAME:
			return '"%s"' % String(v).replace('"', '\\"')
		TYPE_FLOAT:
			return _f(v)
		TYPE_BOOL:
			return "true" if v else "false"
		TYPE_VECTOR2:
			return _j([v.x, v.y])
		TYPE_VECTOR3:
			return _j([v.x, v.y, v.z])
	return str(v)


func _write(id: String, model: Dictionary) -> void:
	var lines: Array[String] = []
	for part: Dictionary in model["parts"]:
		lines.append("    " + _j(part))
	var text: String = '{\n  "id": "%s",\n  "name_key": "MODEL_%s",\n  "parts": [\n%s\n  ]\n}\n' % [id, id, ",\n".join(lines)]
	var f := FileAccess.open(_out_dir + id + ".json", FileAccess.WRITE)
	f.store_string(text)
	f.close()
