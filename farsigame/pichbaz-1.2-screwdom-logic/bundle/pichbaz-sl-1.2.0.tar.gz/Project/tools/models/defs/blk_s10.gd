extends RefCounted
## blk_s10 — Screwdom-logic cube level (v2): castle: walls, gate and four towers. 83 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["#####", "#####", "#####", "#####", "#####"],
		["#####", "#...#", "#...#", "#...#", "##.##"],
		["#####", "#...#", "#...#", "#...#", "##.##"],
		["#####", "#...#", "#...#", "#...#", "#####"],
		["#.#.#", ".....", "#...#", ".....", "#.#.#"],
		["#...#", ".....", ".....", ".....", "#...#"],
	], {"seed": 20, "holes": 156, "hidden": 0.35})
