extends RefCounted
## blk_s01 — Screwdom-logic cube level (v2): first box: nine cubes in a square, the tutorial (tap, box). 9 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["###", "###", "###"],
	], {"seed": 11, "holes": 18, "hidden": 0.0})
