extends RefCounted
## blk_s04 — Screwdom-logic cube level (v2): 3x3x3 cube. 27 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["###", "###", "###"],
		["###", "###", "###"],
		["###", "###", "###"],
	], {"seed": 14, "holes": 54, "hidden": 0.35})
