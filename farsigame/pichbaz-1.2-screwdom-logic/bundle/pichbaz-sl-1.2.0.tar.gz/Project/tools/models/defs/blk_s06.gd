extends RefCounted
## blk_s06 — Screwdom-logic cube level (v2): tower with battlements. 38 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["###", "###", "###"],
		["###", "###", "###"],
		["###", "#.#", "###"],
		["###", "#.#", "###"],
		["#.#", "...", "#.#"],
	], {"seed": 16, "holes": 84, "hidden": 0.35})
