extends RefCounted
## blk_s09 — Screwdom-logic cube level (v2): dog. 78 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		[".#...#.", ".#...#.", ".#...#."],
		[".#...#.", ".#...#.", ".#...#."],
		[".#####.", ".#####.", ".#####."],
		["#######", "#######", "#######"],
		["#######", "#######", "#######"],
		["##...#.", "##...#.", "##...#."],
	], {"seed": 19, "holes": 129, "hidden": 0.35})
