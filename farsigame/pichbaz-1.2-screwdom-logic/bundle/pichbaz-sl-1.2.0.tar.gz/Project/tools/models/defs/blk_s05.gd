extends RefCounted
## blk_s05 — Screwdom-logic cube level (v2): open frame box 4x4x3 (Screwdom's first cube level). 40 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["####", "####", "####", "####"],
		["####", "#..#", "#..#", "####"],
		["####", "#..#", "#..#", "####"],
	], {"seed": 15, "holes": 78, "hidden": 0.35})
