extends RefCounted
## blk_s02 — Screwdom-logic cube level (v2): stairs: three steps, two wide; the dock lesson. 12 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["##", "##", "##"],
		["##", "##", ".."],
		["##", "..", ".."],
	], {"seed": 12, "holes": 24, "hidden": 0.0})
