extends RefCounted
## Screwdom-logic cube structures, v2 (2026-10-08, cloud session FarsiGamecloud2; Docs/design/SCREWDOM_LOGIC.md).
## Measured on 60 Screwdom cube levels: 33-158 cubes on a 1-unit grid, 78-228 screws, 0.8 planks per cube, 2.5 screws
## per plank, 98.6 % of cube faces carry at most ONE screw, 35 % of the screws sit under a neighbouring cube.
## Rules here:
##   1. every screw is on a strap (no bare cube heads); a strap hole sits at the centre of a cube face;
##   2. one strap cell per cube face;
##   3. a strap running along the TOP of a row may continue under a cube standing on that row: that hole is HIDDEN. The
##      covering cube gets a blind hole in its bottom (two stacked slabs in one part) so the head is truly invisible from
##      every camera (owner's rule: a hidden screw is not seen until the cube above it has fallen) and the geometry oracle
##      (MeshRays) agrees; the hole appears when the cube above falls;
##   4. every cube is held by at least one hole; the total number of holes is a multiple of 3; the level screws EVERY hole
##      (`all_holes` flag read by LevelGen), as Screwdom does.
## Layers are lists of row strings, bottom layer first, rows back (-z) to front (+z), columns left (-x) to right (+x);
## '#' = cube, '.' = air (no merged blocks here: a Screwdom structure is 1x1 cubes only).

const PITCH := 0.85          # grid step; cube = PITCH - GAP (head radius 0.12 reads as ~30 % of a cube, as in Screwdom)
const GAP := 0.08            # air between cubes (a strap of STRAP_T fits in it)
const STRAP_T := 0.05
const LIFT := 0.006          # a strap floats this much above the face (the overlap gate allows 0.02)
const HOLE_R := 0.19         # blind hole in a covering cube's bottom (head radius 0.12 + clearance 0.03 + margin)
const ROUND := 0.06          # vertical edge rounding of a cube
const TONES: Array[String] = ["#F2BE7E", "#EDB574", "#E8AD6B", "#E2A564"]
const STRAP_COLORS: Array[String] = ["#A8CBA3", "#EEAAB8", "#BCAAE0", "#9CCCF0", "#9AD6CB", "#F4B39A", "#C9B8E8", "#F2AF9C"]

# normal, in-plane u, in-plane v, euler (x, y)
const FACES := {
	"+z": [Vector3i(0, 0, 1), Vector3i(1, 0, 0), Vector3i(0, 1, 0), Vector2(0, 0)],
	"-z": [Vector3i(0, 0, -1), Vector3i(1, 0, 0), Vector3i(0, 1, 0), Vector2(0, 180)],
	"+x": [Vector3i(1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 1, 0), Vector2(0, 90)],
	"-x": [Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 1, 0), Vector2(0, -90)],
	"+y": [Vector3i(0, 1, 0), Vector3i(1, 0, 0), Vector3i(0, 0, 1), Vector2(-90, 0)],
}
const UP := Vector3i(0, 1, 0)

## Strap catalogue weights (Screwdom plank frequency): edge-bent L over a cube edge is the most common piece.
const KINDS_DEFAULT := {"edge2": 40, "edge3": 14, "i3": 14, "i2": 12, "l": 8, "sq": 9, "t": 3, "plus": 3, "pad": 3}

static var _gap: float = GAP
static var _pitch: float = PITCH


static func parse(layers: Array) -> Dictionary:
	var cells := {}
	for y in layers.size():
		var rows: Array = layers[y]
		for z in rows.size():
			var row: String = rows[z]
			for x in row.length():
				if row[x] == "#":
					cells[Vector3i(x, y, z)] = true
	return cells


## opt: seed, holes (target hole count, rounded up to a multiple of 3), hidden (share of holes that may be hidden, 0..0.5),
##      kinds (weights), colors (strap colours), target (model longest side), fully_hidden (a strap may lie entirely under cubes)
static func make(k: ModelKit, layers: Array, opt: Dictionary = {}) -> void:
	var cells := parse(layers)
	var lo := Vector3i(99, 99, 99)
	var hi := Vector3i(-99, -99, -99)
	for c: Vector3i in cells:
		lo = Vector3i(mini(lo.x, c.x), mini(lo.y, c.y), mini(lo.z, c.z))
		hi = Vector3i(maxi(hi.x, c.x), maxi(hi.y, c.y), maxi(hi.z, c.z))
	var ext := hi - lo + Vector3i.ONE
	var mx := maxi(ext.x, maxi(ext.y, ext.z))
	_pitch = float(opt.get("pitch", PITCH))
	_gap = float(opt.get("gap", GAP))
	k.target = float(opt.get("target", float(mx) * _pitch - _gap))
	var origin := Vector3(lo)
	var cube := _pitch - _gap
	var rng := RandomNumberGenerator.new()
	rng.seed = int(opt.get("seed", 1))
	var want: int = int(opt.get("holes", roundi(float(cells.size()) * 1.9)))
	want = int(ceil(float(want) / 3.0)) * 3
	var hidden_budget: int = roundi(float(want) * float(opt.get("hidden", 0.3)))
	var state := {"cells": cells, "used": {}, "hidden": {}, "holes": 0, "n_hidden": 0, "hidden_budget": hidden_budget,
		"pitch": _pitch, "origin": origin, "rng": rng, "cols": opt.get("colors", STRAP_COLORS), "placed": 0,
		"fully_hidden": bool(opt.get("fully_hidden", true)), "pads": []}
	_straps(k, state, want, opt.get("kinds", KINDS_DEFAULT))
	_hold_everyone(k, state)
	_fix_remainder(k, state)
	# cubes: wood, one part each; a cube standing on a hidden hole gets a blind hole in its bottom
	var cell_list: Array = cells.keys()
	cell_list.sort_custom(func(a: Vector3i, b: Vector3i) -> bool: return [a.y, a.z, a.x] < [b.y, b.z, b.x])
	var n := 0
	var h := cube * 0.5
	var sq: Array = [Vector2(-h, -h), Vector2(h, -h), Vector2(h, h), Vector2(-h, h)]
	for c: Vector3i in cell_list:
		var ctr := (Vector3(c) - origin) * _pitch
		var tone: String = TONES[(n * 7 + c.x * 3 + c.y * 5 + c.z * 2) % TONES.size()]
		n += 1
		var style := {"rot": Vector3(90, 0, 0), "round": ROUND, "bevel": 0.0, "pattern": "wood", "pattern_scale": 1.35,
			"pattern_mix": 0.9, "anchors": [], "cube": true}
		if (state["hidden"] as Dictionary).has(c - UP):
			# bottom slab with the blind hole (local +Z points down), top slab baked on as a detail: one closed part
			var st := style.duplicate()
			st["holes"] = [ModelKit.circle(HOLE_R, 20)]
			var idx := k.extrude(sq, cube * 0.5, ctr + Vector3(0, -cube * 0.25, 0), tone, st)
			k.detail_extrude(idx, sq, cube * 0.5, Vector3(0, 0, -cube * 0.5), tone,
				{"round": ROUND, "bevel": 0.0, "pattern": "wood", "pattern_scale": 1.35, "pattern_mix": 0.9})
		else:
			k.extrude(sq, cube, ctr, tone, style)


# ------------------------------------------------------------------ straps

static func _straps(k: ModelKit, st: Dictionary, want: int, kinds_in: Dictionary) -> void:
	var rng: RandomNumberGenerator = st["rng"]
	var cells: Dictionary = st["cells"]
	var kinds: Dictionary = {}
	for key: String in kinds_in:
		kinds[key] = int(kinds_in[key])
	var faces: Array = FACES.keys()
	var cell_list: Array = cells.keys()
	cell_list.sort_custom(func(a: Vector3i, b: Vector3i) -> bool: return [a.y, a.z, a.x] < [b.y, b.z, b.x])
	# pass 1 (Screwdom layers): flat straps that run under a cube standing on the row, until the hidden budget is spent;
	# the cells with a cube above are tried in random order, each with a few random flat kinds
	var under: Array = []
	for c: Vector3i in cell_list:
		if cells.has(c + UP):
			under.append(c)
	for i in range(under.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var t: Variant = under[i]
		under[i] = under[j]
		under[j] = t
	var flat: Array = ["i2", "i3", "l", "sq", "i2", "i3", "t", "plus"]
	for c: Vector3i in under:
		if int(st["n_hidden"]) >= int(st["hidden_budget"]) or int(st["holes"]) >= want:
			break
		if (st["used"] as Dictionary).has("+y|%s" % c):
			continue
		for attempt in 6:
			var kind: String = flat[rng.randi() % flat.size()]
			var col: String = (st["cols"] as Array)[(int(st["placed"]) + rng.randi() % 2) % (st["cols"] as Array).size()]
			if _place(k, st, "+y", c, kind, col):
				st["placed"] = int(st["placed"]) + 1
				break
	# pass 2: everything else at random, Screwdom's catalogue weights
	var tries := 0
	while int(st["holes"]) < want and tries < want * 160:
		tries += 1
		var face: String = faces[rng.randi() % faces.size()]
		var c: Vector3i = cell_list[rng.randi() % cell_list.size()]
		var kind := _pick(rng, kinds)
		if kind == "pad" and int(st["holes"]) + 1 > want:
			continue
		if not _free(st, c, face, kind != "edge2" and kind != "edge3" and kind != "pad"):
			continue
		var col: String = (st["cols"] as Array)[(int(st["placed"]) + rng.randi() % 2) % (st["cols"] as Array).size()]
		if _place(k, st, face, c, kind, col):
			st["placed"] = int(st["placed"]) + 1


## A strap cell is free on `face` of `c` when the cube exists, nothing lies there yet, and either the face is exposed and
## looks out of the structure, or (flat straps only) the face is the top of `c` under another cube: a hidden hole.
static func _free(st: Dictionary, c: Vector3i, face: String, allow_hidden: bool) -> bool:
	var cells: Dictionary = st["cells"]
	if not cells.has(c) or (st["used"] as Dictionary).has("%s|%s" % [face, c]):
		return false
	var nb: Vector3i = c + (FACES[face][0] as Vector3i)
	if not cells.has(nb):
		return _open(cells, c, face)
	return allow_hidden and face == "+y" and int(st["n_hidden"]) < int(st["hidden_budget"])


static func _exposed(cells: Dictionary, c: Vector3i, face: String) -> bool:
	return cells.has(c) and not cells.has(c + (FACES[face][0] as Vector3i))


## True when the face looks out of the structure (walking along its normal meets no other cube within 12 cells).
static func _open(cells: Dictionary, c: Vector3i, face: String) -> bool:
	var d: Vector3i = FACES[face][0]
	for i in range(1, 12):
		if cells.has(c + d * i):
			return false
	return true


static func _is_hidden(st: Dictionary, c: Vector3i, face: String) -> bool:
	return face == "+y" and (st["cells"] as Dictionary).has(c + UP)


static func _pick(rng: RandomNumberGenerator, w: Dictionary) -> String:
	var total := 0
	for key: String in w:
		total += int(w[key])
	var r := rng.randi() % maxi(total, 1)
	for key: String in w:
		r -= int(w[key])
		if r < 0:
			return key
	return "i2"


## Walks up to `n` cells from c along dir on `face`; returns the usable cells.
static func _run(st: Dictionary, c: Vector3i, dir: Vector3i, n: int, face: String, allow_hidden: bool) -> Array:
	var out: Array = [c]
	for i in range(1, n + 1):
		var nc := c + dir * i
		if not _free(st, nc, face, allow_hidden):
			break
		out.append(nc)
	return out


## A flat strap over `cells_on` (same face) is acceptable when its hidden cells fit the budget and (unless fully_hidden)
## at least one cell shows.
static func _hidden_ok(st: Dictionary, cells_on: Array, face: String) -> bool:
	var h := 0
	for c: Vector3i in cells_on:
		if _is_hidden(st, c, face):
			h += 1
	if h == 0:
		return true
	if int(st["n_hidden"]) + h > int(st["hidden_budget"]):
		return false
	return bool(st["fully_hidden"]) or h < cells_on.size()


## Hole on the TOP face of a strap over cell `c` of face `face`.
static func _hole(c: Vector3, face: String, st: Dictionary, role: int) -> Array:
	var nrm := Vector3(FACES[face][0] as Vector3i)
	var p := (c - (st["origin"] as Vector3)) * _pitch + nrm * (_pitch * 0.5 - _gap * 0.5 + LIFT + STRAP_T - 0.012)
	return [p.x, p.y, p.z, nrm.x, nrm.y, nrm.z, role]


static func _holes(run: Array, face: String, st: Dictionary, ends: Array) -> Array:
	var out: Array = []
	for c: Vector3i in run:
		out.append(_hole(Vector3(c), face, st, 0 if c in ends else 1))
	return out


static func _mark(st: Dictionary, face: String, run: Array) -> void:
	for cell: Vector3i in run:
		(st["used"] as Dictionary)["%s|%s" % [face, cell]] = true
		if _is_hidden(st, cell, face):
			(st["hidden"] as Dictionary)[cell] = true
			st["n_hidden"] = int(st["n_hidden"]) + 1
	st["holes"] = int(st["holes"]) + run.size()


static func _style(width: float) -> Dictionary:
	return {"metal": 0.0, "round": minf(width * 0.4, 0.1), "all_holes": true}


static func _place(k: ModelKit, st: Dictionary, face: String, c: Vector3i, kind: String, col: String) -> bool:
	var rng: RandomNumberGenerator = st["rng"]
	var f: Array = FACES[face]
	var nrm: Vector3i = f[0]
	var u: Vector3i = f[1]
	var v: Vector3i = f[2]
	var du: Vector3i = u if rng.randi() % 2 == 0 else -u
	var dv: Vector3i = v if rng.randi() % 2 == 0 else -v
	var width := clampf(_pitch * 0.5, 0.36, 0.5)   # >= 0.36: head ring (r 0.138) + bevel must sit on the flat top
	var style := _style(width)
	match kind:
		"i2", "i3":
			var d: Vector3i = du if rng.randi() % 2 == 0 else dv
			var n_cells: int = 2 if kind == "i2" else 3
			var r := _run(st, c, d, n_cells - 1, face, true)
			if r.size() < n_cells or not _hidden_ok(st, r, face):
				return false
			return _emit_line(k, st, face, r, col, width)
		"plus":
			var rx := _run(st, c, du, 1, face, true)
			var rx2 := _run(st, c, -du, 1, face, true)
			var ry := _run(st, c, dv, 1, face, true)
			var ry2 := _run(st, c, -dv, 1, face, true)
			if rx.size() < 2 or rx2.size() < 2 or ry.size() < 2 or ry2.size() < 2:
				return false
			var all: Array = [c, rx[1], rx2[1], ry[1], ry2[1]]
			if not _hidden_ok(st, all, face):
				return false
			var lx := 2.0 * _pitch + 0.72 * _pitch
			style["anchors"] = _holes(all, face, st, [rx[1], rx2[1], ry[1], ry2[1]])
			style["rot"] = _rot(f, 0.0)
			k.strap_cross(lx, lx, width, STRAP_T, _strap_pos(Vector3(c), nrm, st), col, style)
			_mark(st, face, all)
			return true
		"l":
			var r1 := _run(st, c, du, 1, face, true)
			var r2 := _run(st, c, dv, 1, face, true)
			if r1.size() < 2 or r2.size() < 2:
				return false
			var all: Array = [c, r1[1], r2[1]]
			if not _hidden_ok(st, all, face):
				return false
			var a := _pitch + 0.36 * _pitch
			var roll := _roll_for(f, du, dv)
			if roll < 0.0:
				return false
			style["anchors"] = _holes(all, face, st, all)
			style["rot"] = _rot(f, roll)
			k.strap_l(a, a, width, STRAP_T, _strap_pos(Vector3(c), nrm, st), col, style)
			_mark(st, face, all)
			return true
		"t":
			var bl := _run(st, c, du, 1, face, true)
			var br := _run(st, c, -du, 1, face, true)
			var stem := _run(st, c, dv, 1, face, true)
			if bl.size() < 2 or br.size() < 2 or stem.size() < 2:
				return false
			var all: Array = [c, bl[1], br[1], stem[1]]
			if not _hidden_ok(st, all, face):
				return false
			var bar := 2.0 * _pitch + 0.72 * _pitch
			var stem_l := _pitch + 0.36 * _pitch
			var roll := _roll_for_t(f, du, dv)
			if roll < 0.0:
				return false
			style["anchors"] = _holes(all, face, st, [bl[1], br[1], stem[1]])
			style["rot"] = _rot(f, roll)
			k.strap_t(bar, stem_l, width, STRAP_T, _strap_pos(Vector3(c), nrm, st), col, style)
			_mark(st, face, all)
			return true
		"sq":
			var all: Array = [c, c + du, c + dv, c + du + dv]
			for cell: Vector3i in all:
				if not _free(st, cell, face, true):
					return false
			if not _hidden_ok(st, all, face):
				return false
			var cen := Vector3(c) + (Vector3(du) + Vector3(dv)) * 0.5
			var s := _pitch - 0.14 * _pitch
			var outline: Array = [Vector2(-s, -s), Vector2(s, -s), Vector2(s, s), Vector2(-s, s)]
			style["anchors"] = _holes(all, face, st, all)
			style["rot"] = _rot(f, 0.0)
			style["round"] = 0.14
			k.extrude(outline, STRAP_T, _strap_pos(cen, nrm, st), col, style)
			_mark(st, face, all)
			return true
		"pad":
			if not _exposed(st["cells"], c, face):
				return false
			return _pad(k, st, face, c, col)
		"edge2", "edge3":
			return _edge_strap(k, st, face, c, kind, col, width)
	return false


static func _pad(k: ModelKit, st: Dictionary, face: String, c: Vector3i, col: String) -> bool:
	var f: Array = FACES[face]
	var nrm: Vector3i = f[0]
	var pr := clampf(_pitch * 0.3, 0.22, 0.34)
	var rot := Vector3(0, 0, 0)
	match face:
		"+z": rot = Vector3(90, 0, 0)
		"-z": rot = Vector3(-90, 0, 0)
		"+x": rot = Vector3(0, 0, -90)
		"-x": rot = Vector3(0, 0, 90)
	var idx := k.cyl(pr, STRAP_T, _strap_pos(Vector3(c), nrm, st), col,
		{"metal": 0.0, "rot": rot, "anchors": [_hole(Vector3(c), face, st, 0)], "all_holes": true})
	(st["pads"] as Array).append(idx)
	_mark(st, face, [c])
	return true


## Strap bent over a cube edge (Screwdom "2D L"): arm A lies on `fa`, arm B on a perpendicular exposed face of the same
## cell. One extrude whose outline is the angle profile, pushed along the edge by `width`. One hole per covered cell.
static func _edge_strap(k: ModelKit, st: Dictionary, fa: String, c: Vector3i, kind: String, col: String, width: float) -> bool:
	var rng: RandomNumberGenerator = st["rng"]
	var cells: Dictionary = st["cells"]
	var na: Vector3i = FACES[fa][0]
	if not _exposed(cells, c, fa):
		return false
	var others: Array = []
	for fb: String in FACES:
		var nb: Vector3i = FACES[fb][0]
		if nb == na or nb == -na:
			continue
		if _free(st, c, fb, false):
			others.append(fb)
	if others.is_empty():
		return false
	var fb: String = others[rng.randi() % others.size()]
	var nb: Vector3i = FACES[fb][0]
	var la: int = 1
	var lb: int = 1
	if kind == "edge3":
		if rng.randi() % 2 == 0:
			la = 2
		else:
			lb = 2
	var ra := _run(st, c, -nb, la - 1, fa, false)   # arm A runs along face A away from the edge
	var rb := _run(st, c, -na, lb - 1, fb, false)
	if ra.size() < la or rb.size() < lb:
		return false
	var h := _pitch * 0.5 - _gap * 0.5 + LIFT   # a hair above the faces
	var t := STRAP_T
	var a := (float(la) - 0.1) * _pitch
	var b := (float(lb) - 0.1) * _pitch
	var outline: Array = [Vector2(h, h - a), Vector2(h + t, h - a), Vector2(h + t, h + t), Vector2(h - b, h + t),
		Vector2(h - b, h), Vector2(h, h)]
	var ax := Vector3(na)
	var ay := Vector3(nb)
	var az := ax.cross(ay)
	var basis := Basis(ax, ay, az)
	var e := basis.get_euler(EULER_ORDER_YXZ) * (180.0 / PI)
	var cc := (Vector3(c) - (st["origin"] as Vector3)) * _pitch
	var anchors: Array = []
	for j in la:
		var p := cc + ax * (h + t - 0.012) + ay * (-float(j) * _pitch)
		anchors.append([p.x, p.y, p.z, ax.x, ax.y, ax.z, 0])
	for j in lb:
		var p2 := cc + ax * (-float(j) * _pitch) + ay * (h + t - 0.012)
		anchors.append([p2.x, p2.y, p2.z, ay.x, ay.y, ay.z, 0])
	# bevel under half the strap thickness, or the cap inset crosses the thin arm and turns the ring inside out
	k.extrude(outline, width, cc, col, {"metal": 0.0, "round": 0.02, "bevel": 0.02, "rot": Vector3(e.x, e.y, e.z),
		"anchors": anchors, "all_holes": true})
	_mark(st, fa, ra)
	_mark(st, fb, rb)
	return true


static func _emit_line(k: ModelKit, st: Dictionary, face: String, r: Array, col: String, width: float) -> bool:
	var f: Array = FACES[face]
	var a: Vector3i = r[0]
	var b: Vector3i = r[r.size() - 1]
	var d := Vector3(b - a)
	var cen := Vector3(a) + d * 0.5
	var len := d.length() * _pitch + 0.72 * _pitch
	var roll := 0.0
	var bx: Basis = _basis(f, 0.0)
	if absf((bx * Vector3.RIGHT).normalized().dot(d.normalized())) < 0.5:
		roll = 90.0
	var style := _style(width)
	style["rot"] = _rot(f, roll)
	style["anchors"] = _holes(r, face, st, [a, b])
	k.strap_line(len, width, STRAP_T, _strap_pos(cen, f[0], st), col, style)
	_mark(st, face, r)
	return true


## Every cube must carry at least one hole (else it is loose at the start): an i2 toward a neighbour first, then a washer.
static func _hold_everyone(k: ModelKit, st: Dictionary) -> void:
	var cells: Dictionary = st["cells"]
	var used: Dictionary = st["used"]
	var rng: RandomNumberGenerator = st["rng"]
	var cell_list: Array = cells.keys()
	cell_list.sort_custom(func(a: Vector3i, b: Vector3i) -> bool: return [a.y, a.z, a.x] < [b.y, b.z, b.x])
	for c: Vector3i in cell_list:
		var held := false
		for face: String in FACES:
			if used.has("%s|%s" % [face, c]):
				held = true
				break
		if held:
			continue
		var col: String = (st["cols"] as Array)[(int(st["placed"]) + rng.randi() % 2) % (st["cols"] as Array).size()]
		var done := false
		# 1. a visible i2 toward a neighbour; 2. a hidden strap on the top while the hidden budget allows it;
		# 3. a visible edge strap; 4. a visible washer; 5. (inner cube, no visible face at all) a hidden strap on its top
		# under the cube above, whatever the budget says: Screwdom's inner layer. A tutorial model (hidden 0) thus never
		# gets a hidden hole unless a cube has no visible face.
		for face: String in ["+y", "+z", "+x", "-x", "-z"]:
			if _free(st, c, face, false) and _place(k, st, face, c, "i2", col):
				done = true
				break
		if not done and cells.has(c + UP) and int(st["n_hidden"]) < int(st["hidden_budget"]):
			for kind: String in ["i2", "i3", "l", "sq"]:
				if _place(k, st, "+y", c, kind, col):
					done = true
					break
		if not done:
			for face: String in ["+y", "+z", "+x", "-x", "-z"]:
				if _free(st, c, face, false) and _place(k, st, face, c, "edge2", col):
					done = true
					break
		if not done:
			for face: String in ["+y", "+z", "+x", "-x", "-z"]:
				if _free(st, c, face, false) and _pad(k, st, face, c, col):
					done = true
					break
		if not done and cells.has(c + UP):
			var saved: int = int(st["hidden_budget"])
			st["hidden_budget"] = 1 << 30
			for kind: String in ["i2", "i3", "l", "sq"]:
				if _place(k, st, "+y", c, kind, col):
					done = true
					break
			st["hidden_budget"] = saved
		if done:
			st["placed"] = int(st["placed"]) + 1
		else:
			push_warning("blocks2: cube %s has no free face for a strap" % str(c))


## Holes come in threes (one box = 3 screws): washers on free visible faces make up the difference.
static func _fix_remainder(k: ModelKit, st: Dictionary) -> void:
	var cells: Dictionary = st["cells"]
	var rng: RandomNumberGenerator = st["rng"]
	var guard := 0
	while int(st["holes"]) % 3 != 0 and guard < 200:
		guard += 1
		var cell_list: Array = cells.keys()
		cell_list.sort_custom(func(a: Vector3i, b: Vector3i) -> bool: return [b.y, b.z, a.x] < [a.y, a.z, b.x])
		var added := false
		for c: Vector3i in cell_list:
			for face: String in ["+y", "+z", "+x", "-x", "-z"]:
				if _free(st, c, face, false):
					var col: String = (st["cols"] as Array)[(int(st["placed"]) + rng.randi() % 2) % (st["cols"] as Array).size()]
					if _pad(k, st, face, c, col):
						st["placed"] = int(st["placed"]) + 1
						added = true
						break
			if added:
				break
		if not added:
			push_warning("blocks2: no free face left to fix the hole count (%d)" % int(st["holes"]))
			return


static func _strap_pos(cen: Vector3, nrm: Vector3i, st: Dictionary) -> Vector3:
	return (cen - (st["origin"] as Vector3)) * _pitch + Vector3(nrm) * (_pitch * 0.5 - _gap * 0.5 + LIFT + STRAP_T * 0.5)


static func _rot(f: Array, roll: float) -> Vector3:
	var e: Vector2 = f[3]
	return Vector3(e.x, e.y, roll)


static func _basis(f: Array, roll: float) -> Basis:
	var r := _rot(f, roll)
	return Basis.from_euler(Vector3(deg_to_rad(r.x), deg_to_rad(r.y), deg_to_rad(r.z)), EULER_ORDER_YXZ)


static func _close(a: Vector3, b: Vector3i) -> bool:
	return a.distance_to(Vector3(b)) < 0.1


## L strap: local +X must point along dx, local +Y along dy.
static func _roll_for(f: Array, dx: Vector3i, dy: Vector3i) -> float:
	for roll: float in [0.0, 90.0, 180.0, 270.0]:
		var b := _basis(f, roll)
		if _close(b * Vector3.RIGHT, dx) and _close(b * Vector3.UP, dy):
			return roll
	return -1.0


## T strap: bar along +-dx, stem (local -Y) toward dy.
static func _roll_for_t(f: Array, dx: Vector3i, dy: Vector3i) -> float:
	for roll: float in [0.0, 90.0, 180.0, 270.0]:
		var b := _basis(f, roll)
		if _close(b * Vector3.DOWN, dy) and absf((b * Vector3.RIGHT).dot(Vector3(dx))) > 0.9:
			return roll
	return -1.0
