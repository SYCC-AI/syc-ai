extends RefCounted
## blk_s03 — Screwdom-logic cube level (v2): base with four pillars: straps on the base run under the pillars (the hidden-screw lesson). 20 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["####", "####", "####"],
		["#..#", "....", "#..#"],
		["#..#", "....", "#..#"],
	], {"seed": 13, "holes": 39, "hidden": 0.3})
