extends RefCounted
## blk_s07 — Screwdom-logic cube level (v2): bridge: two towers and a deck with posts. 46 cubes.
const B := preload("res://tools/models/defs/_blocks2.gd")
static func define(k: ModelKit) -> void:
	B.make(k, [
		["##...##", "##...##"],
		["##...##", "##...##"],
		["##...##", "##...##"],
		["#######", "#######"],
		["#.#.#.#", "#.#.#.#"],
	], {"seed": 17, "holes": 102, "hidden": 0.35})
