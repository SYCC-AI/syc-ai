class_name LevelGen extends RefCounted
## Deterministic level generator (BLUEPRINT 5.5). Tools only, never used at runtime.
## One LevelGen instance holds the socket tables of one model; generate() builds one level.

const LevelsScript := preload("res://scripts/core/levels.gd")
const COLORS: Array[String] = ["red", "blue", "green", "yellow", "purple", "orange", "pink"]
const MIN_SOCKET_GAP: float = 0.26      # two screw heads never overlap on screen
const SEARCH_GAMES: int = 100
const CONFIRM_GAMES: int = 400
## Dock (buffer tray) size per band: smaller tray = harder (owner items 11/13: harder from the start). The generator moves it
## one step (3..5) when the bias alone cannot bring the casual fail rate into the window.
const BAND_DOCK: Dictionary = {"tutorial": 5, "easy": 5, "normal": 4, "hard": 4, "very_hard": 3}
var cur_dock: int = 5
## Round 5 hand-made opening (L1-L5, lane 33): socket preferences so the first view is rich and readable.
##   front: weight of heads facing the start camera (others 1, heads facing away or down nearly never)
##   cover: [min, max] % of covered heads (replaces the band rule), min_on: {part id: heads it must carry},
##   max_part: most heads on one part (a strap with 7 heads looks like a zip), gap: least distance between heads,
##   strap_ends: heads on straps only near their ends (one screw per end, as a real strap is fixed)
const HAND: Dictionary = {
}
## Special edition (Docs/design/SPECIAL_EDITION.md): a rotor part turns in `rotor_steps` states; every socket keeps its
## covering set per state (`blocked_states`, state 0 = the model's cover). Key/lock parts (model flags `key` / `lock`) make
## the lock screws need the key screw. Parts with `min_screws` get at least that many heads in the level.
## Screwdom logic (1.2, Docs/design/SCREWDOM_LOGIC.md): a model whose straps carry `all_holes` screws EVERY hole; the
## level's screw count is the structure's hole count and the casual band is reached with colours, queue and dock only.
var all_holes: bool = false
var rotor_part: int = -1
var rotor_steps: int = 0
var rotor_pid: String = ""
const START_VIEW := Vector3(0.0, 0.423, 0.906)   # start camera direction in model space (pitch 25, yaw 0)
var cur_n: int = 0
var last_forced: int = 0   # screws the pinning step had to take in the last layout (a dense structure leaves little choice)
const BAND_H: Dictionary = {"tutorial": 0.0, "easy": 0.2, "normal": 0.45, "hard": 0.75, "very_hard": 0.95}

var model: Dictionary = {}
var part_ids: Array[String] = []
var sockets: Array[Dictionary] = []   # {part: int, pos: Vector3, normal: Vector3, blocked: Array[String], group: String, role: int}
var by_part: Array = []               # Array of Array[int] socket indices per part
## Round Fab (Screwdom study): sockets come in PATTERNS (group id "<part>:<face>:<pattern>"). A level screws whole
## patterns: both ends of a bar, the 4 corners of a plate, a ring. role 0 = end/corner hole, role 1 = middle/centre.
var by_group: Dictionary = {}         # group id -> Array[int]
const MID_HOLE_CHANCE: float = 0.35   # a bar's middle hole is screwed this often (Screwdom leaves most middles empty)
const MAX_GROUPS_PER_FACE: int = 2
var max_tries: int = 400
var debug: bool = false


func _init(model_dict: Dictionary) -> void:
	model = model_dict
	var parts: Array = model["parts"]
	var rays: MeshRays = MeshRays.create_server(model)
	for pi in parts.size():
		var pid: String = String(parts[pi]["id"])
		part_ids.append(pid)
		var idx: Array[int] = []
		var socks: Array = parts[pi].get("sockets", [])
		var cover: Array = parts[pi].get("cover", [])
		var pin: Array = parts[pi].get("pin", [])
		var groups: Array = parts[pi].get("group", [])
		var roles: Array = parts[pi].get("role", [])
		for k in socks.size():
			var blocked: Array[String] = []
			for q: Variant in cover[k]:
				blocked.append(String(q))
			var pins: Array[String] = []
			for q: Variant in pin[k]:
				pins.append(String(q))
			if pins.is_empty():
				pins.append(pid)
			var pos: Vector3 = Geom.socket_pos(socks[k])
			var on_end: bool = _near_strap_end(parts[pi], pos)
			var nrm: Vector3 = Geom.socket_normal(socks[k])
			var gid: String = String(groups[k]) if k < groups.size() else "%s:g%d" % [pid, k]
			var role: int = int(roles[k]) if k < roles.size() else 0
			sockets.append({"part": pi, "pos": pos, "normal": nrm, "blocked": blocked, "pins": pins, "end": on_end, "group": gid, "role": role})
			idx.append(sockets.size() - 1)
			if not by_group.has(gid):
				by_group[gid] = []
			(by_group[gid] as Array).append(sockets.size() - 1)
		by_part.append(idx)
		if parts[pi].get("all_holes", false):
			all_holes = true
		if parts[pi].has("rotor") and rotor_part < 0:
			rotor_part = pi
			rotor_pid = pid
			rotor_steps = maxi(int((parts[pi]["rotor"] as Dictionary).get("steps", 4)), 2)
	rays.free_server()
	if rotor_part >= 0:
		_rotor_states()


## Cover sets of every socket with the rotor turned to each of its states (state 0 = the model's own cover).
func _rotor_states() -> void:
	var rd: Dictionary = (model["parts"] as Array)[rotor_part]["rotor"]
	var piv := Vector3(float(rd["pivot"][0]), float(rd["pivot"][1]), float(rd["pivot"][2]))
	var ax := Vector3(float(rd["axis"][0]), float(rd["axis"][1]), float(rd["axis"][2])).normalized()
	for s: Dictionary in sockets:
		s["blocked_states"] = [(s.blocked as Array).duplicate()]
	for st in range(1, rotor_steps):
		var ang: float = TAU * float(st) / float(rotor_steps)
		var r := Basis(ax, ang)
		var xf := Transform3D(r, piv - r * piv)
		var variant: Dictionary = model.duplicate(true)
		var rp: Dictionary = (variant["parts"] as Array)[rotor_part]
		var p0 := Vector3(float(rp["pos"][0]), float(rp["pos"][1]), float(rp["pos"][2]))
		var p1: Vector3 = xf * p0
		rp["pos"] = [p1.x, p1.y, p1.z]
		var e: Vector3 = (r * ModelBuilder.part_basis(rp)).get_euler(EULER_ORDER_YXZ) * (180.0 / PI)
		rp["rot"] = [e.x, e.y, e.z]
		var rays: MeshRays = MeshRays.create_server(variant)
		for s2: Dictionary in sockets:
			var pos: Vector3 = s2.pos
			var nrm: Vector3 = s2.normal
			if int(s2.part) == rotor_part:
				pos = xf * pos
				nrm = (r * nrm).normalized()
			var cv: Array[String] = rays.blocked_by(part_ids[int(s2.part)], pos, nrm)
			var lst: Array = []
			for q: String in cv:
				lst.append(q)
			(s2["blocked_states"] as Array).append(lst)
		rays.free_server()


## A strap (thin flat part) head is "on an end" when it sits in the outer 0.6 of the strap's length; any other part: true.
static func _near_strap_end(part: Dictionary, pos: Vector3) -> bool:
	var sz: Array = part.get("size", [])
	if sz.size() < 3 or float(sz[2]) > 0.1 or float(sz[0]) < 1.0:
		return true
	var c: Array = part.get("pos", [0, 0, 0])
	return pos.distance_to(Vector3(c[0], c[1], c[2])) >= float(sz[0]) * 0.5 - 0.6


## Result: {level: Dictionary, fail: float, covered_pct: int, tries: int, miss: bool, nodes: int} or {} when impossible.
func generate(n: int) -> Dictionary:
	var plan: Array = LevelsScript.PLAN_R3[n - 1]
	var count: int = plan[0]
	var colors: int = plan[1]
	var band: String = plan[2]
	# round Fab: a level never asks for more heads than the model offers in tidy patterns (1.2 x margin); the count stays
	# a multiple of 3 and every colour keeps at least one box. The real count lands in stats.screws.
	var margin: float = 1.05 if String(model["id"]).begins_with("blk_") else 1.2   # block structures: nearly every hole is used, as in Screwdom
	var avail: int = (3 * int(floor(float(sockets.size()) / margin / 3.0)))
	if all_holes:
		count = sockets.size() - sockets.size() % 3
		colors = clampi(colors, 1, maxi(count / 3, 1))
		if count != plan[0]:
			push_warning("L%d: the structure has %d holes (plan %d)" % [n, count, plan[0]])
	elif avail < count:
		push_warning("L%d: model offers %d pattern sockets, screws %d -> %d" % [n, sockets.size(), count, avail])
		count = maxi(avail, 6)
		colors = clampi(colors, 1, count / 3)
	var window: Array = LevelsScript.BAND_FAIL[band]
	var base_seed: int = 1000 + n
	cur_n = n
	# (a screw through a strap pins the strap AND the cube under it, so a level may hold more parts than screws;
	# _pick_sockets rejects a layout that leaves a part unpinned)
	var bias: float = 0.0
	cur_dock = int(BAND_DOCK[band])
	var best: Dictionary = {}
	var best_dist: float = 1e9
	var tries: int = 0
	for attempt in max_tries:
		tries = attempt + 1
		var rng := RandomNumberGenerator.new()
		rng.seed = base_seed * 1000 + attempt
		var h: float = clampf(BAND_H[band] + bias + rng.randf_range(-0.3, 0.3), 0.0, 1.0)
		if all_holes and count >= 80:
			# Screwdom-size structures (1.2): with 80+ screws a colour order above h 0.5 loses every casual game, the band is
			# reached between 0.1 and 0.5 (measured on blk_s06-s08), so the draw is halved
			h = clampf(h * 0.5, 0.0, 0.6)
		var level: Dictionary = _build(n, count, colors, band, h, rng)
		if level.is_empty():
			continue
		var covered: int = _covered_count(level)
		if not _cover_ok(n, band, covered, count):
			if debug:
				print("  try %d h=%.2f covered=%d REJECT" % [attempt, h, covered])
			continue
		var st: PuzzleState = PuzzleState.from_level(level, model)
		var fail: float = CasualPlayer.fail_pct(st, SEARCH_GAMES, 4242 + attempt)
		var dist: float = _dist(fail, window)
		if debug:
			print("  try %d h=%.2f bias=%.2f covered=%d fail=%.0f" % [attempt, h, bias, covered, fail])
		if fail < window[0]:
			bias = minf(bias + 0.03, 0.25)
			if bias >= 0.25 and cur_dock > 3 and band != "tutorial":
				cur_dock -= 1
				bias = 0.0
				best_dist = 1e9
				best = {}
		elif fail > window[1]:
			bias = maxf(bias - 0.03, -0.25)
			if bias <= -0.25 and cur_dock < 5:
				cur_dock += 1
				bias = 0.0
				best_dist = 1e9
				best = {}
		if dist > 8.0 and dist >= best_dist:
			continue
		# every shipped level so far solves in N nodes (no backtracking); a layout that needs a 300k-node search is not one
		# a player enjoys, so the generator gives up on it early (1.2: big cube levels with hidden layers)
		var sol: Dictionary = Solver.solve(st, 100000)
		if not sol.solved:
			continue
		if dist <= 8.0:
			fail = CasualPlayer.fail_pct(st, CONFIRM_GAMES, 99)
			dist = _dist(fail, window)
		if dist < best_dist:
			best_dist = dist
			best = {"level": level, "fail": fail, "covered": covered, "nodes": sol.nodes, "solution": sol.solution, "tries": tries}
		if dist == 0.0:
			break
	if best.is_empty():
		return {}
	var lv: Dictionary = best.level
	lv["solution"] = best.solution
	var real: int = (lv.screws as Array).size()
	var real_colors: int = 0
	var seen_c: Dictionary = {}
	for s0: Dictionary in lv.screws:
		seen_c[s0.color] = true
	real_colors = seen_c.size()
	lv["stats"] = {"screws": real, "colors": real_colors, "covered_pct": roundi(100.0 * best.covered / real),
		"casual_fail_pct": roundi(best.fail), "solver_nodes": best.nodes, "seed": base_seed}
	return {"level": _ordered(lv), "fail": best.fail, "covered_pct": roundi(100.0 * best.covered / real),
		"tries": best.tries, "miss": best_dist > 0.0, "nodes": best.nodes}


static func _dist(fail: float, window: Array) -> float:
	if fail < window[0]:
		return window[0] - fail
	if fail > window[1]:
		return fail - window[1]
	return 0.0


static func _covered_count(level: Dictionary) -> int:
	var c: int = 0
	for s: Dictionary in level.screws:
		if not (s.blocked_by as Array).is_empty():
			c += 1
	return c


## Cover rules: levels 1-2 none, level 3 at most a quarter, other bands 20-45 %.
## A model that offers fewer covered sockets than that (flat cube structures) is allowed a lower minimum.
func _cover_ok(n: int, band: String, covered: int, count: int) -> bool:
	if all_holes:
		return true
	if HAND.has(n) and HAND[n].has("cover"):
		var w: Array = HAND[n]["cover"]
		var p: float = 100.0 * covered / count
		var avail_h: int = 0
		for s: Dictionary in sockets:
			if not (s.blocked as Array).is_empty():
				avail_h += 1
		var lo_h: float = minf(float(w[0]), 100.0 * float(avail_h) / count * 0.8)   # pattern sockets offer fewer hidden heads
		return p >= lo_h and p <= float(w[1])
	if n <= 2:
		return covered == 0
	if band == "tutorial":
		return covered * 4 <= count
	var pct: float = 100.0 * covered / count
	var avail: int = 0
	for s: Dictionary in sockets:
		if not (s.blocked as Array).is_empty():
			avail += 1
	var lo: float = minf(20.0, 0.7 * 100.0 * float(mini(avail, count)) / count)
	if last_forced * 10 >= count * 7:
		lo = 0.0   # the pinning step chose most screws itself (block structure): the covered share is what it is
	return pct >= lo and pct <= 45.0


func _build(n: int, count: int, colors: int, band: String, h: float, rng: RandomNumberGenerator) -> Dictionary:
	var chosen: Array[int] = []
	if all_holes:
		for si in count:
			chosen.append(si)
	else:
		chosen = _pick_sockets(n, count, band, h, rng)
	if chosen.is_empty() or chosen.size() % 3 != 0:
		return {}
	count = chosen.size()
	colors = clampi(colors, 1, count / 3)
	if HAND.has(n):
		var need: Dictionary = HAND[n].get("min_on", {})
		for pid: String in need:
			var on: int = 0
			for si in chosen:
				if part_ids[sockets[si].part] == pid:
					on += 1
			if on < int(need[pid]):
				return {}
	var colored: Array[String] = _assign_colors(chosen, count, colors, h, rng)
	var screws: Array = []
	var parts: Array = model["parts"]
	var key_ids: Array = []
	for i in count:
		var s: Dictionary = sockets[chosen[i]]
		var e := {"id": i, "part": part_ids[s.part], "pos": _v3(s.pos), "normal": _v3(s.normal),
			"color": colored[i], "blocked_by": (s.blocked as Array).duplicate(), "pins": (s.pins as Array).duplicate()}
		if rotor_part >= 0:
			e["blocked_by_states"] = (s.blocked_states as Array).duplicate(true)
		if (parts[s.part] as Dictionary).get("key", false):
			key_ids.append(i)
		screws.append(e)
	# special edition: every screw on a `lock` part needs the key part's screws out first
	if not key_ids.is_empty():
		for e2: Dictionary in screws:
			var pi: int = sockets[chosen[int(e2.id)]].part
			if (parts[pi] as Dictionary).get("lock", false):
				e2["needs"] = key_ids.duplicate()
	var level := {"id": n, "model": model["id"], "band": band, "dock": cur_dock, "screws": screws,
		"boxes": _queue(screws, colors, count, h, rng)}
	if rotor_part >= 0:
		level["rotors"] = [{"part": rotor_pid, "steps": rotor_steps, "state": 0}]
	if not key_ids.is_empty():
		level["key"] = int(key_ids[0])
	return level


static func _v3(v: Vector3) -> Array:
	return [snappedf(v.x, 0.001), snappedf(v.y, 0.001), snappedf(v.z, 0.001)]


func _pick_sockets(n: int, count: int, band: String, h: float, rng: RandomNumberGenerator) -> Array[int]:
	var target_cov: int = 0
	if HAND.has(n) and HAND[n].has("cover"):
		var cw: Array = HAND[n]["cover"]
		target_cov = roundi((float(cw[0]) + float(cw[1])) * 0.5 * count / 100.0)
	elif n > 2:
		var cf: float = 0.2 + 0.25 * h if band != "tutorial" else 0.1
		target_cov = roundi(cf * count)
	var chosen: Array[int] = []
	var per_part: PackedInt32Array = PackedInt32Array()
	per_part.resize(part_ids.size())
	var cov: Array[int] = [0]
	var faces_used: Dictionary = {}   # face key -> groups taken on it
	# 1. every part is pinned by at least one chosen screw (COMMON 8.1), open sockets preferred; the whole pattern
	#    of the chosen socket comes along (both ends of a strap, all corners of a plate)
	var pinned: Dictionary = {}
	var order: Array[int] = []
	for pi in part_ids.size():
		order.append(pi)
	_shuffle(order, rng)
	# most constrained part first (a cube held by one single strap end), so the budget is never spent before it
	var pools: Dictionary = {}
	for pi in part_ids.size():
		var cnt: int = 0
		for si in sockets.size():
			if (sockets[si].pins as Array).has(part_ids[pi]):
				cnt += 1
		pools[pi] = cnt
	order.sort_custom(func(a: int, b: int) -> bool: return int(pools[a]) < int(pools[b]))
	for pi: int in order:
		if pinned.has(part_ids[pi]):
			continue
		var pool: Array[int] = []
		var pool_any: Array[int] = []
		for si in sockets.size():
			if not (sockets[si].pins as Array).has(part_ids[pi]):
				continue
			pool_any.append(si)
			if (sockets[si].blocked as Array).is_empty():
				pool.append(si)
		if pool.is_empty():
			pool = pool_any
		if pool.is_empty():
			if debug:
				print("  no socket pins %s" % part_ids[pi])
			return []
		var pick: int = _pick_far(pool, chosen, rng)
		if pick < 0:
			if debug:
				print("  no far socket for %s (pool %d)" % [part_ids[pi], pool.size()])
			return []
		# keep one screw in reserve for every part still unpinned after this pick
		var left: int = 0
		for pj: int in order:
			if not pinned.has(part_ids[pj]) and not (sockets[pick].pins as Array).has(part_ids[pj]):
				left += 1
		_take_group(String(sockets[pick].group), pick, chosen, per_part, cov, maxi(count - left, chosen.size() + 1), faces_used, rng)
		for si in chosen:
			for q: String in sockets[si].pins:
				pinned[q] = true
	if pinned.size() < part_ids.size():
		if debug:
			print("  %d of %d parts pinned with %d screws" % [pinned.size(), part_ids.size(), chosen.size()])
		return []
	# special edition: a part with `min_screws` (a surprise inside a box, a dial plate under a rotor) carries at least
	# that many heads, taken from its own sockets
	for pi in part_ids.size():
		var want: int = int(((model["parts"] as Array)[pi] as Dictionary).get("min_screws", 0))
		while per_part[pi] < want:
			var own: Array[int] = []
			for si: int in by_part[pi]:
				if si not in chosen and _far_enough(si, chosen):
					own.append(si)
			var pick2: int = _pick_far(own, chosen, rng)
			if pick2 < 0:
				if debug:
					print("  %s needs %d heads, only %d fit" % [part_ids[pi], want, per_part[pi]])
				return []
			chosen.append(pick2)
			per_part[pi] += 1
			if not (sockets[pick2].blocked as Array).is_empty():
				cov[0] += 1
	last_forced = chosen.size()
	if chosen.size() > count:
		# a structure of many parts needs more screws than the plan says just to hold every part: the level grows to
		# the next multiple of 3 (the caller reads the real count back from the layout)
		count = int(ceil(float(chosen.size()) / 3.0)) * 3
	# 2. fill the rest pattern by pattern, spreading over parts, steering toward the covered target
	var guard: int = 0
	while chosen.size() < count and guard < 4000:
		guard += 1
		var need: int = count - chosen.size()
		var want_cov: int = maxi(target_cov - cov[0], 0)
		var take_cov: bool = rng.randf() < float(want_cov) / float(need)
		var gid: String = _pick_group(chosen, per_part, take_cov, need, faces_used, rng)
		if gid == "":
			gid = _pick_group(chosen, per_part, not take_cov, need, faces_used, rng)
		if gid == "":
			# the model offers no more tidy patterns: a level with at least 60 % of the planned heads is accepted
			# (trimmed to a multiple of 3, the caller reads the real count back)
			if chosen.size() * 10 >= count * 6 and chosen.size() >= 6:
				while chosen.size() % 3 != 0:
					var last: int = chosen.pop_back()
					per_part[sockets[last].part] -= 1
					if not (sockets[last].blocked as Array).is_empty():
						cov[0] -= 1
				if debug:
					print("  fill ran dry at %d of %d: accepted" % [chosen.size(), count])
				return chosen
			if debug:
				print("  fill ran dry at %d of %d" % [chosen.size(), count])
			return []
		var before: int = chosen.size()
		_take_group(gid, -1, chosen, per_part, cov, count, faces_used, rng)
		if chosen.size() == before:
			if debug:
				print("  pattern %s gave nothing (free %d)" % [gid, (by_group[gid] as Array).size()])
			faces_used[_face_key(gid)] = 99   # never offer this face again in this layout
	if chosen.size() != count:
		if debug:
			print("  layout ended with %d of %d screws (guard %d)" % [chosen.size(), count, guard])
		return []
	return chosen


static func _face_key(gid: String) -> String:
	var parts: PackedStringArray = gid.split(":")
	return parts[0] + ":" + parts[1] if parts.size() >= 2 else gid


## Adds the sockets of pattern `gid` to `chosen`: end/corner holes (role 0) first, in a stable order, then the middle
## holes with MID_HOLE_CHANCE. `first` (a socket already picked for pinning) always goes in. Stops at `count`.
func _take_group(gid: String, first: int, chosen: Array[int], per_part: PackedInt32Array, cov: Array[int], count: int,
		faces_used: Dictionary, rng: RandomNumberGenerator) -> void:
	var members: Array = by_group.get(gid, [])
	var order: Array[int] = []
	if first >= 0:
		order.append(first)
	var ends: Array[int] = []
	var mids: Array[int] = []
	for si: int in members:
		if si == first or si in chosen or not _far_enough(si, chosen):
			continue
		if int(sockets[si].role) == 0:
			ends.append(si)
		else:
			mids.append(si)
	_shuffle(ends, rng)
	order.append_array(ends)
	if ends.is_empty() and first < 0:
		order.append_array(mids)   # a lone centre head (small part), or the last free middle hole of a used strap
	var took_any: bool = false
	for si in order:
		if chosen.size() >= count and si != first:
			break
		if si in chosen or not _far_enough(si, chosen):
			continue
		if HAND.has(cur_n) and per_part[sockets[si].part] >= int(HAND[cur_n].get("max_part", 99)):
			continue
		chosen.append(si)
		took_any = true
		per_part[sockets[si].part] += 1
		if not (sockets[si].blocked as Array).is_empty():
			cov[0] += 1
	if took_any and not mids.is_empty() and chosen.size() < count and rng.randf() < MID_HOLE_CHANCE:
		var si2: int = mids[rng.randi_range(0, mids.size() - 1)]
		if si2 not in chosen and _far_enough(si2, chosen):
			chosen.append(si2)
			per_part[sockets[si2].part] += 1
			if not (sockets[si2].blocked as Array).is_empty():
				cov[0] += 1
	if took_any:
		var fk: String = _face_key(gid)
		faces_used[fk] = int(faces_used.get(fk, 0)) + 1


## Picks a pattern with free end holes. Weight: spread over parts (fewer heads on the part = more weight), the hand-made
## face preference, and the covered/open wish. Near the end only patterns that fit in `need` are taken.
func _pick_group(chosen: Array[int], per_part: PackedInt32Array, want_covered: bool, need: int, faces_used: Dictionary,
		rng: RandomNumberGenerator) -> String:
	var cands: Array[String] = []
	var weights: Array[float] = []
	var total: float = 0.0
	for gid: String in by_group:
		var free_ends: Array[int] = []
		var any_free: bool = false
		for si: int in by_group[gid]:
			if si in chosen or not _far_enough(si, chosen):
				continue
			if HAND.has(cur_n) and per_part[sockets[si].part] >= int(HAND[cur_n].get("max_part", 99)):
				continue
			any_free = true
			if int(sockets[si].role) == 0:
				free_ends.append(si)
		if not any_free:
			continue
		var probe: int = free_ends[0] if not free_ends.is_empty() else -1
		if probe < 0:
			# only a middle/centre hole left in this pattern: take it alone only when the pattern is already in use
			var used: bool = false
			for si: int in by_group[gid]:
				if si in chosen:
					used = true
			if not used and not gid.ends_with(":c") and (by_group[gid] as Array).size() > 1:
				continue   # (a one-hole pattern, like a cube face head, stands on its own)
			for si: int in by_group[gid]:
				if si not in chosen and _far_enough(si, chosen):
					probe = si
					break
			if probe < 0:
				continue
		var is_cov: bool = not (sockets[probe].blocked as Array).is_empty()
		if is_cov != want_covered:
			continue
		var fk: String = _face_key(gid)
		if int(faces_used.get(fk, 0)) >= MAX_GROUPS_PER_FACE and not gid.ends_with(":a") and int(faces_used.get(fk, 0)) < 99 and need > 6:
			continue   # (near the end of the fill any face may help)
		if int(faces_used.get(fk, 0)) >= 99:
			continue
		var size: int = maxi(free_ends.size(), 1)
		if size > need and need < 4:
			continue   # would overshoot the screw count; a smaller pattern must finish the level
		var w: float = 1.0 / float(1 + per_part[sockets[probe].part]) * _face_w(probe)
		if free_ends.size() >= 2:
			w *= 1.3   # a real fastened strap or plate reads better than a lone head
		cands.append(gid)
		weights.append(w)
		total += w
	if cands.is_empty():
		return ""
	var r: float = rng.randf() * total
	for i in cands.size():
		r -= weights[i]
		if r <= 0.0:
			return cands[i]
	return cands.back()


func _far_enough(si: int, chosen: Array[int]) -> bool:
	var p: Vector3 = sockets[si].pos
	var gap: float = MIN_SOCKET_GAP
	if HAND.has(cur_n):
		gap = float(HAND[cur_n].get("gap", MIN_SOCKET_GAP))
		if HAND[cur_n].get("strap_ends", false) and not sockets[si].end:
			return false
	for ci in chosen:
		if p.distance_to(sockets[ci].pos) < gap:
			return false
	return true


func _pick_far(pool: Array[int], chosen: Array[int], rng: RandomNumberGenerator) -> int:
	var ok: Array[int] = []
	for si in pool:
		if si not in chosen and _far_enough(si, chosen):
			ok.append(si)
	if ok.is_empty():
		return -1
	if HAND.has(cur_n):
		var ws: Array[float] = []
		var tot: float = 0.0
		for si in ok:
			ws.append(_face_w(si))
			tot += ws.back()
		var r: float = rng.randf() * tot
		for i in ok.size():
			r -= ws[i]
			if r <= 0.0:
				return ok[i]
		return ok.back()
	return ok[rng.randi_range(0, ok.size() - 1)]


## Hand-made levels: heads that face the start camera are preferred, heads facing away or down are nearly never used.
func _face_w(si: int) -> float:
	if not HAND.has(cur_n):
		return 1.0
	var nrm: Vector3 = sockets[si].normal
	if nrm.y < -0.3:
		return 0.02
	var f: float = nrm.dot(START_VIEW)
	if f > 0.5:
		return float(HAND[cur_n]["front"])
	return 1.0 if f > 0.0 else 0.25


func _pick_weighted(chosen: Array[int], per_part: PackedInt32Array, want_covered: bool, rng: RandomNumberGenerator) -> int:
	var cands: Array[int] = []
	var weights: Array[float] = []
	var total: float = 0.0
	for si in sockets.size():
		var is_cov: bool = not (sockets[si].blocked as Array).is_empty()
		if is_cov != want_covered or si in chosen or not _far_enough(si, chosen):
			continue
		if HAND.has(cur_n) and per_part[sockets[si].part] >= int(HAND[cur_n].get("max_part", 99)):
			continue
		var w: float = 1.0 / float(1 + per_part[sockets[si].part]) * _face_w(si)
		cands.append(si)
		weights.append(w)
		total += w
	if cands.is_empty():
		return -1
	var r: float = rng.randf() * total
	for i in cands.size():
		r -= weights[i]
		if r <= 0.0:
			return cands[i]
	return cands.back()


func _box_counts(count: int, colors: int) -> Array[int]:
	var boxes: int = count / 3
	var res: Array[int] = []
	for c in colors:
		res.append(boxes / colors + (1 if c < boxes % colors else 0))
	return res


func _assign_colors(chosen: Array[int], count: int, colors: int, h: float, rng: RandomNumberGenerator) -> Array[String]:
	var seq: Array[String] = []
	var counts: Array[int] = _box_counts(count, colors)
	for c in colors:
		for k in counts[c] * 3:
			seq.append(COLORS[c])
	var order: Array[int] = []
	for i in count:
		order.append(i)
	var clustered: bool = rng.randf() > h
	if clustered:
		# same colors tend to sit on the same part: easier to read
		order.sort_custom(func(a: int, b: int) -> bool: return sockets[chosen[a]].part < sockets[chosen[b]].part)
	else:
		var hidden: Array[int] = []
		if h >= 0.3:
			for i in count:
				if not (sockets[chosen[i]].blocked as Array).is_empty():
					hidden.append(i)
		if hidden.is_empty():
			_shuffle(seq, rng)
		else:
			# item 13: the hidden heads (under hoods, caps, wells) share the first colors, so the first boxes of a hard level
			# ask for colors whose screws are all buried: the player has to dig (take the hood screw first) or fill the tray
			var out2: Array[String] = []
			out2.resize(count)
			var rest: Array[String] = seq.slice(hidden.size())
			_shuffle(rest, rng)
			var ri: int = 0
			for i in count:
				if hidden.has(i):
					out2[i] = seq[hidden.find(i)]
				else:
					out2[i] = rest[ri]
					ri += 1
			return out2
	var out: Array[String] = []
	out.resize(count)
	for i in count:
		out[order[i]] = seq[i]
	return out


## Box queue: easy keeps colors that most open screws have first, hard does the opposite (BLUEPRINT 5.5).
func _queue(screws: Array, colors: int, count: int, h: float, rng: RandomNumberGenerator) -> Array[String]:
	var open_count: Dictionary = {}
	for c in colors:
		open_count[COLORS[c]] = 0
	for s: Dictionary in screws:
		if (s.blocked_by as Array).is_empty():
			open_count[s.color] += 1
	var counts: Array[int] = _box_counts(count, colors)
	var keyed: Array = []
	for c in colors:
		for k in counts[c]:
			var key: float = (0.5 - h) * 2.0 * float(open_count[COLORS[c]]) + rng.randf_range(-1.0, 1.0) * 0.35 * float(count) / float(colors)
			keyed.append([key, COLORS[c]])
	keyed.sort_custom(func(a: Array, b: Array) -> bool: return a[0] > b[0])
	var out: Array[String] = []
	for e: Array in keyed:
		out.append(e[1])
	return out


static func _shuffle(arr: Array, rng: RandomNumberGenerator) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j: int = rng.randi_range(0, i)
		var t: Variant = arr[i]
		arr[i] = arr[j]
		arr[j] = t


## Stable key order, as BLUEPRINT 5.3 lists them.
static func _ordered(lv: Dictionary) -> Dictionary:
	var out: Dictionary = {}
	for k in ["id", "model", "band", "dock", "screws", "boxes", "rotors", "key", "solution", "stats"]:
		if lv.has(k):
			out[k] = lv[k]
	return out


static func fmt_num(v: float) -> String:
	var s: String = "%.3f" % v
	if s.contains("."):
		s = s.rstrip("0").rstrip(".")
	return "0" if s == "-0" else s


static func _arr(a: Array) -> String:
	var parts: PackedStringArray = PackedStringArray()
	for v: Variant in a:
		if typeof(v) == TYPE_STRING:
			parts.append('"%s"' % v)
		elif typeof(v) == TYPE_FLOAT:
			parts.append(fmt_num(v))
		else:
			parts.append(str(v))
	return "[" + ", ".join(parts) + "]"


## Deterministic JSON text: 2-space indent, one screw per line, floats at 3 decimals.
static func to_text(lv: Dictionary) -> String:
	var t: PackedStringArray = PackedStringArray()
	t.append("{")
	t.append('  "id": %d,' % lv.id)
	t.append('  "model": "%s",' % lv.model)
	t.append('  "band": "%s",' % lv.band)
	t.append('  "dock": %d,' % lv.dock)
	t.append('  "screws": [')
	var screws: Array = lv.screws
	for i in screws.size():
		var s: Dictionary = screws[i]
		var bb: PackedStringArray = PackedStringArray()
		for b: Variant in s.blocked_by:
			bb.append('"%s"' % b)
		var pp: PackedStringArray = PackedStringArray()
		for q: Variant in s.get("pins", [s.part]):
			pp.append('"%s"' % q)
		# special edition keys only when present (levels without them keep their exact text)
		var extra: String = ""
		if s.has("needs"):
			extra += ', "needs": %s' % _arr(s.needs)
		if s.has("blocked_by_states"):
			var sts: PackedStringArray = PackedStringArray()
			for st2: Variant in s.blocked_by_states:
				sts.append(_arr(st2))
			extra += ', "blocked_by_states": [%s]' % ", ".join(sts)
		t.append('    {"id": %d, "part": "%s", "pos": %s, "normal": %s, "color": "%s", "blocked_by": [%s], "pins": [%s]%s}%s' % [
			s.id, s.part, _arr(s.pos), _arr(s.normal), s.color, ", ".join(bb), ", ".join(pp), extra, "," if i < screws.size() - 1 else ""])
	t.append("  ],")
	t.append('  "boxes": %s,' % _arr(lv.boxes))
	if lv.has("rotors"):
		var rs: PackedStringArray = PackedStringArray()
		for r: Dictionary in lv.rotors:
			rs.append('{"part": "%s", "steps": %d, "state": %d}' % [r.part, int(r.steps), int(r.state)])
		t.append('  "rotors": [%s],' % ", ".join(rs))
	if lv.has("key"):
		t.append('  "key": %d,' % int(lv.key))
	t.append('  "solution": %s,' % _arr(lv.solution))
	var st: Dictionary = lv.stats
	t.append('  "stats": {"screws": %d, "colors": %d, "covered_pct": %d, "casual_fail_pct": %d, "solver_nodes": %d, "seed": %d}' % [
		st.screws, st.colors, st.covered_pct, st.casual_fail_pct, st.solver_nodes, st.seed])
	t.append("}")
	return "\n".join(t) + "\n"
