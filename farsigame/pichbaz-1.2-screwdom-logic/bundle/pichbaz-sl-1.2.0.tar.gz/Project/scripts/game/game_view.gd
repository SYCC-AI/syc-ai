class_name GameView extends Node3D
## The 3D puzzle board: model + screws, the two color boxes, the dock, input, animation queue.
## Rules live in PuzzleState (PichBaz_1); this node only shows the events it returns.

signal level_won(level: int, stats: Dictionary)
signal level_failed(level: int, progress_pct: int)
signal state_changed(snapshot: Dictionary)
signal locked_slot_tapped()
signal booster_finished(kind: String)
signal zoom_changed(v: float)
signal reaction(kind: String, arg: Variant)        # special edition: "flash", "hint", "surprise", "rotor" ... for the HUD
signal locked_tapped(screw_id: int)                # a padlocked screw was tapped before its key

var anim_speed: float = 1.0

# ---- special edition (Docs/design/SPECIAL_EDITION.md) ----
const ROTOR_TURN_S := 0.36
const HINGE_OPEN_S := 0.62
const SpecialFx := preload("res://scripts/game/special_fx.gd")
var _part_base: Dictionary = {}      # part id -> Transform3D as built (model space)
var _part_def: Dictionary = {}       # part id -> part dictionary
var _screw_base: Dictionary = {}     # screw id -> Transform3D as built (model space)
var _rotor_angle: Dictionary = {}    # rotor part id -> visual angle (rad)
var _hinged: Dictionary = {}         # part id -> true while it hangs open on its hinge
var _spins: Array = []               # [{parts, axis, rps, until_ms, t0}]
var _glow_mats: Dictionary = {}      # part id -> ShaderMaterial (lit look)
var _locks: Dictionary = {}          # screw id -> padlock node
var _keys: Dictionary = {}           # screw id -> halo node
var _rotor_badges: Dictionary = {}   # rotor part id -> badge node
var _shake_t: float = 0.0
var _shake_amp: float = 0.0
var _progress_parts: Array[String] = []

const CAM_DIST := 10.0
const VIEW_WIDTH := 5.0            # world width visible at the model plane (camera keeps the WIDTH)
const FRAC_BOXES := 0.168          # vertical screen fractions (r5 lane 31 light HUD: slim racks, model gets the rest)
const FRAC_DOCK := 0.246
const FRAC_MODEL_TOP := 0.285
const FRAC_MODEL_BOTTOM := 0.862
const FIT_WIDTH := 0.9              # the model fills this much of the screen width at level start (1.2: Screwdom fills the width)
const FIT_HEIGHT := 0.97            # ... unless it would be taller than this much of the model area
const HEAD_VIS := 1.32              # screw head VISUAL scale; the rule/solver/rays keep the real head (MeshRays.HEAD_RADIUS)
const TAP_SLOP := 12.0
const PICK_RADIUS := 56.0          # px at 1080 width
const LOCK_RADIUS := 70.0
const ZOOM_MIN := 1.0
const ZOOM_MAX := 2.6
const HUD_K := 0.3                  # the 3D HUD hangs this much closer to the camera (same screen size), so a zoomed model never covers it
const XRAY_ALPHA := 0.28
const SEAT_SCALE := 0.85
const HUD_TILT := 86.0             # racks face the camera (holes + screw heads toward the player)
const MAX_QUEUE := 2
const BOX_SPACING := 0.44
const BOX_W := 1.5
const DOCK_HOLE_R := 0.15
const PITCH_LIMIT := 55.0
const START_PITCH := 25.0
const FALL_SKIP_SPEED := 5.0       # anim_speed at or above this skips the physics fall (tests, bot)
const FALL_GRAVITY := 1.8
const FALL_MAX_MS := 2500          # hard lifetime of a falling part
const MAX_BODIES := 5
const FALL_ARM_MS := 120           # a fresh body ignores the model this long, so one starting inside another part cannot jam
const BUSY_WATCHDOG := 12.0        # seconds a tap sequence may run before the input lock is forced open
const HIT_GAP_MS := 120
const PartSwing := preload("res://scripts/game/part_swing.gd")
const SWING_HULL_SHRINK := 0.9      # a swinging part is blocked by other parts only when it would newly touch them
const SWEEP_BACK := 0.006           # swing sweep rays start this far behind each sample (world units)
const SWEEP_GRAZE := 0.03          # a sample sliding exactly along a face (designed touching parts) is not a contact

var _level: Dictionary = {}
var _model: Dictionary = {}
var _state: PuzzleState = null
var _level_no: int = 0
var _gen: int = 0

var _cam: Camera3D
var _pivot: Node3D
var _hud: Node3D
var _fx: Node3D
var _backdrop: MeshInstance3D
var _backdrop_mat: ShaderMaterial = null
var _env: Environment = null
var _blob: MeshInstance3D
var _vw: float = 1080.0
var _vh: float = 1920.0
var _model_scale: float = 1.0
var _radius: float = 2.5             # bounding-sphere radius of the model around its centre
var _rays: MeshRays = null
var _zoom: float = 1.0
var _zoom_target: float = 1.0
var _pan: Vector2 = Vector2.ZERO     # world units, added to the pivot position
var _touches: Dictionary = {}        # finger index -> screen position
var _pinch_dist: float = 0.0
var _pinch_mid: Vector2 = Vector2.ZERO
var _base_pos: Vector3 = Vector3.ZERO
var _wwid: float = VIEW_WIDTH
var _fit_pts: PackedVector3Array = PackedVector3Array()  # hull points of the whole model in the start orientation
var _fit_off: Vector2 = Vector2.ZERO  # model-centre offset (world) that centres the start view in the model area
var _fit_bottom: float = -2.45        # lowest projected model point under the pivot (world, per unit scale) for the shadow
static var _big_screws: Dictionary = {}

var _parts: Dictionary = {}          # part id -> MeshInstance3D
var _hulls: Dictionary = {}          # part id -> ConvexPolygonShape3D, built at level load (cheap, shared by every release)
var _busy_t: float = 0.0
var _meshes: Dictionary = {}         # part id -> ArrayMesh (one mesh per part, shared by view, colliders and falling body)
var _part_mats: Dictionary = {}      # part id -> material saved while the X-ray look is on
var _screws: Dictionary = {}         # screw id -> MeshInstance3D
var _released: Dictionary = {}       # part id -> true
var _cols: Dictionary = {}           # part id -> StaticBody3D trimesh collider under the pivot (removed on release)
var _bodies: Array[RigidBody3D] = [] # live falling parts, oldest first
var _last_hit_ms: int = 0
var _swings: Dictionary = {}         # part id -> PartSwing (parts hanging on their last screw)
var _pins_seen: Dictionary = {}      # part id -> remaining pinning screws after the last tap
var _swing_q: PhysicsShapeQueryParameters3D = null
var _swing_ray: PhysicsRayQueryParameters3D = null
var _bake_faces: Dictionary = {}     # part id -> faces, input of the swing-sample bake (worker thread)
var _baked: Dictionary = {}          # part id -> PartSwing.bake() result; read only after the task completed
var _bake_task: int = -1
var _proxies: Dictionary = {}        # part id -> StaticBody3D with the cheap hull on layer 8 (swing contact tests, never the heavy trimesh)
var _boxes: Array = [null, null]     # Node3D per slot
var _dock: Node3D = null
var _dock_base: Node3D = null
var _dock_tray_mat: ShaderMaterial = null
var _dock_screws: Dictionary = {}    # dock index -> screw id
var _capacity: int = 5
var _locked_visible: bool = false
var _flying: int = 0

var _yaw: float = 0.0
var _pitch: float = START_PITCH
var _yaw_vel: float = 0.0
var _pitch_vel: float = 0.0
var _drag: bool = false
var _moved: bool = false
var _press_pos: Vector2 = Vector2.ZERO
var _last_pos: Vector2 = Vector2.ZERO

var _busy: bool = false
var _queue: Array = []               # [screw_id, force]
var _hammer: bool = false
var _xray_on: bool = false
var _tweens: Array[Tween] = []
var _taps: int = 0
var _t0_ms: int = 0
var _boosters_used: int = 0
var _pulse: float = 0.0
var _xray_mat: ShaderMaterial = null
var _ring_mesh: Mesh = null
var _ring_mat: StandardMaterial3D = null
var _mat_cache: Dictionary = {}


func _ready() -> void:
	_cam = Camera3D.new()
	_cam.keep_aspect = Camera3D.KEEP_WIDTH
	_cam.fov = rad_to_deg(2.0 * atan(VIEW_WIDTH * 0.5 / CAM_DIST))
	_cam.position = Vector3(0, 0, CAM_DIST)
	_cam.far = 120.0
	add_child(_cam)
	_cam.make_current()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Backdrop.background_color(1)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#EDEBFF")
	env.ambient_light_energy = 0.5
	_env = env
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	Backdrop.add_lights(self)
	_backdrop = MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = Vector2(70, 150)
	_backdrop.mesh = quad
	_backdrop_mat = Backdrop.make_material()
	_backdrop.material_override = _backdrop_mat
	_backdrop.position = Vector3(0, 0, -30)
	add_child(_backdrop)
	add_child(Backdrop.make_motes())
	_blob = MeshInstance3D.new()
	var bq := QuadMesh.new()
	bq.size = Vector2(1, 1)
	_blob.mesh = bq
	var blm := ShaderMaterial.new()
	blm.shader = load("res://assets/shaders/blob.gdshader")
	_blob.material_override = blm
	add_child(_blob)
	_pivot = Node3D.new()
	_pivot.name = "Pivot"
	add_child(_pivot)
	_hud = Node3D.new()
	_hud.name = "Hud3D"
	_hud.scale = Vector3.ONE * HUD_K
	_hud.position = Vector3(0, 0, CAM_DIST * (1.0 - HUD_K))
	add_child(_hud)
	_fx = Node3D.new()
	_fx.name = "Fx"
	add_child(_fx)
	get_viewport().size_changed.connect(_layout)
	_layout()


# ------------------------------------------------------------------ public API

func start_level(n: int) -> void:
	var level: Dictionary = Levels.load_level(n)
	if level.is_empty():
		push_error("GameView.start_level: cannot load level %d" % n)
		return
	var model: Dictionary = Levels.load_model(String(level["model"]))
	start_level_data(level, model, n)


func start_level_data(level: Dictionary, model: Dictionary, level_number: int = 0) -> void:
	_gen += 1
	_clear()
	_level = level
	_model = model
	_level_no = level_number if level_number > 0 else int(level.get("id", 0))
	Backdrop.apply_chapter(_backdrop_mat, _level_no)
	_env.background_color = Backdrop.background_color(_level_no)
	_state = PuzzleState.from_level(level, model)
	_taps = 0
	_boosters_used = 0
	_t0_ms = Time.get_ticks_msec()
	_busy = false
	_queue.clear()
	_hammer = false
	_xray_on = false
	_released.clear()
	_yaw = 0.0
	_pitch = START_PITCH
	_yaw_vel = 0.0
	_pitch_vel = 0.0
	_zoom = ZOOM_MIN
	_zoom_target = ZOOM_MIN
	_pan = Vector2.ZERO
	_touches.clear()
	zoom_changed.emit(0.0)
	var snap: Dictionary = _state.snapshot()
	_capacity = int(snap["dock_capacity"])
	_build_model()
	for pid_k: Variant in _parts.keys():
		_pins_seen[pid_k] = _state.pin_count(String(pid_k))
	_radius = _model_radius()
	_fit_pts = _start_points()
	_build_screws()
	_build_special()
	_build_boxes(snap)
	_rebuild_dock()
	_apply_rotation()
	_layout()
	_pivot.remove_meta("intro") if _pivot.has_meta("intro") else null
	if anim_speed < 5.0:
		_pivot.set_meta("intro", true)
		_pivot.scale = Vector3.ONE * _model_scale * 0.7
		var tw := _tw()
		tw.tween_property(_pivot, "scale", Vector3.ONE * _model_scale, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		tw.finished.connect(func() -> void: _pivot.remove_meta("intro"))


func restart() -> void:
	if _level.is_empty():
		return
	start_level_data(_level, _model, _level_no)


func set_paused(p: bool) -> void:
	process_mode = Node.PROCESS_MODE_DISABLED if p else Node.PROCESS_MODE_INHERIT


func current_level() -> int:
	return _level_no


func can_continue() -> bool:
	return _state != null and _state.can_add_dock_slot()


func set_locked_slot_visible(v: bool) -> void:
	_locked_visible = v
	if _state != null:
		_rebuild_dock()


func use_booster(kind: String) -> bool:
	if _state == null or _state.status() == "won":
		return false
	match kind:
		"extra_slot":
			if not _state.can_add_dock_slot():
				return false
			_apply_dock_events(_state.add_dock_slot())
			_boosters_used += 1
			Sfx.play("booster")
			booster_finished.emit("extra_slot")
			state_changed.emit(_state.snapshot())
			return true
		"hammer":
			if _hammer or _state.status() != "playing":
				return false
			_set_hammer(true)
			return true
		"xray":
			if _xray_on or _state.status() != "playing":
				return false
			_start_xray()
			_boosters_used += 1
			Sfx.play("booster")
			booster_finished.emit("xray")
			return true
	return false


## Zoom in 0..1 (0 = whole model, 1 = ZOOM_MAX), smooth. The slider and the pinch both end up here.
func set_zoom(v: float) -> void:
	_zoom_target = lerpf(ZOOM_MIN, ZOOM_MAX, clampf(v, 0.0, 1.0))


func zoom_value() -> float:
	return (_zoom - ZOOM_MIN) / (ZOOM_MAX - ZOOM_MIN)


func cancel_booster() -> void:
	_set_hammer(false)


func continue_with_extra_slot() -> bool:
	if _state == null or not _state.can_add_dock_slot():
		return false
	_apply_dock_events(_state.add_dock_slot())
	state_changed.emit(_state.snapshot())
	return true


func hint_screw_screen_pos() -> Vector2:
	if _state == null:
		return Vector2(-1, -1)
	var cam_local := _cam_local()
	var order: Array = _level.get("solution", [])
	for id_v: Variant in order:
		var id := int(id_v)
		if _hint_ok(id, cam_local):
			return _screw_screen(id)
	for id_v: Variant in _screws.keys():
		var id := int(id_v)
		if _hint_ok(id, cam_local):
			return _screw_screen(id)
	return Vector2(-1, -1)


func bot_tap(screw_id: int) -> void:
	_request_tap(screw_id, false)


## Tests and bots: turn rotor k (same path as a tap on the rotor part).
func bot_rotate(k: int) -> void:
	_request_action(-k - 1, false)


## Tests and bots: one solution step (a >= 0 tap, a < 0 rotor turn).
func bot_apply(a: int) -> void:
	_request_action(a, false)


func is_busy() -> bool:
	return _busy


## Test helper: is the screw visible (not occluded by an unreleased part) from at least one allowed view
## direction (any yaw, pitch within the clamp)? A level with an unreachable screw is unplayable.
func screw_reachable(id: int) -> bool:
	if not _screws.has(id):
		return false
	var rel := (_cam.global_position - _pivot.global_position) / _pivot.scale.x
	for yaw in range(0, 360, 15):
		for pitch in range(-55, 56, 11):
			var q := Quaternion(Vector3.RIGHT, deg_to_rad(float(pitch))) * Quaternion(Vector3.UP, deg_to_rad(float(yaw)))
			if _is_visible(id, q.inverse() * rel):
				return true
	return false


func state() -> PuzzleState:
	return _state


# ------------------------------------------------------------------ build

func _clear() -> void:
	for t in _tweens:
		if t.is_valid():
			t.kill()
	_tweens.clear()
	for root: Node3D in [_pivot, _hud, _fx]:
		for c in root.get_children():
			root.remove_child(c)
			c.queue_free()
	_bake_wait()
	_parts.clear()
	_meshes.clear()
	_hulls.clear()
	_part_mats.clear()
	_cols.clear()
	_rays = null
	_bodies.clear()
	_swings.clear()
	_proxies.clear()
	_pins_seen.clear()
	_screws.clear()
	_boxes = [null, null]
	_dock = null
	_dock_base = null
	_dock_screws.clear()
	_flying = 0
	_part_base.clear()
	_part_def.clear()
	_screw_base.clear()
	_rotor_angle.clear()
	_hinged.clear()
	_spins.clear()
	_glow_mats.clear()
	_locks.clear()
	_keys.clear()
	_rotor_badges.clear()
	_progress_parts.clear()
	_shake_t = 0.0
	_shake_amp = 0.0


## Radius of the sphere around the model centre that holds every part (from the mesh bounds).
func _model_radius() -> float:
	var r := 1.0
	for part: Dictionary in _model["parts"]:
		var xf := ModelBuilder.part_transform(part)
		var bb: AABB = (_meshes[String(part["id"])] as ArrayMesh).get_aabb()
		for k in 8:
			r = maxf(r, (xf * bb.get_endpoint(k)).length())
	return r


## Hull points of every part in model space, turned to the start view (the framing fits what the player sees first).
func _start_points() -> PackedVector3Array:
	var q := Quaternion(Vector3.RIGHT, deg_to_rad(START_PITCH))
	var pts := PackedVector3Array()
	for part: Dictionary in _model["parts"]:
		var pid := String(part["id"])
		var xf := ModelBuilder.part_transform(part)
		for p: Vector3 in (_hulls[pid] as ConvexPolygonShape3D).points:
			pts.append(q * (xf * p))
	for sc: Dictionary in _level.get("screws", []):
		var sp: Array = sc["pos"]
		pts.append(q * Vector3(sp[0], sp[1], sp[2]))
	return pts


## Perspective screen-plane extents (x0, x1, y0, y1) of the start view at model scale s around the pivot.
func _start_extent(s: float, off: Vector2) -> Vector4:
	var e := Vector4(INF, -INF, INF, -INF)
	for p in _fit_pts:
		var k := CAM_DIST / maxf(CAM_DIST - p.z * s, 0.5)
		var x := (off.x + p.x * s) * k
		var y := (off.y + p.y * s) * k
		e = Vector4(minf(e.x, x), maxf(e.y, x), minf(e.z, y), maxf(e.w, y))
	return e


## Start-view framing: scale so the model is FIT_WIDTH of the screen wide (or fills the model area height), centred.
## Never smaller than the old bounding-sphere fit, so every rotation stays at least as readable as before.
func _fit_start(area_h: float) -> float:
	var s_sphere := clampf(minf(_wwid * 0.96, area_h * 0.97) / (2.0 * _radius), 0.5, 1.5)
	if _fit_pts.is_empty():
		_fit_off = Vector2.ZERO
		return s_sphere
	var s := s_sphere
	var off := Vector2.ZERO
	for i in 6:
		var e := _start_extent(s, off)
		var k := minf(_wwid * FIT_WIDTH / maxf(e.y - e.x, 0.01), area_h * FIT_HEIGHT / maxf(e.w - e.z, 0.01))
		s = clampf(s * k, s_sphere, s_sphere * 1.8)
		e = _start_extent(s, off)
		off -= Vector2((e.x + e.y) * 0.5, (e.z + e.w) * 0.5) * 0.9
	_fit_off = off
	_fit_bottom = (_start_extent(s, off).z - off.y) / s
	return s


## Camera framing from the bounding sphere (any rotation fits). Static so the model tools can measure tap sizes.
static func frame_scale(radius: float, vw: float, vh: float) -> float:
	var area_h := VIEW_WIDTH * vh / vw * (FRAC_MODEL_BOTTOM - FRAC_MODEL_TOP)
	return clampf(minf(VIEW_WIDTH * 0.96, area_h * 0.97) / (2.0 * radius), 0.5, 1.5)


## Cheap convex collider: the extreme vertices of the mesh in 26 directions (a sampled vertex subset keeps it fast).
static func _make_hull(mesh: ArrayMesh) -> ConvexPolygonShape3D:
	var faces := mesh.get_faces()
	var n := faces.size()
	var stride := maxi(1, n / 600)
	var dirs: Array[Vector3] = []
	for x in [-1, 0, 1]:
		for y in [-1, 0, 1]:
			for z in [-1, 0, 1]:
				if x != 0 or y != 0 or z != 0:
					dirs.append(Vector3(x, y, z).normalized())
	var best: Array[float] = []
	var pts: Array[Vector3] = []
	for d in dirs:
		best.append(-1e20)
		pts.append(Vector3.ZERO)
	var i := 0
	while i < n:
		var v := faces[i]
		for k in dirs.size():
			var dd := v.dot(dirs[k])
			if dd > best[k]:
				best[k] = dd
				pts[k] = v
		i += stride
	var sh := ConvexPolygonShape3D.new()
	sh.points = PackedVector3Array(pts)
	return sh


func _build_model() -> void:
	var mat := ModelBuilder.baked_material()
	ModelBuilder.style_hoods(_model)
	for part: Dictionary in _model["parts"]:
		var pid := String(part["id"])
		var mesh := ModelBuilder.make_part_mesh(part)
		_meshes[pid] = mesh
		var mi := MeshInstance3D.new()
		mi.name = pid
		mi.mesh = mesh
		mi.transform = ModelBuilder.part_transform(part)
		mi.material_override = mat
		mi.set_meta("mat", mat)
		mi.set_meta("hex", String(part["color"]))
		_pivot.add_child(mi)
		_parts[pid] = mi
		_part_base[pid] = mi.transform
		_part_def[pid] = part
		_hulls[pid] = _make_hull(mesh)
		_bake_faces[pid] = mesh.get_faces()
		var px := StaticBody3D.new()
		px.collision_layer = 8
		px.collision_mask = 0
		px.transform = mi.transform
		var pcs := CollisionShape3D.new()
		pcs.shape = _hulls[pid]
		px.add_child(pcs)
		_pivot.add_child(px)
		_proxies[pid] = px
	_cols = MeshRays.build_bodies(_pivot, _model, _meshes)
	_bake_task = WorkerThreadPool.add_task(_bake_swing_samples, false, "swing samples")
	_rays = MeshRays.new()
	_rays.setup(_pivot, _model, _cols)


func _build_screws() -> void:
	for sc: Dictionary in _level["screws"]:
		var id := int(sc["id"])
		var node := ModelBuilder.make_screw(String(sc["color"])) as MeshInstance3D
		node.mesh = big_screw_mesh(String(sc["color"]))
		var p: Array = sc["pos"]
		var n: Array = sc["normal"]
		var nv := Vector3(n[0], n[1], n[2]).normalized()
		node.transform = Transform3D(Basis(Quaternion(Vector3.UP, nv)), Vector3(p[0], p[1], p[2]))
		_pivot.add_child(node)
		_screws[id] = node
		_screw_base[id] = node.transform


## The screw mesh with a bigger, glossier head (radius and dome x HEAD_VIS, colour a bit richer); the shaft keeps
## its size. Only the look changes: picking, rays and the rule use the node transform and MeshRays.HEAD_RADIUS.
static func big_screw_mesh(color_key: String) -> ArrayMesh:
	if _big_screws.has(color_key):
		return _big_screws[color_key]
	var src := ModelBuilder.screw_mesh(color_key)
	var arr := src.surface_get_arrays(0)
	var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	var nr: PackedVector3Array = arr[Mesh.ARRAY_NORMAL]
	var cl: PackedColorArray = arr[Mesh.ARRAY_COLOR]
	var ky := 1.0 + (HEAD_VIS - 1.0) * 0.7
	for i in v.size():
		if v[i].y > -0.001:
			v[i] = Vector3(v[i].x * HEAD_VIS, v[i].y * ky, v[i].z * HEAD_VIS)
			nr[i] = Vector3(nr[i].x / HEAD_VIS, nr[i].y / ky, nr[i].z / HEAD_VIS).normalized()
			var c := cl[i]
			if c.s > 0.15:
				c.s = minf(c.s * 1.12, 1.0)
			cl[i] = c
	arr[Mesh.ARRAY_VERTEX] = v
	arr[Mesh.ARRAY_NORMAL] = nr
	arr[Mesh.ARRAY_COLOR] = cl
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	_big_screws[color_key] = m
	return m


func _build_boxes(snap: Dictionary) -> void:
	var infos: Array = snap["boxes"]
	for slot in 2:
		if infos[slot] != null:
			var nb := _make_box(String((infos[slot] as Dictionary)["color"]))
			_hud.add_child(nb)
			nb.position = _slot_pos(slot)
			_boxes[slot] = nb


func _mat(hex: String) -> ShaderMaterial:
	return ModelBuilder.part_material(hex)


func _make_box(color_key: String) -> Node3D:
	var root := Node3D.new()
	root.rotation_degrees = Vector3(HUD_TILT, 0, 0)
	root.set_meta("color", color_key)
	var body := MeshInstance3D.new()
	body.mesh = RackLook.box_mesh(color_key, BOX_W, BOX_SPACING)
	body.material_override = ModelBuilder.baked_material()
	root.add_child(body)
	return root


func _hole_disc(pos: Vector3, radius: float, hex: String) -> MeshInstance3D:
	var d := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.03
	cm.radial_segments = 20
	cm.rings = 1
	d.mesh = cm
	d.material_override = _mat(hex)
	d.position = pos
	return d


func _box_hole_local(index: int) -> Vector3:
	return Vector3((index - 1) * BOX_SPACING, 0.215, 0)


func _dock_visible_slots() -> int:
	return _capacity + (1 if _locked_visible and _capacity < 7 else 0)


func _dock_spacing() -> float:
	return minf(0.58, 3.7 / float(_dock_visible_slots()))


func _dock_hole_local(i: int) -> Vector3:
	var n := _dock_visible_slots()
	return Vector3((i - (n - 1) * 0.5) * _dock_spacing(), 0.185, 0)


func _rebuild_dock() -> void:
	if _dock == null:
		_dock = Node3D.new()
		_dock.rotation_degrees = Vector3(HUD_TILT, 0, 0)
		_hud.add_child(_dock)
	if _dock_base != null:
		_dock.remove_child(_dock_base)
		_dock_base.queue_free()
	_dock_base = Node3D.new()
	_dock.add_child(_dock_base)
	_dock.move_child(_dock_base, 0)
	var n := _dock_visible_slots()
	var hole_x: Array[float] = []
	var socket_x: Array[float] = []
	for i in n:
		socket_x.append(_dock_hole_local(i).x)
		if i < _capacity:
			hole_x.append(socket_x[i])
	var tray := MeshInstance3D.new()
	tray.mesh = RackLook.dock_sockets_mesh(socket_x, DOCK_HOLE_R)
	_dock_tray_mat = ModelBuilder.dock_material()
	tray.material_override = _dock_tray_mat
	_dock_base.add_child(tray)
	var top := MeshInstance3D.new()
	top.mesh = RackLook.dock_holes_mesh(hole_x, DOCK_HOLE_R, _dock_hole_local(0).y)
	top.material_override = ModelBuilder.baked_material()
	_dock_base.add_child(top)
	if _dock_visible_slots() > _capacity:
		_dock_base.add_child(_make_lock(_dock_hole_local(_capacity)))
	for idx_v: Variant in _dock_screws.keys():
		var idx := int(idx_v)
		var sn: Node3D = _screws.get(int(_dock_screws[idx_v]))
		if sn != null and sn.get_parent() == _dock:
			sn.position = _dock_hole_local(idx) + Vector3(0, -0.04, 0)
	_layout_hud()


## Small gold padlock from ModelBuilder primitives: rounded body, arc shackle, dark keyhole.
func _make_lock(pos: Vector3) -> Node3D:
	var root := Node3D.new()
	root.position = pos + Vector3(0, 0.1, 0)
	root.rotation_degrees = Vector3(-HUD_TILT, 0, 0)
	var acc := ModelBuilder.Acc.new()
	var gold := ModelBuilder.bake_color("#F2B01E")
	var steel := ModelBuilder.bake_color("#C9D0D8")
	var dark := ModelBuilder.bake_color("#2B2118")
	var body := Transform3D(Basis.IDENTITY, Vector3(0, -0.04, 0))
	ModelBuilder.add_rbox(acc, Vector3(0.17, 0.13, 0.065), 0.045, body, gold, 0.25)
	# shackle: two legs and a half ring of short rounded bars
	for sx in [-1.0, 1.0]:
		ModelBuilder.add_rbox(acc, Vector3(0.02, 0.05, 0.02), 0.012, Transform3D(Basis.IDENTITY, Vector3(sx * 0.085, 0.14, 0)), steel, 0.8)
	for i in 7:
		var a := PI * float(i) / 6.0
		var c := Vector3(cos(a) * 0.085, 0.165 + sin(a) * 0.075, 0)
		var xf := Transform3D(Basis(Vector3.BACK, a + PI * 0.5), c)
		ModelBuilder.add_rbox(acc, Vector3(0.02, 0.03, 0.02), 0.012, xf, steel, 0.8)
	# keyhole: round hole plus slot
	var kh := Transform3D(Basis(Vector3.RIGHT, PI * 0.5), Vector3(0, -0.01, 0.062))
	ModelBuilder.add_lathe(acc, ModelBuilder.cyl_profile(0.03, 0.02, 0.008), kh, dark, 0.0)
	ModelBuilder.add_rbox(acc, Vector3(0.011, 0.03, 0.01), 0.004, Transform3D(Basis.IDENTITY, Vector3(0, -0.06, 0.066)), dark, 0.0)
	var mi := MeshInstance3D.new()
	mi.mesh = acc.mesh()
	mi.material_override = ModelBuilder.baked_material()
	root.add_child(mi)
	return root


# ------------------------------------------------------------------ layout

func _wp(fx: float, fy: float) -> Vector3:
	return _cam.project_position(Vector2(fx * _vw, fy * _vh), CAM_DIST)


func _slot_pos(slot: int) -> Vector3:
	var c := _wp(0.5, FRAC_BOXES)
	return Vector3(c.x + (-1.0 if slot == 0 else 1.0) * (BOX_W * 0.5 + 0.12), c.y, 0)


func _layout() -> void:
	if _cam == null or not _cam.is_inside_tree():
		return
	var vs := get_viewport().get_visible_rect().size
	_vw = maxf(vs.x, 1.0)
	_vh = maxf(vs.y, 1.0)
	_wwid = _wp(1.0, 0.5).x - _wp(0.0, 0.5).x
	var area_h := absf(_wp(0.5, FRAC_MODEL_TOP).y - _wp(0.5, FRAC_MODEL_BOTTOM).y)
	_model_scale = _fit_start(area_h) if not _model.is_empty() else 1.0
	var c := _wp(0.5, (FRAC_MODEL_TOP + FRAC_MODEL_BOTTOM) * 0.5)
	_base_pos = Vector3(c.x + _fit_off.x, c.y + _fit_off.y, 0)
	_apply_zoom()
	var vis_h := absf(_wp(0.5, 0.0).y - _wp(0.5, 1.0).y)
	_backdrop.scale = Vector3(_wwid * 4.4 / 70.0, vis_h * 4.4 / 150.0, 1.0)
	_blob.position = Vector3(_base_pos.x, _base_pos.y + _fit_bottom * _model_scale - 0.1, -0.5)
	_blob.scale = Vector3(4.6 * _model_scale, 0.9 * _model_scale, 1.0)
	_layout_hud()


func _layout_hud() -> void:
	if _cam == null or not _cam.is_inside_tree():
		return
	for slot in 2:
		var b: Node3D = _boxes[slot]
		if b != null and not b.has_meta("moving"):
			b.position = _slot_pos(slot)
	if _dock != null:
		var d := _wp(0.5, FRAC_DOCK)
		_dock.position = Vector3(d.x, d.y, 0)


# ------------------------------------------------------------------ input

func _unhandled_input(ev: InputEvent) -> void:
	if _state == null:
		return
	if ev is InputEventScreenTouch:
		_touch(ev as InputEventScreenTouch)
	elif ev is InputEventScreenDrag:
		_touch_drag(ev as InputEventScreenDrag)
	elif ev is InputEventMouseButton:
		var mb := ev as InputEventMouseButton
		if mb.pressed and (mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN):
			_zoom_at(mb.position, 1.12 if mb.button_index == MOUSE_BUTTON_WHEEL_UP else 1.0 / 1.12)
			return
		if mb.button_index != MOUSE_BUTTON_LEFT:
			return
		if mb.pressed:
			if _touches.size() >= 2:
				return
			_drag = true
			_moved = false
			_press_pos = mb.position
			_last_pos = mb.position
			_yaw_vel = 0.0
			_pitch_vel = 0.0
		elif _drag:
			_drag = false
			if not _moved and _touches.size() < 2:
				_handle_tap(mb.position)
	elif ev is InputEventMouseMotion and _drag:
		if _touches.size() >= 2:
			return
		var mm := ev as InputEventMouseMotion
		if not _moved and mm.position.distance_to(_press_pos) > TAP_SLOP * _vw / 1080.0:
			_moved = true
		if _moved:
			var d := mm.position - _last_pos
			_yaw += d.x * 0.4
			_pitch = clampf(_pitch + d.y * 0.3, -PITCH_LIMIT, PITCH_LIMIT)
			_yaw_vel = d.x * 0.4 * 40.0
			_pitch_vel = d.y * 0.3 * 40.0
			_apply_rotation()
		_last_pos = mm.position


## Two fingers: pinch zoom toward the midpoint and pan. The first finger also arrives as an emulated mouse press,
## so a second finger cancels the pending tap/rotation.
func _touch(t: InputEventScreenTouch) -> void:
	if t.pressed:
		_touches[t.index] = t.position
		if _touches.size() == 2:
			_drag = false
			_moved = true
			_yaw_vel = 0.0
			_pitch_vel = 0.0
			_pinch_start()
	else:
		_touches.erase(t.index)
		if _touches.size() == 1:
			_pinch_start_single()


func _pinch_start() -> void:
	var pts: Array = _touches.values()
	_pinch_dist = maxf((pts[0] as Vector2).distance_to(pts[1] as Vector2), 1.0)
	_pinch_mid = ((pts[0] as Vector2) + (pts[1] as Vector2)) * 0.5


func _pinch_start_single() -> void:
	_drag = false
	_moved = true


func _touch_drag(d: InputEventScreenDrag) -> void:
	if not _touches.has(d.index):
		return
	_touches[d.index] = d.position
	if _touches.size() != 2:
		return
	var pts: Array = _touches.values()
	var dist := maxf((pts[0] as Vector2).distance_to(pts[1] as Vector2), 1.0)
	var mid := ((pts[0] as Vector2) + (pts[1] as Vector2)) * 0.5
	_zoom_at(mid, dist / _pinch_dist)
	# two-finger pan: the model follows the midpoint
	_pan += (_screen_to_plane(mid) - _screen_to_plane(_pinch_mid))
	_clamp_pan()
	_apply_zoom()
	_pinch_dist = dist
	_pinch_mid = mid


func _screen_to_plane(sp: Vector2) -> Vector2:
	var w := _cam.project_position(sp, CAM_DIST)
	return Vector2(w.x, w.y)


## Zoom by factor k about a screen point: the model point under it stays put.
func _zoom_at(sp: Vector2, k: float) -> void:
	var old := _zoom
	_zoom = clampf(_zoom * k, ZOOM_MIN, ZOOM_MAX)
	_zoom_target = _zoom
	if is_equal_approx(old, _zoom):
		return
	var m := _screen_to_plane(sp)
	var centre := Vector2(_base_pos.x, _base_pos.y) + _pan
	var ratio := _zoom / old
	_pan = (m - (m - centre) * ratio) - Vector2(_base_pos.x, _base_pos.y)
	_clamp_pan()
	_apply_zoom()
	zoom_changed.emit(zoom_value())


func _clamp_pan() -> void:
	if _zoom <= ZOOM_MIN + 0.001:
		_pan = Vector2.ZERO
		return
	var rw := _radius * _model_scale * _zoom
	var area_h := absf(_wp(0.5, FRAC_MODEL_TOP).y - _wp(0.5, FRAC_MODEL_BOTTOM).y)
	var lim := Vector2(maxf(rw - _wwid * 0.3, 0.0), maxf(rw - area_h * 0.3, 0.0))
	_pan = Vector2(clampf(_pan.x, -lim.x, lim.x), clampf(_pan.y, -lim.y, lim.y))


func _apply_zoom() -> void:
	_pivot.position = Vector3(_base_pos.x + _pan.x, _base_pos.y + _pan.y, 0)
	if not _pivot.has_meta("intro"):
		_pivot.scale = Vector3.ONE * _model_scale * _zoom


func _process(delta: float) -> void:
	if _state == null:
		return
	if not _bodies.is_empty():
		_tick_bodies(delta)
	if not _swings.is_empty():
		_tick_swings(delta)
	if _busy and _state.status() == "playing":
		_busy_t += delta
		if _busy_t > BUSY_WATCHDOG:   # something never finished: open the input lock instead of freezing the game
			push_warning("GameView: tap sequence stuck, forcing input unlock")
			_gen += 1
			_busy = false
			_flying = 0
			_queue.clear()
			_busy_t = 0.0
	else:
		_busy_t = 0.0
	if not _drag and (absf(_yaw_vel) > 0.5 or absf(_pitch_vel) > 0.5):
		_yaw += _yaw_vel * delta
		_pitch = clampf(_pitch + _pitch_vel * delta, -PITCH_LIMIT, PITCH_LIMIT)
		var k := exp(-3.5 * delta)
		_yaw_vel *= k
		_pitch_vel *= k
		_apply_rotation()
	_tick_special(delta)
	if not is_equal_approx(_zoom, _zoom_target):
		var before := _zoom
		_zoom = lerpf(_zoom, _zoom_target, 1.0 - exp(-12.0 * delta))
		if absf(_zoom - _zoom_target) < 0.01:
			_zoom = _zoom_target
		_pan = _pan * (_zoom / before)
		_clamp_pan()
		_apply_zoom()
		zoom_changed.emit(zoom_value())
	if _hammer:
		_pulse += delta * 5.0
		var s := 1.04 + 0.04 * sin(_pulse)
		for id_v: Variant in _screws.keys():
			var n: Node3D = _screws[id_v]
			if n.get_parent() == _pivot:
				n.scale = Vector3.ONE * s


func _apply_rotation() -> void:
	_pivot.quaternion = Quaternion(Vector3.RIGHT, deg_to_rad(_pitch)) * Quaternion(Vector3.UP, deg_to_rad(_yaw))


func _handle_tap(sp: Vector2) -> void:
	if _locked_visible and _capacity < 7 and _dock != null:
		var lp := _dock.to_global(_dock_hole_local(_capacity))
		if _cam.unproject_position(lp).distance_to(sp) < LOCK_RADIUS * _vw / 1080.0:
			Sfx.play("locked")
			locked_slot_tapped.emit()
			return
	var id := _pick(sp)
	if id >= 0:
		_request_tap(id, _hammer)
		return
	if _hammer:
		return
	var k := _pick_rotor(sp)
	if k >= 0:
		_request_action(-k - 1, false)


func _request_tap(id: int, force: bool) -> void:
	_request_action(id, force)


## One player action: a >= 0 taps screw a, a < 0 turns rotor (-a - 1). Queued (at most MAX_QUEUE) while busy.
func _request_action(a: int, force: bool) -> void:
	if _state == null or _state.status() != "playing":
		return
	if _busy:
		if _queue.size() < MAX_QUEUE:
			_queue.append([a, force])
		return
	_run_taps(a, force)


func _run_taps(first_id: int, first_force: bool) -> void:
	var g := _gen
	_busy = true
	_busy_t = 0.0
	var id := first_id
	var force := first_force
	while true:
		if id < 0:
			await _do_rotate(-id - 1, g)
		else:
			await _do_tap(id, force, g)
		if g != _gen:
			return
		if _queue.is_empty() or _state.status() != "playing":
			_queue.clear()
			break
		_busy_t = 0.0
		var nxt: Array = _queue.pop_front()
		id = int(nxt[0])
		force = bool(nxt[1])
	_busy = false


# ------------------------------------------------------------------ picking

func _screw_head_world(id: int) -> Vector3:
	var n: Node3D = _screws[id]
	return n.global_transform * Vector3(0, 0.06, 0)


func _screw_screen(id: int) -> Vector2:
	return _cam.unproject_position(_screw_head_world(id))


func _cam_local() -> Vector3:
	return _pivot.global_transform.affine_inverse() * _cam.global_position


func _hint_ok(id: int, cam_local: Vector3) -> bool:
	if _state.is_removed(id) or not _state.is_tappable(id):
		return false
	if not _is_visible(id, cam_local):
		return false
	var sp := _screw_screen(id)
	return sp.x > 20.0 and sp.y > 20.0 and sp.x < _vw - 20.0 and sp.y < _vh - 20.0


func _pick(sp: Vector2) -> int:
	# the tap target is never smaller than the (bigger) visible head
	var head_px := MeshRays.HEAD_RADIUS * HEAD_VIS * 1.15 * _model_scale * _zoom * _vw / maxf(_wwid, 0.01)
	var radius := maxf(PICK_RADIUS * _vw / 1080.0, head_px)
	var cam_local := _cam_local()
	var best := -1
	var best_d := INF
	for id_v: Variant in _screws.keys():
		var id := int(id_v)
		if _state.is_removed(id):
			continue
		var n: Node3D = _screws[id]
		if n.get_parent() != _pivot:
			continue
		var d := _screw_screen(id).distance_to(sp)
		if d > radius or d >= best_d:
			continue
		if not _hammer and not _is_visible(id, cam_local):
			continue
		best = id
		best_d = d
	return best


## COMMON 11.3: visible = MeshRays says the camera reaches the head centre or a rim point (real meshes).
func _is_visible(id: int, cam_local: Vector3) -> bool:
	var n: Node3D = _screws[id]
	return _rays.head_visible(cam_local, n.position, n.basis.y.normalized(), _released)


# ------------------------------------------------------------------ tap resolution + animation

func _tw() -> Tween:
	var t := create_tween()
	t.set_speed_scale(anim_speed)
	_tweens.append(t)
	if _tweens.size() > 64:
		_tweens = _tweens.filter(func(x: Tween) -> bool: return x.is_valid())
	return t


func _wait(sec: float) -> void:
	var t := _tw()
	t.tween_interval(sec)
	await t.finished


func _do_tap(id: int, force: bool, g: int) -> void:
	var ev: Array[Dictionary] = _state.tap(id, force)
	if ev.is_empty():
		if _state.is_locked(id) and _state.is_removed(id) == false:
			locked_tapped.emit(id)
			_lock_shake(id)
		await _shake(id, g)
		return
	_taps += 1
	if force:
		_set_hammer(false)
		_boosters_used += 1
		booster_finished.emit("hammer")
	await _play(ev, g)
	if g != _gen:
		return
	_after_change()
	state_changed.emit(_state.snapshot())
	var last: Dictionary = ev.back()
	match String(last["type"]):
		"won":
			await _win(g)
		"failed":
			await _fail(g, int(last["progress_pct"]))


func _shake(id: int, g: int) -> void:
	var n: Node3D = _screws.get(id)
	if n == null or n.get_parent() != _pivot:
		return
	Sfx.play("locked")
	Sfx.vibrate(10)
	var base := n.position
	var tw := _tw()
	for i in 4:
		tw.tween_property(n, "position", base + Vector3(0.05 if i % 2 == 0 else -0.05, 0, 0.03), 0.0625)
	tw.tween_property(n, "position", base, 0.0)
	await tw.finished


func _play(events: Array, g: int) -> void:
	var i := 0
	var delay_k := 0
	while i < events.size():
		var e: Dictionary = events[i]
		i += 1
		match String(e["type"]):
			"screw_to_box", "screw_to_dock":
				var rel: Array = []
				while i < events.size() and String((events[i] as Dictionary)["type"]) == "part_released":
					rel.append(String((events[i] as Dictionary)["part"]))
					i += 1
				await _move_screw(e, rel, g)
			"part_released":
				_release_part(String(e["part"]))
			"box_done":
				await _box_done(int(e["slot"]), g)
			"box_open":
				_open_box(int(e["slot"]), String(e["color"]))
			"box_empty":
				_boxes[int(e["slot"])] = null
			"dock_to_box":
				_dock_to_box(e, delay_k, g)
				delay_k += 1
			"dock_resized":
				_capacity = int(e["capacity"])
				_rebuild_dock()
		if g != _gen:
			return
	while _flying > 0:
		await get_tree().process_frame
		if g != _gen:
			return


static func _smooth(p: float) -> float:
	return p * p * p * (p * (p * 6.0 - 15.0) + 10.0)   # smootherstep: no start/stop jerk


func _fly(node: Node3D, target_fn: Callable, dur: float, arc: float, end_scale: float, g: int) -> void:
	var t0 := node.transform
	var q0 := Quaternion(t0.basis.orthonormalized())
	var s0 := t0.basis.get_scale().x
	var spin_axis := t0.basis.y.normalized()
	var tw := _tw()
	tw.tween_method(func(p: float) -> void:
		if not is_instance_valid(node):
			return
		var e := _smooth(p)
		var tx: Transform3D = target_fn.call()
		var q := q0.slerp(Quaternion(tx.basis.orthonormalized()), e)
		q = Quaternion(spin_axis, 0.9 * sin(p * PI)) * q   # a slight twist on the way, zero at both ends
		var sc := lerpf(s0, end_scale, e)
		var pos := t0.origin.lerp(tx.origin, e) + Vector3(0, sin(e * PI) * arc, 0)
		node.transform = Transform3D(Basis(q).scaled(Vector3.ONE * sc), pos), 0.0, 1.0, dur)
	await tw.finished


## Soft landing: a small dip and two decaying settles instead of a hard bounce.
func _bounce(node: Node3D) -> void:
	var base := node.position
	var tw := _tw()
	tw.tween_property(node, "position", base + Vector3(0, 0.045, 0), 0.07).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(node, "position", base - Vector3(0, 0.012, 0), 0.08).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(node, "position", base, 0.07).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	await tw.finished


func _move_screw(e: Dictionary, release_ids: Array, g: int) -> void:
	var id := int(e["screw"])
	var node: Node3D = _screws.get(id)
	if node == null:
		return
	var to_box := String(e["type"]) == "screw_to_box"
	node.reparent(_fx)
	Sfx.play("unscrew", -5.0, randf_range(0.96, 1.04))
	var g0 := node.transform
	var axis := g0.basis.y.normalized()
	var lift := 0.4 * _model_scale
	var tw := _tw()
	tw.tween_method(func(p: float) -> void:
		if is_instance_valid(node):
			var le := ease(p, -1.6) if p < 1.0 else 1.0   # eases out: quick start, soft end
			node.transform = Transform3D(Basis(axis, TAU * 1.5 * _smooth(p)) * g0.basis, g0.origin + axis * lift * le), 0.0, 1.0, 0.22)
	await tw.finished
	if g != _gen:
		return
	for pid: String in release_ids:
		_release_part(pid)
	_refresh_hangs()
	var hole_scale := SEAT_SCALE
	if to_box:
		var slot := int(e["slot"])
		var index := int(e["index"])
		var box: Node3D = _boxes[slot]
		if box == null:
			return
		var tf := func() -> Transform3D:
			return box.global_transform * Transform3D(Basis.from_scale(Vector3.ONE * hole_scale), _box_hole_local(index))
		await _fly(node, tf, 0.42, 0.8, hole_scale, g)
		if g != _gen:
			return
		node.reparent(box)
		node.transform = Transform3D(Basis.from_scale(Vector3.ONE * hole_scale), _box_hole_local(index))
		Sfx.play("to_box", -4.0, randf_range(0.97, 1.03))
	else:
		var di := int(e["dock_index"])
		var dock := _dock
		var tf2 := func() -> Transform3D:
			return dock.global_transform * Transform3D(Basis.from_scale(Vector3.ONE * hole_scale), _dock_hole_local(di) + Vector3(0, -0.04, 0))
		await _fly(node, tf2, 0.42, 0.8, hole_scale, g)
		if g != _gen:
			return
		node.reparent(dock)
		node.transform = Transform3D(Basis.from_scale(Vector3.ONE * hole_scale), _dock_hole_local(di) + Vector3(0, -0.04, 0))
		_dock_screws[di] = id
		Sfx.play("to_dock", -4.0, randf_range(0.97, 1.03))
	await _bounce(node)


func _dock_to_box(e: Dictionary, k: int, g: int) -> void:
	_flying += 1
	var id := int(e["screw"])
	var di := int(e["dock_index"])
	var slot := int(e["slot"])
	var index := int(e["index"])
	var node: Node3D = _screws.get(id)
	var box: Node3D = _boxes[slot]
	if node == null or box == null:
		_flying -= 1
		return
	await _wait(0.08 * k)
	if g != _gen:
		return
	node.reparent(_fx)
	_dock_screws.erase(di)
	var tf := func() -> Transform3D:
		return box.global_transform * Transform3D(Basis.from_scale(Vector3.ONE * SEAT_SCALE), _box_hole_local(index))
	await _fly(node, tf, 0.42, 0.6, SEAT_SCALE, g)
	if g != _gen:
		return
	node.reparent(box)
	node.transform = Transform3D(Basis.from_scale(Vector3.ONE * SEAT_SCALE), _box_hole_local(index))
	Sfx.play("to_box", -4.0, randf_range(0.97, 1.03))
	await _bounce(node)
	if g != _gen:
		return
	_flying -= 1


func _open_box(slot: int, color_key: String) -> void:
	var nb := _make_box(color_key)
	_hud.add_child(nb)
	var final := _slot_pos(slot)
	nb.position = final + Vector3((-4.0 if slot == 0 else 4.0), 0, 0)
	nb.set_meta("moving", true)
	_boxes[slot] = nb
	var tw := _tw()
	tw.tween_property(nb, "position", final, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.finished.connect(func() -> void:
		if is_instance_valid(nb):
			nb.remove_meta("moving"))


func _box_done(slot: int, g: int) -> void:
	while _flying > 0:
		await get_tree().process_frame
		if g != _gen:
			return
	var box: Node3D = _boxes[slot]
	_boxes[slot] = null
	if box == null:
		return
	var color_key := String(box.get_meta("color"))
	var lid := MeshInstance3D.new()
	lid.mesh = RackLook.lid_mesh(color_key, BOX_W)
	lid.material_override = ModelBuilder.baked_material()
	lid.position = Vector3(0, 1.0, 0)
	box.add_child(lid)
	var tw := _tw()
	tw.tween_property(lid, "position:y", 0.33, 0.15).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	await tw.finished
	if g != _gen:
		return
	Sfx.play("box_done")
	_burst(box.global_position, ModelBuilder.color_of(color_key), 24)
	_fly_off(box, slot, g)


func _fly_off(box: Node3D, slot: int, g: int) -> void:
	var tw := _tw()
	tw.tween_property(box, "scale", Vector3.ONE * 1.15, 0.08)
	tw.tween_property(box, "position", box.position + Vector3((-1.0 if slot == 0 else 1.0) * 1.0, 2.5, -1.0), 0.35).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(box, "scale", Vector3.ONE * 0.05, 0.35)
	await tw.finished
	if g == _gen and is_instance_valid(box):
		box.queue_free()


func _release_part(pid: String) -> void:
	if _released.has(pid) or not _parts.has(pid):
		return
	_released[pid] = true
	var sw: RefCounted = _swings.get(pid)
	_swings.erase(pid)
	if _proxies.has(pid):
		(_proxies[pid] as Node).queue_free()
		_proxies.erase(pid)
	var node: MeshInstance3D = _parts[pid]
	if _cols.has(pid):
		(_cols[pid] as Node).queue_free()
		_cols.erase(pid)
	_react(pid, node)
	_drop_hinged_children(pid)
	var def: Dictionary = _part_def.get(pid, {})
	if def.has("hinge") and not _released.has(String((def["hinge"] as Dictionary).get("host", ""))):
		_hinge_open(pid, node, def["hinge"], anim_speed >= FALL_SKIP_SPEED)   # bots/tests: the open pose at once
		return
	_drop_body(pid, node, sw, bool(def.get("pop", false)))


## The released part leaves as a physics body (slides off the model, or pops up when `pop`).
func _drop_body(pid: String, node: MeshInstance3D, sw: RefCounted, pop: bool) -> void:
	if anim_speed >= FALL_SKIP_SPEED:
		node.queue_free()
		return
	var g0 := node.global_transform
	var sc := g0.basis.get_scale().x
	var dir := g0.origin - _pivot.global_position
	dir.y *= 0.15   # slide off sideways instead of hopping up and landing back on the model
	dir.z = maxf(dir.z, 0.0) + 0.3
	dir = dir.normalized()
	var body := RigidBody3D.new()
	body.gravity_scale = FALL_GRAVITY * 0.35   # eased up to full gravity in _tick_bodies, so the drop starts softly
	body.collision_layer = 2     # falling parts never touch each other, only the static model (layer 1)
	body.collision_mask = 0      # armed after FALL_ARM_MS, so a body that starts inside another part cannot jam
	body.contact_monitor = true
	body.max_contacts_reported = 4
	var pm := PhysicsMaterial.new()
	pm.friction = 0.7
	pm.bounce = 0.12
	body.physics_material_override = pm
	var cs := CollisionShape3D.new()
	cs.shape = _hulls[pid]
	cs.scale = Vector3.ONE * sc * 0.96
	body.add_child(cs)
	_fx.add_child(body)
	body.global_transform = Transform3D(g0.basis.orthonormalized(), g0.origin)
	node.reparent(body, false)
	node.transform = Transform3D(Basis.from_scale(Vector3.ONE * sc), Vector3.ZERO)
	body.linear_velocity = dir * 1.1 * sc
	body.angular_velocity = Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5) * 1.6
	if pop:   # jack-in-the-box: a spring throws the part up and out of the picture
		body.linear_velocity = Vector3(dir.x * 0.6, 3.2, 0.9) * sc
		body.angular_velocity = Vector3(randf_range(1.5, 3.0), randf_range(-2.0, 2.0), randf_range(-1.0, 1.0))
		body.gravity_scale = FALL_GRAVITY
	if sw != null:   # keep the swing motion: the part lets go with the speed it had
		var aw: Vector3 = _pivot.global_transform.basis * (sw.a as Vector3)
		var rw: Vector3 = _pivot.global_transform.basis * (Basis(sw.a as Vector3, float(sw.theta)) * ((sw.com as Vector3) - (sw.p as Vector3)))
		body.linear_velocity += (aw.normalized() * float(sw.omega)).cross(rw)
		body.angular_velocity += aw.normalized() * float(sw.omega)
	body.set_meta("t0", Time.get_ticks_msec())
	body.set_meta("armed", false)
	body.set_meta("hit", false)
	body.set_meta("rest", 0.0)
	body.set_meta("kicks", 0)
	body.set_meta("dir", dir)
	body.body_entered.connect(_on_fall_hit.bind(body))
	_bodies.append(body)
	while _bodies.size() > MAX_BODIES:
		var old: RigidBody3D = _bodies.pop_front()
		if is_instance_valid(old):
			old.get_parent().remove_child(old)
			old.queue_free()


# ------------------------------------------------------------------ hanging parts (item 12 + 16)

## A part that just lost all but one pinning screw hangs on it: a damped pendulum about the screw axis.
## Parts that already started with one screw stay as designed (rigid) until released; 2+ screws = rigid.
func _refresh_hangs() -> void:
	if anim_speed >= FALL_SKIP_SPEED:
		return
	for pid_v: Variant in _parts.keys():
		var pid := String(pid_v)
		if _released.has(pid) or _swings.has(pid) or _is_special(pid):
			continue
		var left := _state.pin_count(pid)
		var seen := int(_pins_seen.get(pid, left))
		_pins_seen[pid] = left
		if left != 1 or seen < 2:
			continue
		var pin: Array[int] = _state.pinners(pid)
		if pin.size() != 1 or not _screws.has(pin[0]):
			continue
		var sn: Node3D = _screws[pin[0]]
		var node: MeshInstance3D = _parts[pid]
		var sw := PartSwing.make(pid, pin[0], node.transform, sn.position, sn.basis.y, _meshes[pid], _baked_for(pid))
		sw.blockers = _swing_overlaps(sw, node.transform)
		_swings[pid] = sw


## Worker thread: contact samples + centre of mass of every part, so a part starting to hang costs no frame time.
func _bake_swing_samples() -> void:
	for pid: Variant in _bake_faces.keys():
		_baked[pid] = PartSwing.bake(_bake_faces[pid])


func _exit_tree() -> void:
	_bake_wait()


func _bake_wait() -> void:
	if _bake_task >= 0:
		WorkerThreadPool.wait_for_task_completion(_bake_task)
		_bake_task = -1
	_bake_faces.clear()
	_baked.clear()


func _baked_for(pid: String) -> Dictionary:
	if _bake_task >= 0 and WorkerThreadPool.is_task_completed(_bake_task):
		WorkerThreadPool.wait_for_task_completion(_bake_task)
		_bake_task = -1
	return _baked.get(pid, {}) if _bake_task < 0 else {}


func _swing_overlaps(sw: RefCounted, xf: Transform3D) -> Dictionary:
	if _swing_q == null:
		_swing_q = PhysicsShapeQueryParameters3D.new()
		_swing_q.collision_mask = 8
	var out: Dictionary = {}
	var own: Node = _proxies.get(sw.pid)
	_swing_q.shape = _hulls[sw.pid]
	_swing_q.transform = _pivot.global_transform * xf * Transform3D(Basis.from_scale(Vector3.ONE * SWING_HULL_SHRINK), Vector3.ZERO)
	var ex: Array[RID] = []
	if own is CollisionObject3D:
		ex.append((own as CollisionObject3D).get_rid())
	_swing_q.exclude = ex
	for h: Dictionary in _pivot.get_world_3d().direct_space_state.intersect_shape(_swing_q, 8):
		out[h["rid"]] = true
	return out


func _tick_swings(delta: float) -> void:
	var down := (_pivot.global_transform.basis.orthonormalized().inverse() * Vector3.DOWN).normalized()
	for pid_v: Variant in _swings.keys():
		var sw: RefCounted = _swings[pid_v]
		var node: MeshInstance3D = _parts.get(pid_v)
		if node == null or not is_instance_valid(node):
			_swings.erase(pid_v)
			continue
		var th0: float = sw.theta
		var w0: float = sw.omega
		sw.step(minf(delta, 0.05), down, _model_scale)
		if sw.theta == th0:
			continue
		node.transform = sw.xf
		# swept contact every 2nd frame (from the last checked angle, so nothing is skipped) and when the part settles
		if ((Engine.get_process_frames() + hash(pid_v)) & 1) != 0 and not sw.asleep:
			continue
		var safe := _swing_sweep(sw, float(sw.checked), float(sw.theta))
		if safe != float(sw.theta):   # the sweep touched another part: stop at the contact, soft bounce or rest
			sw.hit(safe, w0, delta)
			node.transform = sw.xf
		else:
			sw.contact_t = 0.0
		sw.checked = sw.theta
		var col: Node3D = _cols.get(pid_v)
		if col != null:
			col.transform = sw.xf   # visibility rays follow the part: a swung-away part uncovers, a swung-over part hides
		(_proxies[pid_v] as Node3D).transform = sw.xf


## Swept contact of a hanging part (round 5): each outer sample point of the part moves along a short ray from its
## pose at `th0` to its pose at `th1` against the exact meshes of the other parts (ray layer). Only surfaces it ENTERS
## count (front faces, not grazing), so designed touching / overlaps at hang start never jam it and nothing ever ends
## inside another part. Returns `th1` when free, else the last free angle (two bisection steps towards the contact).
func _swing_sweep(sw: RefCounted, th0: float, th1: float) -> float:
	if _swing_ray == null:
		_swing_ray = PhysicsRayQueryParameters3D.new()
		_swing_ray.collision_mask = MeshRays.LAYER_BIT
		_swing_ray.hit_back_faces = false
		_swing_ray.hit_from_inside = false
	var own: CollisionObject3D = _cols.get(sw.pid)
	_swing_ray.exclude = [own.get_rid()] if own != null else []
	if not _sweep_hits(sw, th0, th1):
		return th1
	var lo := th0
	var hi := th1
	for _i in 2:
		var mid := (lo + hi) * 0.5
		if _sweep_hits(sw, lo, mid):
			hi = mid
		else:
			lo = mid
	return lo


func _sweep_hits(sw: RefCounted, th0: float, th1: float) -> bool:
	var gx := _pivot.global_transform
	var space := _pivot.get_world_3d().direct_space_state
	var n: int = (sw.samples as PackedVector3Array).size()
	var first: int = sw.last_hit
	for j in n:
		var i := (j + first) % n   # the sample that touched last time first: a resting part answers after one ray
		var a0: Vector3 = gx * (sw.sample_at(i, th0) as Vector3)
		var a1: Vector3 = gx * (sw.sample_at(i, th1) as Vector3)
		var mv := a1 - a0
		if mv.length_squared() < 1e-8:
			continue
		var dir := mv.normalized()
		_swing_ray.from = a0 - dir * SWEEP_BACK   # a point resting ON a surface (sitting part) still sees it
		_swing_ray.to = a1 + dir * 0.01
		var h := space.intersect_ray(_swing_ray)
		if not h.is_empty() and (h["normal"] as Vector3).dot(mv.normalized()) < -SWEEP_GRAZE:
			sw.last_hit = i
			return true
	return false


func _on_fall_hit(_other: Node, body: RigidBody3D) -> void:
	if not is_instance_valid(body) or bool(body.get_meta("hit")):
		return
	body.set_meta("hit", true)
	var now := Time.get_ticks_msec()
	if now - _last_hit_ms < HIT_GAP_MS:
		return
	_last_hit_ms = now
	Sfx.play("part_fall", clampf(-18.0 + body.linear_velocity.length() * 1.6, -18.0, -8.0))


## Frees falling bodies once fully off screen (or after 6 s). Never fades.
func _tick_bodies(delta: float) -> void:
	var now := Time.get_ticks_msec()
	var vr := get_viewport().get_visible_rect()
	for i in range(_bodies.size() - 1, -1, -1):
		var b := _bodies[i]
		if not is_instance_valid(b):
			_bodies.remove_at(i)
		elif now - int(b.get_meta("t0")) > FALL_MAX_MS or _body_offscreen(b, vr):
			_bodies.remove_at(i)
			b.queue_free()
		else:
			if not bool(b.get_meta("armed")) and now - int(b.get_meta("t0")) > FALL_ARM_MS:
				b.set_meta("armed", true)
				b.collision_mask = 1
			b.gravity_scale = lerpf(FALL_GRAVITY * 0.35, FALL_GRAVITY, clampf(float(now - int(b.get_meta("t0"))) / 350.0, 0.0, 1.0))
			_unstick(b, delta)


## A part resting on top of the model gets kicked off; if it still rests it falls through the rest.
func _unstick(b: RigidBody3D, delta: float) -> void:
	if b.linear_velocity.length() > 0.5:
		b.set_meta("rest", 0.0)
		return
	var rest := float(b.get_meta("rest")) + delta
	b.set_meta("rest", rest)
	if rest < 0.3:
		return
	b.set_meta("rest", 0.0)
	var kicks := int(b.get_meta("kicks"))
	b.set_meta("kicks", kicks + 1)
	if kicks >= 2:
		b.collision_mask = 0
		return
	var d: Vector3 = b.get_meta("dir")
	b.sleeping = false
	b.linear_velocity = Vector3(d.x * 3.5, 1.2, d.z * 3.5)
	b.angular_velocity = Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5) * 6.0


func _body_offscreen(b: RigidBody3D, vr: Rect2) -> bool:
	if _cam.is_position_behind(b.global_position):
		return true
	var mi := b.get_child(1) as MeshInstance3D if b.get_child_count() > 1 else null
	if mi == null:
		return true
	var aabb := mi.get_aabb()
	var gt := mi.global_transform
	var lo := Vector2(1e9, 1e9)
	var hi := Vector2(-1e9, -1e9)
	for k in 8:
		var c := gt * aabb.get_endpoint(k)
		if _cam.is_position_behind(c):
			return false
		var sp := _cam.unproject_position(c)
		lo = lo.min(sp)
		hi = hi.max(sp)
	return not vr.intersects(Rect2(lo, hi - lo), true)


func _win(g: int) -> void:
	Sfx.play("win")
	Sfx.vibrate(30)
	_burst(_pivot.global_position, Color("#FFE066"), 48)
	await _wait(0.8)
	if g != _gen:
		return
	var stats := {"taps": _taps, "seconds": float(Time.get_ticks_msec() - _t0_ms) / 1000.0, "boosters_used": _boosters_used}
	level_won.emit(_level_no, stats)


func _fail(g: int, pct: int) -> void:
	Sfx.play("fail")
	Sfx.vibrate(40)
	if _dock_tray_mat != null:
		var m := _dock_tray_mat
		var tw := _tw()
		for i in 2:
			tw.tween_method(func(p: float) -> void: m.set_shader_parameter("base_color", Color("#3F4F7E").lerp(Color("#E53935"), p)), 0.0, 1.0, 0.12)
			tw.tween_method(func(p: float) -> void: m.set_shader_parameter("base_color", Color("#E53935").lerp(Color("#3F4F7E"), p)), 0.0, 1.0, 0.12)
		await tw.finished
	await _wait(0.2)
	if g != _gen:
		return
	level_failed.emit(_level_no, pct)


func _burst(pos: Vector3, col: Color, amount: int) -> void:
	var p := CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.06
	sm.height = 0.12
	sm.radial_segments = 6
	sm.rings = 3
	p.mesh = sm
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	p.material_override = m
	p.amount = amount
	p.lifetime = 0.7
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector3(0, 1, 0)
	p.spread = 180.0
	p.initial_velocity_min = 2.5
	p.initial_velocity_max = 5.0
	p.gravity = Vector3(0, -4.0, 0)
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.2
	p.color = col
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1, 1, 1, 1))
	ramp.set_color(1, Color(1, 1, 1, 0))
	p.color_ramp = ramp
	_fx.add_child(p)
	p.global_position = pos
	p.emitting = true
	var tw := _tw()
	tw.tween_interval(1.0)
	tw.finished.connect(func() -> void:
		if is_instance_valid(p):
			p.queue_free())


# ------------------------------------------------------------------ boosters

func _apply_dock_events(events: Array[Dictionary]) -> void:
	for e: Dictionary in events:
		if String(e["type"]) == "dock_resized":
			_capacity = int(e["capacity"])
	_rebuild_dock()


## The one X-ray material (hammer and x-ray booster): cyan glass, fresnel rim, alpha about 0.28, no depth write.
func _xray_material() -> ShaderMaterial:
	if _xray_mat == null:
		_xray_mat = ShaderMaterial.new()
		_xray_mat.shader = load("res://assets/shaders/xray_glass.gdshader")
		_xray_mat.set_shader_parameter("alpha", XRAY_ALPHA)
	return _xray_mat


func _xray_parts(on: bool) -> void:
	for pid_v: Variant in _parts.keys():
		if _released.has(pid_v):
			continue
		var mi: MeshInstance3D = _parts[pid_v]
		if on:
			if not _part_mats.has(pid_v):
				_part_mats[pid_v] = mi.material_override
			mi.material_override = _xray_material()
		elif _part_mats.has(pid_v):
			mi.material_override = _part_mats[pid_v] as Material
			_part_mats.erase(pid_v)


## Soft emissive ring lying under a selectable head (hammer mode).
func _hammer_ring() -> MeshInstance3D:
	if _ring_mesh == null:
		var tm := TorusMesh.new()
		tm.inner_radius = 0.15
		tm.outer_radius = 0.2
		tm.rings = 24
		tm.ring_segments = 6
		_ring_mesh = tm
		_ring_mat = StandardMaterial3D.new()
		_ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_ring_mat.albedo_color = Color(1.0, 0.86, 0.35, 0.8)
		_ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_ring_mat.emission_enabled = true
		_ring_mat.emission = Color(1.0, 0.78, 0.25)
		_ring_mat.emission_energy_multiplier = 1.4
	var r := MeshInstance3D.new()
	r.name = "hammer_ring"
	r.mesh = _ring_mesh
	r.material_override = _ring_mat
	r.scale = Vector3(1, 0.35, 1)
	r.position = Vector3(0, 0.01, 0)
	return r


func _set_hammer(on: bool) -> void:
	if _hammer == on:
		return
	_hammer = on
	_pulse = 0.0
	_xray_parts(on or _xray_on)
	for id_v: Variant in _screws.keys():
		var n := _screws[id_v] as MeshInstance3D
		if n.get_parent() != _pivot:
			continue
		var ring := n.get_node_or_null("hammer_ring")
		if on and ring == null:
			n.add_child(_hammer_ring())
		elif not on:
			if ring != null:
				n.remove_child(ring)
				ring.queue_free()
			n.scale = Vector3.ONE


func _start_xray() -> void:
	_xray_on = true
	_xray_parts(true)
	var g := _gen
	await _wait(5.0 * anim_speed)
	if g != _gen:
		return
	_xray_on = false
	_xray_parts(_hammer)


# ------------------------------------------------------------------ special edition (Docs/design/SPECIAL_EDITION.md)

## Hinge, rotor, pop and progress parts never hang as pendulums (their own motion is scripted).
func _is_special(pid: String) -> bool:
	var d: Dictionary = _part_def.get(pid, {})
	return d.has("hinge") or d.has("rotor") or d.has("progress_spin") or bool(d.get("pop", false))


## After the model and screws exist: rotor visual state, key halos, padlocks, progress parts.
func _build_special() -> void:
	for pid_v: Variant in _parts.keys():
		var pid := String(pid_v)
		var d: Dictionary = _part_def[pid]
		if d.has("rotor"):
			_rotor_angle[pid] = 0.0
			var k := _state.rotor_of_part(pid)
			if k >= 0:
				_rotor_angle[pid] = _rotor_step(pid) * float(_state.rotor_state(k))
				_apply_rotor_angle(pid)
				if anim_speed < FALL_SKIP_SPEED:
					_add_rotor_badge(pid, d["rotor"])
		if d.has("progress_spin"):
			_progress_parts.append(pid)
	if anim_speed < FALL_SKIP_SPEED:
		for id_v: Variant in _screws.keys():
			var id := int(id_v)
			if _state.is_locked(id):
				_add_lock(id)
		for kid in _state.key_screws():
			if _screws.has(kid):
				_add_key_halo(kid)
	_apply_progress()


func _rotor_step(pid: String) -> float:
	var k := _state.rotor_of_part(pid)
	return TAU / float(maxi(_state.rotor_steps(k), 2)) if k >= 0 else TAU * 0.25


## Rotor / progress parts: the part node, its colliders and its screws follow the rotation (model space).
func _apply_part_rotation(pid: String, xf: Transform3D) -> void:
	var node_v: Variant = _parts.get(pid)
	if node_v == null or not is_instance_valid(node_v) or _released.has(pid):
		return   # (a freed node must never reach a typed variable)
	var node := node_v as MeshInstance3D
	node.transform = xf * (_part_base[pid] as Transform3D)
	if _cols.has(pid):
		(_cols[pid] as Node3D).transform = node.transform
	if _proxies.has(pid):
		(_proxies[pid] as Node3D).transform = node.transform
	for id_v: Variant in _screws.keys():
		var id := int(id_v)
		var sn_v: Variant = _screws[id]   # (a flown screw's node may be freed already)
		if sn_v == null or not is_instance_valid(sn_v):
			continue
		var sn := sn_v as Node3D
		if sn.get_parent() != _pivot or _state.screw_part_id(id) != pid or not _screw_base.has(id):
			continue
		sn.transform = xf * (_screw_base[id] as Transform3D)
	if _rotor_badges.has(pid) and is_instance_valid(_rotor_badges[pid]):
		var rd: Dictionary = (_part_def[pid] as Dictionary).get("rotor", {})
		var piv := SpecialFx.v3(rd.get("pivot", [0, 0, 0]))
		var ax := SpecialFx.v3(rd.get("axis", [0, 1, 0]), Vector3.UP).normalized()
		(_rotor_badges[pid] as Node3D).transform = Transform3D(Basis(Quaternion(Vector3.UP, ax)), piv + ax * 0.08)


func _apply_rotor_angle(pid: String) -> void:
	var rd: Dictionary = (_part_def[pid] as Dictionary).get("rotor", {})
	var piv := SpecialFx.v3(rd.get("pivot", [0, 0, 0]))
	var ax := SpecialFx.v3(rd.get("axis", [0, 1, 0]), Vector3.UP)
	_apply_part_rotation(pid, SpecialFx.about(piv, ax, float(_rotor_angle[pid])))


func _add_rotor_badge(pid: String, rd: Dictionary) -> void:
	var b := MeshInstance3D.new()
	b.name = "rotor_badge"
	b.mesh = SpecialFx.badge_mesh()
	b.material_override = SpecialFx.unshaded(Color(1.0, 0.93, 0.55, 0.85), 1.0)
	var piv := SpecialFx.v3(rd.get("pivot", [0, 0, 0]))
	var ax := SpecialFx.v3(rd.get("axis", [0, 1, 0]), Vector3.UP).normalized()
	b.transform = Transform3D(Basis(Quaternion(Vector3.UP, ax)), piv + ax * 0.08)
	_pivot.add_child(b)
	_rotor_badges[pid] = b


func _add_lock(id: int) -> void:
	var n: Node3D = _screws[id]
	var l := MeshInstance3D.new()
	l.name = "padlock"
	l.mesh = SpecialFx.lock_mesh()
	l.material_override = ModelBuilder.baked_material()
	n.add_child(l)
	_locks[id] = l


func _add_key_halo(id: int) -> void:
	var n: Node3D = _screws[id]
	var h := MeshInstance3D.new()
	h.name = "key_halo"
	h.mesh = SpecialFx.halo_mesh()
	h.material_override = ModelBuilder.baked_material()
	h.position = Vector3(0, 0.004, 0)
	n.add_child(h)
	_keys[id] = h


## Tap on a rotor part (no screw under the finger): a ray against the model colliders (layer 1).
func _pick_rotor(sp: Vector2) -> int:
	if _state == null or _state.rotor_count() == 0:
		return -1
	var from := _cam.project_ray_origin(sp)
	var dir := _cam.project_ray_normal(sp)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 60.0, 1)
	q.hit_back_faces = true
	var h: Dictionary = _pivot.get_world_3d().direct_space_state.intersect_ray(q)
	if h.is_empty():
		return -1
	var col: Object = h.get("collider")
	if col == null or not (col as Node).has_meta("pid"):
		return -1
	var pid := String((col as Node).get_meta("pid"))
	var k := _state.rotor_of_part(pid)
	return k if k >= 0 and _state.can_rotate(k) else -1


func _do_rotate(k: int, g: int) -> void:
	var ev: Array[Dictionary] = _state.rotate(k)
	if ev.is_empty():
		return
	var pid := String(ev[0]["part"])
	_taps += 1
	Sfx.play("rotor", -4.0, randf_range(0.97, 1.03))
	Sfx.vibrate(8)
	var from: float = float(_rotor_angle.get(pid, 0.0))
	var to: float = from + _rotor_step(pid)
	if anim_speed >= FALL_SKIP_SPEED:
		_rotor_angle[pid] = to
		_apply_rotor_angle(pid)
	else:
		var tw := _tw()
		tw.tween_method(func(a: float) -> void:
			if _parts.has(pid):
				_rotor_angle[pid] = a
				_apply_rotor_angle(pid), from, to, ROTOR_TURN_S).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		await tw.finished
		if g != _gen:
			return
	_rotor_angle[pid] = fmod(to, TAU)
	_apply_rotor_angle(pid)
	reaction.emit("rotor", pid)
	state_changed.emit(_state.snapshot())


## A hinged part opens on its hinge and stays; it is already released by the rules (nothing it covered stays covered).
func _hinge_open(pid: String, node: MeshInstance3D, h: Dictionary, instant: bool = false) -> void:
	_hinged[pid] = true
	var piv := SpecialFx.v3(h.get("pivot", [0, 0, 0]))
	var ax := SpecialFx.v3(h.get("axis", [1, 0, 0]), Vector3.RIGHT).normalized()
	var ang := deg_to_rad(float(h.get("angle", 100.0)))
	var base: Transform3D = _part_base[pid]
	if instant:
		if is_instance_valid(node):
			node.transform = SpecialFx.about(piv, ax, ang) * base
		return
	Sfx.play(String(h.get("sfx", "creak")), -6.0, randf_range(0.95, 1.05))
	var tw := _tw()
	tw.tween_method(func(a: float) -> void:
		if is_instance_valid(node):
			node.transform = SpecialFx.about(piv, ax, a) * base, 0.0, ang, HINGE_OPEN_S).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## When the host of hinged parts falls, the open lids and doors fall with it.
func _drop_hinged_children(host: String) -> void:
	for pid_v: Variant in _hinged.keys():
		var pid := String(pid_v)
		var d: Dictionary = _part_def.get(pid, {})
		if String((d.get("hinge", {}) as Dictionary).get("host", "")) != host:
			continue
		_hinged.erase(pid)
		var node_v: Variant = _parts.get(pid)
		if node_v != null and is_instance_valid(node_v) and (node_v as Node).get_parent() == _pivot:
			_drop_body(pid, node_v as MeshInstance3D, null, false)


## Reactions of a part that just came free: sound, lights, spinning parts, particles, a shake or a flash.
func _react(pid: String, node: MeshInstance3D) -> void:
	var d: Dictionary = _part_def.get(pid, {})
	if not d.has("react") or anim_speed >= FALL_SKIP_SPEED:
		return
	var r: Dictionary = d["react"]
	var at: Vector3 = node.global_position if is_instance_valid(node) else _pivot.global_position
	if r.has("sfx"):
		Sfx.play(String(r["sfx"]), float(r.get("sfx_db", -4.0)))
	for gp: Variant in r.get("glow", []):
		_set_glow(String(gp), String(r.get("glow_color", "#FFD15C")), float(r.get("glow_k", 1.0)))
	if r.has("spin"):
		var s: Dictionary = r["spin"]
		var parts: Array[String] = []
		for q: Variant in s.get("parts", []):
			parts.append(String(q))
		_spins.append({"parts": parts, "axis": SpecialFx.v3(s.get("axis", [0, 0, 1]), Vector3.BACK).normalized(),
			"rps": float(s.get("rps", 1.0)), "secs": float(s.get("secs", 2.5)), "t": 0.0})
	if r.has("burst"):
		var p := SpecialFx.burst(String(r["burst"]), at, _model_scale)
		_fx.add_child(p)
		var tw := _tw()
		tw.tween_interval(2.6)
		tw.finished.connect(func() -> void:
			if is_instance_valid(p):
				p.queue_free())
	if r.has("shake"):
		_shake_amp = maxf(_shake_amp, float(r["shake"]))
		_shake_t = 0.6
	if r.has("flash"):
		reaction.emit("flash", float(r["flash"]))
	if r.has("hint"):
		reaction.emit("hint", String(r["hint"]))
	if r.has("surprise"):
		reaction.emit("surprise", String(r["surprise"]))


## A lit part: its own material instance with the glow uniforms (x-ray swaps keep it, see _xray_parts).
func _set_glow(pid: String, hex: String, k: float) -> void:
	var mi_v: Variant = _parts.get(pid)
	if mi_v == null or not is_instance_valid(mi_v) or _released.has(pid):
		return
	var mi := mi_v as MeshInstance3D
	var m: ShaderMaterial = _glow_mats.get(pid)
	if m == null:
		m = (ModelBuilder.baked_material() as ShaderMaterial).duplicate() as ShaderMaterial
		m.set_shader_parameter("glow_color", Color(hex))
		_glow_mats[pid] = m
	m.set_shader_parameter("glow", 0.0)
	if _part_mats.has(pid):
		_part_mats[pid] = m   # x-ray is on: the lit look returns when it ends
	else:
		mi.material_override = m
		mi.set_meta("mat", m)
	var tw := _tw()
	tw.tween_method(func(v: float) -> void: m.set_shader_parameter("glow", v), 0.0, k, 0.45).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


## Progress parts (clock hands): angle = removed / total * turns.
func _apply_progress() -> void:
	if _progress_parts.is_empty() or _state == null:
		return
	var snap: Dictionary = _state.snapshot()
	var prog: float = float((snap["removed"] as Array).size()) / maxf(float(snap["total"]), 1.0)
	for pid in _progress_parts:
		if _released.has(pid):
			continue
		var ps: Dictionary = (_part_def[pid] as Dictionary)["progress_spin"]
		var piv := SpecialFx.v3(ps.get("pivot", [0, 0, 0]))
		var ax := SpecialFx.v3(ps.get("axis", [0, 0, 1]), Vector3.BACK)
		var ang := -TAU * float(ps.get("turns", 1.0)) * prog
		_apply_part_rotation(pid, SpecialFx.about(piv, ax, ang))


## After every resolved tap: padlocks whose key is gone pop off, progress parts turn.
func _after_change() -> void:
	for id_v: Variant in _locks.keys():
		var id := int(id_v)
		if not _state.is_locked(id):
			var l_v: Variant = _locks[id_v]   # (a padlock rides its screw node, which may be gone already: Variant first)
			_locks.erase(id_v)
			if l_v != null and is_instance_valid(l_v):
				var l := l_v as Node3D
				Sfx.play("unlock", -6.0)
				var tw := _tw()
				tw.tween_property(l, "position", l.position + Vector3(0, 0.25, 0), 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
				tw.parallel().tween_property(l, "scale", Vector3.ONE * 0.01, 0.22)
				tw.finished.connect(func() -> void:
					if is_instance_valid(l):
						l.queue_free())
	for id_v2: Variant in _keys.keys():
		if _state.is_removed(int(id_v2)):
			var h_v: Variant = _keys[id_v2]
			_keys.erase(id_v2)
			if h_v != null and is_instance_valid(h_v):
				(h_v as Node).queue_free()
	for pid_v: Variant in _rotor_badges.keys():
		if _released.has(pid_v):
			var b_v: Variant = _rotor_badges[pid_v]
			_rotor_badges.erase(pid_v)
			if b_v != null and is_instance_valid(b_v):
				(b_v as Node).queue_free()
	_apply_progress()


func _lock_shake(id: int) -> void:
	var l_v: Variant = _locks.get(id)
	if l_v == null or not is_instance_valid(l_v):
		return
	var l := l_v as Node3D
	var tw := _tw()
	for i in 3:
		tw.tween_property(l, "rotation:z", 0.25 if i % 2 == 0 else -0.25, 0.05)
	tw.tween_property(l, "rotation:z", 0.0, 0.05)


func _tick_special(delta: float) -> void:
	if _state == null:
		return
	var t := float(Time.get_ticks_msec()) * 0.001
	for id_v: Variant in _keys.keys():
		var h_v: Variant = _keys[id_v]
		if h_v != null and is_instance_valid(h_v):
			(h_v as Node3D).rotation.y = t * 1.2
	for pid_v: Variant in _rotor_badges.keys():
		var b_v: Variant = _rotor_badges[pid_v]
		if b_v != null and is_instance_valid(b_v):
			var b := b_v as MeshInstance3D
			b.scale = Vector3.ONE * (1.0 + 0.07 * sin(t * 4.0))
			var m: StandardMaterial3D = b.material_override
			m.albedo_color.a = 0.55 + 0.3 * (0.5 + 0.5 * sin(t * 4.0))
	if not _spins.is_empty():
		for i in range(_spins.size() - 1, -1, -1):
			var s: Dictionary = _spins[i]
			s["t"] = float(s["t"]) + delta
			var k := clampf(1.0 - float(s["t"]) / float(s["secs"]), 0.0, 1.0)   # eases out
			var ang := TAU * float(s["rps"]) * float(s["t"]) * (0.4 + 0.6 * k)
			for pid: String in s["parts"]:
				var node_v: Variant = _parts.get(pid)
				if node_v == null or not is_instance_valid(node_v) or _released.has(pid):
					continue
				var base: Transform3D = _part_base[pid]
				(node_v as MeshInstance3D).transform = Transform3D(base.basis * Basis(base.basis.inverse() * (s["axis"] as Vector3), ang), base.origin)
			if float(s["t"]) >= float(s["secs"]):
				for pid2: String in s["parts"]:
					var node2_v: Variant = _parts.get(pid2)
					if node2_v != null and is_instance_valid(node2_v) and not _released.has(pid2):
						(node2_v as MeshInstance3D).transform = _part_base[pid2]
				_spins.remove_at(i)
	if _shake_t > 0.0:
		_shake_t -= delta
		var a := _shake_amp * 0.06 * clampf(_shake_t / 0.6, 0.0, 1.0)
		var off := Vector3(sin(t * 60.0) * a, cos(t * 73.0) * a * 0.6, 0)
		_pivot.position = Vector3(_base_pos.x + _pan.x, _base_pos.y + _pan.y, 0) + off
		if _shake_t <= 0.0:
			_shake_amp = 0.0
			_apply_zoom()
