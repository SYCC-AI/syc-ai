class_name GameScreen extends Control
## Game screen: HUD around the 3D GameView. Owns booster use, tutorial hints, win/fail/pause flows.

signal navigate(screen: String, args: Dictionary)

const GAME_VIEW := "res://scenes/game/game_view.tscn"
const WIN_SCENE := preload("res://scenes/ui/win_popup.tscn")
const FAIL_SCENE := preload("res://scenes/ui/fail_popup.tscn")
const PAUSE_SCENE := preload("res://scenes/ui/pause_popup.tscn")
const OFFER_SCENE := preload("res://scenes/ui/offer_popup.tscn")
const ScrewDot := preload("res://scripts/ui/screw_dot.gd")
const BOOST_ICON := {"extra_slot": "tray", "hammer": "hammer", "xray": "xray"}
const BOOST_NAME := {"extra_slot": "BOOST_EXTRA_SLOT", "hammer": "BOOST_HAMMER", "xray": "BOOST_XRAY"}
const INTRO_KEY := {"extra_slot": "INTRO_EXTRA_SLOT", "hammer": "INTRO_HAMMER", "xray": "INTRO_XRAY"}
const TUT_KEYS := {1: ["TUT_TAP", "TUT_BOX"], 2: ["TUT_DOCK"], 3: ["TUT_HIDDEN"], 4: ["TUT_ROTATE"]}   # 1.2: L3 teaches the hole under a cube
## Special edition 1.1: the ten living toys open with a card (icon, title, one line) that stays 2.8 s or until the first tap.
const CARD_ICON := {1: "swing", 2: "tray", 3: "swing", 4: "rotate", 5: "tray", 6: "star", 7: "swing", 8: "hammer",
	9: "xray", 10: "star"}   # 1.2: one card per cube level (lessons: tap, tray, hidden hole, layers; then the structure's name)
const CARD_SECS := 2.8

static var anim_speed: float = 1.0  # tests raise this

var args: Dictionary = {}
var gv: Node = null
var level_n: int = 1
var fail_n: int = 0
var ad_used: bool = false
var boosters_used: int = 0
var popups_open: int = 0
var pending: Dictionary = {}  # {kind, pay: "item"|"coins"}
var hammer_mode: bool = false

var _level_label: Label
var _strip: HBoxContainer
var _count_label: Label
var _screws_total: int = 0
var _boost_icons: Dictionary = {}
var _boost_locks: Dictionary = {}
var _zoom_slider: ZoomSlider
var _badge: PanelContainer
var _badge_label: Label
var _boost_btns: Dictionary = {}
var _boost_badges: Dictionary = {}
var _hammer_banner: PanelContainer
var _tut_panel: PanelContainer
var _tut_label: Label
var _tut_hand: TextureRect
var _tut_hits: int = 0
var _tut_active: bool = false
var _tut_timer: SceneTreeTimer
var _hud: Control
var _flash: ColorRect
var _card: PanelContainer
var _card_timer: SceneTreeTimer
var _card_pending: int = 0
var _surprise: PanelContainer
var _lock_toast_ms: int = -100000

func _ready() -> void:
	layout_direction = UI.RTL
	UI.full_rect(self)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if ResourceLoader.exists(GAME_VIEW):
		gv = (load(GAME_VIEW) as PackedScene).instantiate()
		add_child(gv)
		gv.anim_speed = anim_speed
		gv.level_won.connect(_on_won)
		gv.level_failed.connect(_on_failed)
		gv.state_changed.connect(_on_state)
		gv.locked_slot_tapped.connect(_on_locked_slot)
		gv.booster_finished.connect(_on_booster_finished)
		if gv.has_signal("reaction"):
			gv.reaction.connect(_on_reaction)
		if gv.has_signal("locked_tapped"):
			gv.locked_tapped.connect(_on_locked_tapped)
	else:
		add_child(UI.background())  # no 3D board available (lab without GameView)
	_build_hud()
	Game.inventory_changed.connect(_refresh_boosters)
	Game.coins_changed.connect(_refresh_boosters)
	_start(int(args.get("level", Game.play_level())))

# ---- HUD ----
func _build_hud() -> void:
	var hud := Control.new()
	UI.full_rect(hud)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(hud)
	_hud = hud
	# top bar 0.00-0.08
	var top := MarginContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.anchor_right = 1.0
	top.anchor_bottom = 0.08
	top.add_theme_constant_override("margin_left", 36)
	top.add_theme_constant_override("margin_right", 36)
	top.add_theme_constant_override("margin_top", 28)
	hud.add_child(top)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 16)
	top.add_child(row)
	row.add_child(UI.round_btn("pause", _on_pause, 104))
	var mid := CenterContainer.new()
	mid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var pill := PanelContainer.new()
	pill.theme_type_variation = "PillPanel"
	pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_level_label = UI.lbl("", "BigLabel")
	pill.add_child(_level_label)
	mid.add_child(pill)
	row.add_child(mid)
	_badge = PanelContainer.new()
	_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_badge_label = UI.lbl("", "WhiteLabel")
	_badge_label.add_theme_font_size_override("font_size", 34)
	_badge.add_child(_badge_label)
	var holder := CenterContainer.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.custom_minimum_size = Vector2(200, 0)
	holder.add_child(_badge)
	row.add_child(holder)

	# zoom slider on the left side of the play area, bound both ways to GameView.set_zoom / zoom_changed
	_zoom_slider = ZoomSlider.new()
	_zoom_slider.anchor_top = 0.655
	_zoom_slider.anchor_bottom = 0.855
	_zoom_slider.offset_left = 18
	_zoom_slider.offset_right = 102
	_zoom_slider.layout_direction = Control.LAYOUT_DIRECTION_LTR
	hud.add_child(_zoom_slider)
	if gv != null and gv.has_method("set_zoom"):
		_zoom_slider.value_changed.connect(func(v: float) -> void: gv.set_zoom(v))
		if gv.has_signal("zoom_changed"):
			gv.zoom_changed.connect(func(v: float) -> void:
				if not _zoom_slider.is_dragging():
					_zoom_slider.set_value(v))
	else:
		_zoom_slider.hide()

	# next-levels strip under the top bar, screw counter pill under the racks
	_strip = HBoxContainer.new()
	_strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_strip.layout_direction = Control.LAYOUT_DIRECTION_RTL
	_strip.alignment = BoxContainer.ALIGNMENT_CENTER
	_strip.add_theme_constant_override("separation", 14)
	_strip.anchor_right = 1.0
	_strip.anchor_top = 0.074
	_strip.anchor_bottom = 0.122
	hud.add_child(_strip)
	hud.add_child(_make_counter())

	# booster bar: one compact rounded bar at the bottom with icon buttons
	var bar := PanelContainer.new()
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_stylebox_override("panel", _bar_style())
	bar.anchor_left = 0.5
	bar.anchor_right = 0.5
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_left = -330
	bar.offset_right = 330
	bar.offset_top = -232
	bar.offset_bottom = -44
	hud.add_child(bar)
	var brow := HBoxContainer.new()
	brow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	brow.alignment = BoxContainer.ALIGNMENT_CENTER
	brow.add_theme_constant_override("separation", 20)
	bar.add_child(brow)
	for kind in Game.KINDS:
		var b := _make_booster_button(kind)
		brow.add_child(b)
		_boost_btns[kind] = b

	# hammer banner + tutorial text, both just under the top bar
	_hammer_banner = _banner(tr("HAMMER_PICK"))
	hud.add_child(_hammer_banner)
	_hammer_banner.hide()
	_tut_panel = _banner("")
	_tut_label = _tut_panel.get_child(0)
	hud.add_child(_tut_panel)
	_tut_panel.hide()
	_tut_hand = Icons.rect("hand", 130)
	_tut_hand.hide()
	hud.add_child(_tut_hand)
	# special edition: a white flash over everything (camera, lens cap) and the surprise banner
	_flash = ColorRect.new()
	_flash.color = Color(1, 1, 1, 1)
	_flash.modulate.a = 0.0
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UI.full_rect(_flash)
	hud.add_child(_flash)
	_surprise = _banner("")
	_surprise.anchor_top = 0.235
	hud.add_child(_surprise)
	_surprise.hide()

func _banner(text: String) -> PanelContainer:
	var p := PanelContainer.new()
	p.theme_type_variation = "PillPanel"
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.anchor_left = 0.06
	p.anchor_right = 0.94
	p.anchor_top = 0.31
	p.grow_vertical = Control.GROW_DIRECTION_END
	p.add_child(UI.lbl(text, "SmallLabel", HORIZONTAL_ALIGNMENT_CENTER, true))
	return p

func _flat(bg: Color, radius: int, bottom: int, edge: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.border_width_bottom = bottom
	sb.border_color = edge
	sb.anti_aliasing = true
	return sb

func _bar_style() -> StyleBoxFlat:
	var sb := _flat(Color("#FFE9C7"), 52, 10, Color("#E2B57A"))
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 14
	sb.content_margin_bottom = 18
	sb.shadow_color = Color(0.4, 0.22, 0.05, 0.22)
	sb.shadow_size = 12
	sb.shadow_offset = Vector2(0, 6)
	return sb

## Booster tile: the icon on a soft cream tile (unlocked) or a padlock with «مرحلهٔ n» (not unlocked yet).
func _make_booster_button(kind: String) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(176, 150)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(func() -> void: _on_booster_pressed(kind))
	UI.juice(b)
	var tile := _flat(Color("#FFFBF2"), 40, 8, Color("#E8C99A"))
	tile.shadow_color = Color(0.4, 0.22, 0.05, 0.12)
	tile.shadow_size = 4
	tile.shadow_offset = Vector2(0, 3)
	var tile_p := tile.duplicate() as StyleBoxFlat
	tile_p.bg_color = Color("#FFF1D6")
	b.add_theme_stylebox_override("normal", tile)
	b.add_theme_stylebox_override("hover", tile)
	b.add_theme_stylebox_override("pressed", tile_p)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_stylebox_override("disabled", StyleBoxEmpty.new())
	var icon := Icons.rect(BOOST_ICON[kind], 96)
	icon.set_anchors_preset(Control.PRESET_FULL_RECT)
	icon.offset_top = 22
	icon.offset_bottom = -8
	icon.offset_left = 40
	icon.offset_right = -10
	b.add_child(icon)
	_boost_icons[kind] = icon
	var lock := VBoxContainer.new()
	lock.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lock.alignment = BoxContainer.ALIGNMENT_CENTER
	lock.add_theme_constant_override("separation", 0)
	lock.set_anchors_preset(Control.PRESET_FULL_RECT)
	var lc := CenterContainer.new()
	lc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lc.add_child(Icons.rect("lock", 72))
	lock.add_child(lc)
	var ll := UI.lbl(Fa.fmt("LEVEL", {"n": int(Game.INTRO_LEVEL[kind])}), "SmallLabel")
	ll.add_theme_font_size_override("font_size", 28)
	lock.add_child(ll)
	b.add_child(lock)
	_boost_locks[kind] = lock
	var badge := PanelContainer.new()
	var bsb := StyleBoxFlat.new()
	bsb.bg_color = Color("#F5841B")
	bsb.set_corner_radius_all(40)  # fully round: a circle for one digit, a pill for coin + price
	bsb.set_border_width_all(4)
	bsb.border_color = Color("#FFFFFF")
	bsb.content_margin_left = 12
	bsb.content_margin_right = 12
	bsb.content_margin_top = 0
	bsb.content_margin_bottom = 2
	bsb.shadow_color = Color(0.4, 0.2, 0.0, 0.25)
	bsb.shadow_size = 4
	bsb.shadow_offset = Vector2(0, 3)
	badge.add_theme_stylebox_override("panel", bsb)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(badge)
	badge.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 0)  # RTL mirrors: lands at the physical top-left
	badge.custom_minimum_size = Vector2(58, 58)
	badge.position += Vector2(-40, -38)  # centred on the tile corner, clear of the icon
	_boost_badges[kind] = badge
	return b

func _badge_lbl(t: String) -> Label:
	var l := UI.lbl(t, "WhiteLabel")
	l.add_theme_font_size_override("font_size", 30)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l

func _refresh_boosters() -> void:
	if _level_label == null:
		return
	for kind in Game.KINDS:
		var b: Button = _boost_btns[kind]
		var open := Game.booster_visible(kind, level_n)
		(_boost_icons[kind] as Control).visible = open
		(_boost_locks[kind] as Control).visible = not open
		b.add_theme_stylebox_override("normal", b.get_theme_stylebox("hover") if open else StyleBoxEmpty.new())
		var badge: PanelContainer = _boost_badges[kind]
		badge.visible = open
		for c in badge.get_children():
			c.queue_free()
		var h := HBoxContainer.new()
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		h.add_theme_constant_override("separation", 4)
		h.alignment = BoxContainer.ALIGNMENT_CENTER
		var have: int = Game.boosters[kind]
		if have > 0:
			h.add_child(_badge_lbl(Fa.digits(have)))
		elif Game.coins >= Game.booster_price(kind) or not Ads.is_rewarded_ready():
			# no ads in the store build: always show the coin price (tapping without coins says NOT_ENOUGH_COINS)
			h.add_child(Icons.rect("coin", 32))
			h.add_child(_badge_lbl(Fa.digits(Game.booster_price(kind))))
		else:
			h.add_child(Icons.rect("play", 36, "#FFFFFF"))
		badge.add_child(h)
		b.modulate = Color("#FFD27A") if (kind == "hammer" and hammer_mode) else Color.WHITE
	_hammer_banner.visible = hammer_mode

## «removed/total» pill with a small gold screw head, physical left under the racks (like the reference).
func _make_counter() -> Control:
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := _flat(Color(0.33, 0.2, 0.08, 0.42), 30, 0, Color.TRANSPARENT)
	sb.content_margin_left = 14
	sb.content_margin_right = 26
	sb.content_margin_top = 4
	sb.content_margin_bottom = 6
	p.add_theme_stylebox_override("panel", sb)
	p.layout_direction = Control.LAYOUT_DIRECTION_LTR  # physical left, like the reference
	p.anchor_top = 0.268
	p.offset_left = 26
	p.offset_top = 0
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.layout_direction = Control.LAYOUT_DIRECTION_LTR
	h.add_theme_constant_override("separation", 10)
	p.add_child(h)
	h.add_child(ScrewDot.new())
	_count_label = UI.lbl("", "WhiteLabel")
	_count_label.add_theme_font_size_override("font_size", 34)
	h.add_child(_count_label)
	return p

func _refresh_counter() -> void:
	if _count_label == null or gv == null or gv.state() == null:
		return
	var removed: int = (gv.state().snapshot()["removed"] as Array).size()
	_count_label.text = "%s/%s" % [Fa.digits(removed), Fa.digits(_screws_total)]  # a digit run reads left to right in RTL too

## Thumbnails of the levels around the current one (current one big on a white tile).
func _fill_strip(n: int) -> void:
	for c in _strip.get_children():
		c.queue_free()
	var lv := get_tree().root.get_node_or_null("Levels")
	var last: int = lv.count() if lv and lv.has_method("count") else n + 4
	var first := clampi(n - 1, 1, maxi(1, last - 4))
	for k in range(first, mini(first + 5, last + 1)):
		var cur := k == n
		var tile := PanelContainer.new()
		tile.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tile.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var sb := _flat(Color(1, 1, 1, 0.95 if cur else 0.45), 22, 0, Color.TRANSPARENT)
		sb.set_content_margin_all(4)
		if cur:
			sb.shadow_color = Color(0.4, 0.22, 0.05, 0.18)
			sb.shadow_size = 6
			sb.shadow_offset = Vector2(0, 3)
		tile.add_theme_stylebox_override("panel", sb)
		var tr2 := TextureRect.new()
		tr2.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tr2.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr2.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		var px := 90 if cur else 66
		tr2.custom_minimum_size = Vector2(px, px)
		var path := "res://assets/ui/thumbs/%s.png" % (lv.model_id_of(k) if lv else "")
		tr2.texture = load(path) if ResourceLoader.exists(path) else Icons.tex("question", px)
		tr2.modulate = Color.WHITE if cur else Color(1, 1, 1, 0.8)
		tile.add_child(tr2)
		_strip.add_child(tile)

func _set_badge(band: String) -> void:
	_badge.visible = band == "hard" or band == "very_hard"
	if _badge.visible:
		_badge_label.text = tr("DIFF_HARD") if band == "hard" else tr("DIFF_VERY_HARD")
		var sb := StyleBoxFlat.new()
		sb.bg_color = UI.diff_color(band)
		sb.set_corner_radius_all(30)
		sb.content_margin_left = 24
		sb.content_margin_right = 24
		sb.content_margin_top = 8
		sb.content_margin_bottom = 8
		_badge.add_theme_stylebox_override("panel", sb)

func _band_of(n: int) -> String:
	var lv := get_tree().root.get_node_or_null("Levels")
	return lv.band_of(n) if lv and lv.has_method("band_of") else "normal"

# ---- level lifecycle ----
func _start(n: int) -> void:
	level_n = n
	_reset_attempt()
	_level_label.text = Fa.fmt("LEVEL", {"n": n})
	_set_badge(_band_of(n))
	_fill_strip(n)
	if gv:
		gv.start_level(n)
		gv.set_locked_slot_visible(n >= 5)
		var lvl: Dictionary = gv._level
		_screws_total = (lvl.get("screws", []) as Array).size()
	_refresh_counter()
	_refresh_boosters()
	_tutorial(n)
	_intros(n)
	_show_card(n)   # (after the booster intro popups: a card under a popup would be missed)

func _reset_attempt() -> void:
	fail_n = 0
	ad_used = false
	boosters_used = 0
	pending.clear()
	hammer_mode = false

func _restart() -> void:
	_reset_attempt()
	if gv:
		gv.restart()
	_refresh_boosters()
	_refresh_counter()
	_tutorial(level_n)

func _intros(n: int) -> void:
	for kind in Game.KINDS:
		if Game.take_intro(kind, n):
			var pop := OFFER_SCENE.instantiate() as OfferPopup
			pop.configure(tr(BOOST_NAME[kind]), tr(INTRO_KEY[kind]), BOOST_ICON[kind], [{"text": tr("OK"), "variant": "BtnGreen"}])
			_show_popup(pop)

func _show_popup(pop: PopupBase) -> void:
	popups_open += 1
	if gv:
		gv.set_paused(true)
	pop.closed.connect(func() -> void:
		popups_open -= 1
		if popups_open == 0 and gv:
			gv.set_paused(false)
		if popups_open == 0 and _card_pending > 0:
			var n := _card_pending
			_card_pending = 0
			_show_card(n))
	add_child(pop)

# ---- tutorial ----
func _tutorial(n: int) -> void:
	_tut_hits = 0
	_tut_active = TUT_KEYS.has(n)
	_tut_hand.visible = false
	_tut_panel.visible = _tut_active
	if not _tut_active:
		return
	_tut_label.text = tr(TUT_KEYS[n][0])
	_tut_label.add_theme_font_size_override("font_size", 38)
	_update_hand()
	_tut_timer = get_tree().create_timer(6.0)
	var timer := _tut_timer
	timer.timeout.connect(func() -> void:
		if timer == _tut_timer:
			_tut_end())

func _process(_delta: float) -> void:
	_update_hand()  # the model intro-scales and rotates, so the hint must follow the screw every frame

func _update_hand() -> void:
	if not _tut_active or gv == null:
		return
	var p: Vector2 = gv.hint_screw_screen_pos()
	if p.x < 0:
		_tut_hand.hide()
		return
	_tut_hand.show()
	_tut_hand.position = p + Vector2(-62, 16)  # fingertip just under the screw head
	if not _tut_hand.has_meta("bob"):
		_tut_hand.set_meta("bob", true)
		var tw := _tut_hand.create_tween().set_loops()
		tw.tween_property(_tut_hand, "pivot_offset", Vector2(65, 65) + Vector2(0, 0), 0.01)
		tw.tween_property(_tut_hand, "scale", Vector2(0.88, 0.88), 0.45).set_trans(Tween.TRANS_SINE)
		tw.tween_property(_tut_hand, "scale", Vector2.ONE, 0.45).set_trans(Tween.TRANS_SINE)

func _tut_end() -> void:
	_tut_active = false
	_tut_panel.hide()
	_tut_hand.hide()

func _on_state(_snap: Dictionary) -> void:
	_refresh_counter()
	_hide_card()
	if not _tut_active:
		return
	_tut_hits += 1
	var keys: Array = TUT_KEYS.get(level_n, [])
	if _tut_hits >= 2:
		_tut_end()
		return
	if _tut_hits < keys.size():
		_tut_label.text = tr(keys[_tut_hits])
	_update_hand()

# ---- special edition 1.1: level cards, reactions, locks ----
## The card of a living toy: icon, title and one line of help, under the strip; gone at the first tap or after CARD_SECS.
func _show_card(n: int) -> void:
	_hide_card()
	if not CARD_ICON.has(n) or Game.test_mode or _hud == null:
		return
	if popups_open > 0:
		_card_pending = n   # shown when the last popup closes
		return
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.layout_direction = UI.RTL
	var sb := _flat(Color("#FFF4DE"), 34, 8, Color("#E2B57A"))
	sb.content_margin_left = 26
	sb.content_margin_right = 26
	sb.content_margin_top = 18
	sb.content_margin_bottom = 20
	sb.shadow_color = Color(0.4, 0.22, 0.05, 0.25)
	sb.shadow_size = 14
	sb.shadow_offset = Vector2(0, 6)
	p.add_theme_stylebox_override("panel", sb)
	p.anchor_left = 0.07
	p.anchor_right = 0.93
	p.anchor_top = 0.135
	p.grow_vertical = Control.GROW_DIRECTION_END
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 22)
	p.add_child(row)
	row.add_child(Icons.rect(CARD_ICON[n], 150))
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 4)
	var title := UI.lbl(tr("CARD_L%d_TITLE" % n), "BigLabel", HORIZONTAL_ALIGNMENT_RIGHT)
	title.add_theme_font_size_override("font_size", 50)
	col.add_child(title)
	var text := UI.lbl(tr("CARD_L%d" % n), "SmallLabel", HORIZONTAL_ALIGNMENT_RIGHT, true)
	text.add_theme_font_size_override("font_size", 32)
	col.add_child(text)
	row.add_child(col)
	_hud.add_child(p)
	_card = p
	UI.pop_in(p, 0.28)
	UI.sfx("button")
	_card_timer = get_tree().create_timer(CARD_SECS)
	var t := _card_timer
	t.timeout.connect(func() -> void:
		if t == _card_timer:
			_hide_card())

func _hide_card() -> void:
	if _card == null or not is_instance_valid(_card):
		_card = null
		return
	var c := _card
	_card = null
	var tw := c.create_tween()
	tw.tween_property(c, "modulate:a", 0.0, 0.22)
	tw.tween_callback(c.queue_free)

## Reactions of the toys (GameView.reaction): a screen flash, a hint toast, the surprise banner. Rotor turns need no HUD.
func _on_reaction(kind: String, arg: Variant) -> void:
	match kind:
		"flash":
			if _flash == null:
				return
			_flash.modulate.a = clampf(float(arg), 0.0, 1.0)
			var tw := _flash.create_tween()
			tw.tween_property(_flash, "modulate:a", 0.0, 0.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		"hint":
			UI.toast(self, tr(String(arg)))
		"surprise":
			_show_surprise(tr("SURPRISE_" + String(arg)))

func _show_surprise(text: String) -> void:
	if _surprise == null:
		return
	(_surprise.get_child(0) as Label).text = text
	_surprise.modulate.a = 1.0
	_surprise.show()
	UI.pop_in(_surprise, 0.3)
	var tw := _surprise.create_tween()
	tw.tween_interval(2.4)
	tw.tween_property(_surprise, "modulate:a", 0.0, 0.4)
	tw.tween_callback(_surprise.hide)

## A padlocked screw was tapped before its key: one short hint, at most every 2.5 s.
func _on_locked_tapped(_id: int) -> void:
	var now := Time.get_ticks_msec()
	if now - _lock_toast_ms < 2500:
		return
	_lock_toast_ms = now
	UI.toast(self, tr("LOCK_HINT"))

# ---- boosters ----
func _on_booster_pressed(kind: String) -> void:
	if popups_open > 0 or gv == null:
		return
	if not Game.booster_visible(kind, level_n):
		UI.toast(self, Fa.fmt("BOOST_UNLOCK_AT", {"n": int(Game.INTRO_LEVEL[kind])}))
		return
	if kind == "hammer" and hammer_mode:
		gv.cancel_booster()
		hammer_mode = false
		pending.clear()
		_refresh_boosters()
		return
	if int(Game.boosters[kind]) > 0:
		_use(kind, "item")
	elif Game.coins >= Game.booster_price(kind):
		_use(kind, "coins")
	elif Ads.is_rewarded_ready():
		_watch_ad_for(kind)
	elif Ads.backend == "none":
		UI.toast(self, tr("NOT_ENOUGH_COINS"))
	else:
		UI.toast(self, tr("AD_NOT_READY"))

func _watch_ad_for(kind: String) -> void:
	Ads.show_rewarded("booster_" + kind, func(ok: bool) -> void:
		if not is_inside_tree():
			return
		if ok:
			Game.add_booster(kind, 1)  # the reward is kept even if the booster cannot be used right now
			_use(kind, "item")
		else:
			UI.toast(self, tr("AD_NOT_READY")))

func _use(kind: String, pay: String) -> bool:
	pending = {"kind": kind, "pay": pay}
	if not gv.use_booster(kind):
		pending.clear()
		return false
	hammer_mode = kind == "hammer"
	_refresh_boosters()
	return true

func _on_booster_finished(kind: String) -> void:
	if pending.get("kind", "") == kind:
		if pending["pay"] == "item":
			Game.use_booster_item(kind)
		else:
			Game.spend_coins(Game.booster_price(kind))
		pending.clear()
		boosters_used += 1
	if kind == "hammer":
		hammer_mode = false
	UI.sfx("booster")
	_refresh_boosters()

func _on_locked_slot() -> void:
	if popups_open > 0:
		return
	var kind := "extra_slot"
	var opts: Array = []
	var have: int = Game.boosters[kind]
	if have > 0:
		opts.append({"text": "%s ×%s" % [tr(BOOST_NAME[kind]), Fa.digits(have)], "variant": "BtnGreen", "cb": func() -> void: _use(kind, "item")})
	else:
		if Ads.is_rewarded_ready():
			opts.append({"text": tr("BOOST_FREE_AD"), "variant": "BtnOrange", "icon": "play", "cb": func() -> void: _watch_ad_for(kind)})
		var price := Game.booster_price(kind)
		opts.append({"text": Fa.fmt("BOOST_BUY", {"n": price}), "variant": "BtnBlue", "icon": "coin", "disabled": Game.coins < price, "cb": func() -> void: _use(kind, "coins")})
	var pop := OFFER_SCENE.instantiate() as OfferPopup
	pop.configure(tr("SLOT_LOCKED_TITLE"), tr("SLOT_LOCKED_TEXT"), "lock", opts, true)
	_show_popup(pop)

# ---- pause ----
func _on_pause() -> void:
	if popups_open > 0:
		return
	var pop := PAUSE_SCENE.instantiate() as PausePopup
	pop.configure()
	pop.restart.connect(_restart)
	pop.home.connect(func() -> void: navigate.emit("home", {}))
	_show_popup(pop)

# ---- win ----
func _on_won(n: int, _stats: Dictionary) -> void:
	_tut_end()
	var earned := Game.on_level_won(n)
	var lw: Dictionary = Game.last_win.duplicate()
	var pop := WIN_SCENE.instantiate() as WinPopup
	pop.configure(earned, str(lw.get("new_model", "")), func() -> void: _after_win(n, lw))
	_show_popup(pop)

func _after_win(n: int, lw: Dictionary) -> void:
	if bool(lw.get("season_end", false)):
		var pop := OFFER_SCENE.instantiate() as OfferPopup
		pop.configure(tr("SEASON_END_TITLE"), tr("SEASON_END_TEXT"), "star", [{"text": tr("OK"), "variant": "BtnGreen", "cb": func() -> void: navigate.emit("home", {})}])
		_show_popup(pop)
		return
	Ads.maybe_show_interstitial(n, func() -> void: _start(Game.play_level()))

# ---- fail (never an interstitial here) ----
func _on_failed(_n: int, pct: int) -> void:
	_tut_end()
	fail_n += 1
	_show_fail(pct)

func _show_fail(pct: int) -> void:
	var pop := FAIL_SCENE.instantiate() as FailPopup
	pop.configure(pct, fail_n, ad_used, gv.can_continue())
	pop.continue_ad.connect(func() -> void:
		Ads.show_rewarded("continue", func(ok: bool) -> void:
			if ok:
				ad_used = true
				gv.continue_with_extra_slot()
			else:
				_show_fail(pct)))
	pop.continue_coins.connect(func(price: int) -> void:
		if Game.spend_coins(price):
			gv.continue_with_extra_slot()
		else:
			_show_fail(pct))
	pop.retry.connect(_restart)
	_show_popup(pop)

## Shot helper (tools/shot --call=preview_zoom --level=<percent>).
func preview_zoom(percent: int) -> void:
	var v := clampf(percent / 100.0, 0.0, 1.0)
	_zoom_slider.set_value(v)
	if gv != null and gv.has_method("set_zoom"):
		gv.set_zoom(v)
