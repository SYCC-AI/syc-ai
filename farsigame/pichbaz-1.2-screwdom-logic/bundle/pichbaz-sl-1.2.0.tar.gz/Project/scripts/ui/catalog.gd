extends RefCounted
## The 70-model catalog (COMMON §5 + §8.3): level n shows IDS[n-1]. UI-side single source until Levels.MODELS is switched.

const IDS: Array[String] = [
	"blk_s01", "blk_s02", "blk_s03", "blk_s04", "blk_s05", "blk_s06", "blk_s07", "blk_s08", "blk_s09", "blk_s10",
	"sailboat", "turtle", "school_bus", "grand_piano", "helicopter", "windmill", "toy_elephant", "tractor", "lighthouse", "biplane",
	"samovar", "submarine", "hot_air_balloon", "jukebox", "rocket", "windcatcher_house", "steam_locomotive", "treehouse", "dinosaur", "galleon",
	"scooter", "carousel", "excavator", "clock_tower", "ufo", "fire_truck", "ferris_wheel", "race_car", "cargo_ship", "space_shuttle",
	"azadi_tower", "monster_truck", "airship", "robot_mech", "castle", "cruise_ship", "space_station", "owl", "jet_airliner", "persian_palace",
	"blk_cube2", "blk_stairs", "blk_cross", "blk_cube3", "blk_arch", "blk_tower", "blk_pyramid", "blk_bridge", "blk_ring", "blk_cube4_holes",
	"blk_ziggurat", "blk_castle_wall", "blk_spiral", "blk_heart", "blk_star", "blk_dog", "blk_horse", "blk_camel", "blk_robot", "blk_giant_cube5",
]

static func id_of(level: int) -> String:
	return IDS[clampi(level, 1, IDS.size()) - 1]

## Level n finished <=> the next level to play is above it (or the whole season is done).
static func unlocked(index: int) -> bool:
	return Game.level > index + 1
