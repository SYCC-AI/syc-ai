extends Node
## Levels autoload (BLUEPRINT 6.1). Reads level and model JSON, caches both.
## Autoload script: no class_name. Tests use preload("res://scripts/core/levels.gd").new().

## Catalog: one model per level, 70 levels (COMMON 5 and 8.3). Index 0 is level 1.
const CATALOG: Array[String] = [
	"blk_s01", "blk_s02", "blk_s03", "blk_s04", "blk_s05", "blk_s06", "blk_s07", "blk_s08", "blk_s09",
	"blk_s10", "sailboat", "turtle", "school_bus", "grand_piano", "helicopter", "windmill", "toy_elephant", "tractor",
	"lighthouse", "biplane", "samovar", "submarine", "hot_air_balloon", "jukebox", "rocket", "windcatcher_house",
	"steam_locomotive", "treehouse", "dinosaur", "galleon", "scooter", "carousel", "excavator", "clock_tower", "ufo",
	"fire_truck", "ferris_wheel", "race_car", "cargo_ship", "space_shuttle", "azadi_tower", "monster_truck", "airship",
	"robot_mech", "castle", "cruise_ship", "space_station", "owl", "jet_airliner", "persian_palace",
	"blk_cube2", "blk_stairs", "blk_cross", "blk_cube3", "blk_arch", "blk_tower", "blk_pyramid", "blk_bridge", "blk_ring",
	"blk_cube4_holes", "blk_ziggurat", "blk_castle_wall", "blk_spiral", "blk_heart", "blk_star", "blk_dog", "blk_horse",
	"blk_camel", "blk_robot", "blk_giant_cube5",
]

## Level plan (item 11 + 13, 2026-10-07): [screws, colors, band]. More screws and a harder curve than 1.0.4:
##   L1-10 Screwdom-logic cube levels (1.2, Docs/design/SCREWDOM_LOGIC.md): every screw on a strap, one per cube face,
##   hidden holes under stacked cubes, EVERY hole screwed (counts come from the structure, the plan is the design target):
##   (the 1.1 living toys were:)
##   L1 24/2 gift box (hinged lid, surprise), L2 30/3 alarm clock (progress hands, popping bells), L3 54/3 wooden cube +
##   swinging strap, L4 36/3 camera (hidden heads under caps, popping lens cap), L5 42/4 radio (turning dial = rotor),
##   L6 42/4 cottage (hinged door, shutters, cat), L7 36/4 cake (key star, locked candles), L8 39/4 lantern (rotor crown),
##   L9 39/4 robot (key + locked hatch + battery), L10 42/4 car (hinged hood and trunk, finale)
##   | L11-35 45-78 | L36-70 60-108 (block levels L51-70 the most, 84-108)
##   band: L1-3 tutorial, L4 easy (the only easy one), every 10th very_hard, every 5th hard, from L36 also hard at x2/x4,
##   else normal; first real challenge at L5. Screw counts are multiples of 3 (one box = 3 screws).
const PLAN_R3: Array = [
	[18, 2, "tutorial"], [27, 3, "tutorial"], [42, 3, "easy"], [57, 4, "easy"], [81, 4, "normal"],
	[84, 4, "normal"], [102, 4, "normal"], [114, 5, "hard"], [138, 4, "normal"], [159, 5, "very_hard"],
	[45, 5, "normal"], [45, 5, "normal"], [48, 5, "normal"], [48, 5, "normal"], [54, 5, "hard"],
	[51, 5, "normal"], [54, 5, "normal"], [54, 5, "normal"], [57, 5, "normal"], [63, 5, "very_hard"],
	[60, 6, "normal"], [60, 6, "normal"], [63, 6, "normal"], [63, 6, "normal"], [69, 6, "hard"],
	[66, 6, "normal"], [69, 6, "normal"], [69, 6, "normal"], [72, 6, "normal"], [78, 6, "very_hard"],
	[75, 6, "normal"], [75, 6, "hard"], [78, 6, "hard"], [78, 6, "hard"], [78, 6, "hard"],
	[60, 5, "normal"], [63, 7, "hard"], [63, 5, "normal"], [66, 7, "hard"], [72, 7, "very_hard"],
	[66, 5, "normal"], [72, 7, "hard"], [69, 5, "normal"], [75, 7, "hard"], [75, 7, "hard"],
	[75, 5, "normal"], [78, 7, "hard"], [78, 5, "normal"], [81, 7, "hard"], [87, 7, "very_hard"],
	[81, 5, "normal"], [63, 4, "hard"], [84, 5, "normal"], [63, 4, "hard"], [90, 7, "hard"],
	[90, 5, "normal"], [93, 5, "hard"], [93, 5, "normal"], [96, 5, "hard"], [72, 4, "very_hard"],
	[72, 4, "normal"], [87, 5, "hard"], [66, 4, "normal"], [66, 4, "hard"], [78, 5, "hard"],
	[72, 4, "normal"], [78, 5, "hard"], [66, 4, "normal"], [66, 4, "hard"], [60, 4, "very_hard"],
]

const MODELS: Array[String] = CATALOG
const PLAN: Array = PLAN_R3

## Fail-rate windows per band (casual player %), BLUEPRINT 5.5: [min, max].
const BAND_FAIL: Dictionary = {
	"tutorial": [0, 8], "easy": [8, 28], "normal": [25, 55], "hard": [50, 80], "very_hard": [70, 95],
}

var level_dir: String = "res://data/levels_r3"
var model_dir: String = "res://data/models_r3"

var _levels: Dictionary = {}
var _models: Dictionary = {}


func count() -> int:
	return PLAN.size()


func model_id_of(n: int) -> String:
	if n < 1 or n > PLAN.size():
		return ""
	return MODELS[n - 1]


func band_of(n: int) -> String:
	if n < 1 or n > PLAN.size():
		return ""
	return PLAN[n - 1][2]


func plan_screws(n: int) -> int:
	return PLAN[n - 1][0]


func plan_colors(n: int) -> int:
	return PLAN[n - 1][1]


func load_level(n: int) -> Dictionary:
	if _levels.has(n):
		return _levels[n]
	var d: Dictionary = _read_json("%s/level_%03d.json" % [level_dir, n])
	if not d.is_empty():
		_levels[n] = d
	return d


func load_model(id: String) -> Dictionary:
	if _models.has(id):
		return _models[id]
	var d: Dictionary = _read_json("%s/%s.json" % [model_dir, id])
	if not d.is_empty():
		_models[id] = d
	return d


func clear_cache() -> void:
	_levels.clear()
	_models.clear()


func _read_json(path: String) -> Dictionary:
	var f: FileAccess = FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("Levels: cannot open %s" % path)
		return {}
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("Levels: bad JSON in %s" % path)
		return {}
	return parsed
